﻿using System;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Component;
using Component.ObjectManager;
using Component.wsOnline;

namespace UI
{
    public partial class frmSocket : Form
    {
        private Thread listenThread;
        private Server s;
        private bool cancel = true;

        public frmSocket()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            int portNo = Convert.ToInt32(ConfigurationManager.AppSettings["portNo"].ToString());
            s = new Server(portNo, "", "");
            this.Text = "New Version Start:" + portNo.ToString();
            listenThread = new Thread(new ThreadStart(s.Start));
            listenThread.Start();
            s.Readed += new ReadDataEventHandler(s_Readed);
        }

        void s_Readed(object sender, EventArgs e)
        {
            Server s = (Server)sender;
            StateObject st = (StateObject)s.connectedSocks[s.connectedSocks.Count - 1];

            byte[] msg = st.msg;
            byte[] Header = new byte[8];
            TextWriter tw = new StreamWriter("logs.txt",true);
            tw.WriteLine("Message ("+ DateTime.Now +"): " + BitConverter.ToString(st.msg, 0).Replace("-", ",") + "\r\n");
            tw.Close();

            //get the header of message
            Array.Copy(msg, Header, 8);

            //write in textbox
            SetControlTextInAThreadSafeWay(txtEvent, BitConverter.ToString(st.msg, 0).Replace("-", ","));

            // decode the message header
            HeaderMsg _header = MSG_Header.DecodeHeader(Header);

            if (_header.Flags == 1)
            {
                try
                {
                    byte[] buffer = null;
                    switch (_header.ServiceType)
                    {

                        case (int)ServiceType.Login:
                            //decode the login message 
                            LoginQuery loginquery = MSG_Login.DecodeLogin(msg);
                            //check the version of Mobile Application
                            int versionNo = Convert.ToInt32(ConfigurationManager.AppSettings["VersionNo"].ToString());
                            if (versionNo > loginquery.Version)
                                throw new Exception("VersionError");

                            //initilize customermanger with BrokerCode
                            CustomerManager manager = new CustomerManager(loginquery.BrokerCode);
                            buffer = manager.Login(_header, loginquery);
                            break;
                        case (int)ServiceType.StockInfo:
                            StockManager stockManager = new StockManager();
                            buffer = stockManager.GetStockPrice(msg, _header, st);
                            break;

                        case (int)ServiceType.AddOrder:
                            //DECODE ORDER MESSAGE
                            Order order = MSG_Request.DecodeMessage(msg);
                            WsOrderMessage om = MSG_Request.ConvertOrderToWsOrderMessage(msg, order);
                            //add order msg to oms
                            buffer = CustomerManager.GetCustomerManger(om.CustomerId, order.BrokerCode).AddOrder(msg,
                                                                                                                 _header,
                                                                                                                 st, om);
                            break;
                        case (int)ServiceType.OrderList:
                            RequestQuery query = MSG_Request.DecodeViewRequestList(msg);
                            //get all order of customer
                            buffer = CustomerManager.GetCustomerManger(query.CustomerId, query.BrokerCode).OrderList(
                                msg, _header, st, OrderListType.OrderList);
                            break;
                        case (int)ServiceType.OrderBook:
                            RequestQuery reqquery = MSG_Request.DecodeViewRequestList(msg);
                            //get all execute order or partially execute order of customer
                            buffer = CustomerManager.GetCustomerManger(reqquery.CustomerId, reqquery.BrokerCode).OrderList(
                                msg, _header, st, OrderListType.OrderBook);
                            break;
                        case (int)ServiceType.CancelOrder:
                            //cancel the order 
                            RequestQuery cancelOrder = MSG_Request.DecodeCancelOrder(msg);
                            buffer =
                                CustomerManager.GetCustomerManger(cancelOrder.CustomerId, cancelOrder.BrokerCode).
                                    CancelOrder(msg, _header,
                                                st,
                                                cancelOrder);
                            break;
                        case (int)ServiceType.ViewAccount:
                            CustomerTurnoverQuery customerTurnoverQuery = MSG_ViewAccount.DecodeViewAccountList(msg);
                            buffer =
                                CustomerManager.GetCustomerManger(customerTurnoverQuery.CustomerId,
                                                                  customerTurnoverQuery.BrokerCode).ViewAccount(msg,
                                                                                                                _header,
                                                                                                                st,
                                                                                                                customerTurnoverQuery);
                            break;

                        case (int)ServiceType.CompanyList:
                            StockManager Smanager = new StockManager();
                            //get all company List
                            buffer = Smanager.GetStockList(msg, _header, st);
                            break;

                        case (int)ServiceType.BestOfMarket:
                            using (MarketManager marketManagerBestOf = new MarketManager())
                            {
                                buffer = marketManagerBestOf.GetBestOfMarket(msg, _header, st);
                            }
                            break;

                        case (int)ServiceType.MessageList:
                            using (MessageManager messageManager = new MessageManager())
                            {
                                buffer = messageManager.GetMessageList(msg, _header, st);
                            }
                            break;
                        case (int)ServiceType.MessageDetail:
                            using (MessageManager messageManager = new MessageManager())
                            {
                                buffer = messageManager.GetMessageDetailById(msg, _header, st);
                            }
                            break;
                        case (int)ServiceType.StockQueue:
                            StockManager queueManager = new StockManager();
                            //get queue of any stock
                            buffer = queueManager.GetStockQueue(msg, _header, st);
                            break;

                        case (int)ServiceType.MainIndices:
                            using (MarketManager marketManager = new MarketManager())
                            {
                                buffer = marketManager.GetMainIndices(msg, _header, st);
                            }
                            break;

                        case (int)ServiceType.MarketInfo:
                            using (MarketManager marketManager = new MarketManager())
                            {
                                buffer = marketManager.GetMarketInfo(msg, _header, st);
                            }
                            break;
                        case (int)ServiceType.StockPrice:
                            using (StockManager stockPrice = new StockManager())
                            {
                                buffer = stockPrice.GetStockPrice2(msg, _header, st);
                            }
                            break;


                        case (int)ServiceType.WatchList:
                            using (StockManager watchList = new StockManager())
                            {
                                buffer = watchList.GetWatchList(msg, _header, st);
                            }
                            break;
                        case (int)ServiceType.Logout:
                            LogoutQuery logoutQuery = MSG_Logout.DecodeLogout(msg);
                            CustomerManager.GetCustomerManger(logoutQuery.CustomerId, logoutQuery.BrokerCode).Logout(
                                logoutQuery);
                            break;
                        default:
                            txtEvent.Text = "Error";
                            break;
                    }
                    int count = 0;
                    if (buffer != null)
                        count = buffer.Length;
                    byte[] bufferTmp = new byte[count + 8];

                    Buffer.BlockCopy(Parser.GetInt2Byte(count), 0, bufferTmp, 0, 2);
                    //bufferTmp[0] = ;

                    bufferTmp[2] = _header.SeqNo;
                    bufferTmp[3] = _header.ResponseCode;
                    bufferTmp[4] = 0;
                    bufferTmp[5] = 0;
                    bufferTmp[6] = 0;
                    bufferTmp[7] = Convert.ToByte(_header.ServiceType);
                    if (count > 0)
                    {
                        Buffer.BlockCopy(buffer, 0, bufferTmp, 8, count);
                    }

                    SetControlTextInAThreadSafeWay(txtEvent, "\r\nOutput\n\r");
                    SetControlTextInAThreadSafeWay(txtEvent, BitConverter.ToString(bufferTmp, 0).Replace("-", ","));

                    st.workSocket.Send(bufferTmp);
                    //st.workSocket.Close();
                }
                catch (Exception exception)
                {
                    SetControlTextInAThreadSafeWay(txtEvent, exception.ToString() + "|||||\n\r" + exception.InnerException);
                    byte[] buffer = Parser.StrToByteArray("خطا. در صورت بروز مجدد اشکال با کارگزاری تماس بگیرید");
                    int count = 0;
                    if (buffer != null)
                        count = buffer.Length;
                    byte[] bufferTmp = new byte[count + 8];
                    Buffer.BlockCopy(Parser.GetInt2Byte(count), 0, bufferTmp, 0, 2);
                    //bufferTmp[0] = ;

                    bufferTmp[2] = _header.SeqNo;
                    bufferTmp[3] = 0x02;
                    bufferTmp[4] = 0;
                    bufferTmp[5] = 0;
                    bufferTmp[6] = 0;
                    bufferTmp[7] = Convert.ToByte(_header.ServiceType);
                    if (count > 0)
                    {
                        Buffer.BlockCopy(buffer, 0, bufferTmp, 8, count);
                    }
                }
            }


            //else
            //{ }
        }

        delegate void DelegateWithTwoGenericArguments<T, U>(T tArg, U uArg);
        private void SetControlTextInAThreadSafeWay(Control c, string Text)
        {
            if (c.InvokeRequired)
            {
                DelegateWithTwoGenericArguments<Control, string> d =
                    new DelegateWithTwoGenericArguments<Control, string>(this.SetControlTextInAThreadSafeWay);
                c.Invoke(d, new object[] { c, Text });
            }
            else
            {
                //string st = "";
                //string[] s = Text.Split(',');
                //foreach( string ss in s)
                //    st+=BitConverter.
                c.Text += Text;

            }
        }

        private void frmSocket_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (cancel)
                MessageBox.Show("لطفا برنامه را نبندید", "خطا");
            e.Cancel = cancel;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            cancel = false;
            Application.Exit();
        }

    }
}
