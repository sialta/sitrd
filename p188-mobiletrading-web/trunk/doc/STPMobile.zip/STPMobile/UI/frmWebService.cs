﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Component;
using Component.Component;
using Component.ObjectManager;
using Component.wsOnline;
using Component.wsOnlineRLC;

using WS_Mobile = Component.wsOnlineRLC.WS_Mobile;

namespace UI
{
    public partial class frmWebService : Form
    {
        WS_Mobile wsMobile = RLCService.GetRLCServiceObject();
        public frmWebService()
        {
            InitializeComponent();
            //OMS.Engine.Init();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                label1.Text = DateTime.Now.ToString();
                
                label1.Text += DateTime.Now.ToString();
                //WsPersonInfo personInfo = wsMobile.Login("alavi", "100");
                textBox1.Text=  BitConverter.ToString(Parser.StrToByteArray("100")).Replace("-", ",");
                label1.Text += "\n" + DateTime.Now.ToString();
                //MessageBox.Show(personInfo.CustomerId.ToString());            

            }
            catch (Exception exception)
            {

                MessageBox.Show(exception.Message);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {

                Component.wsOnline.WS_Mobile wsMobile = new Component.wsOnline.WS_Mobile();
                WsPersonInfo personInfo = wsMobile.Login("mfd050671", "jollvy");
                //wsMobile.GetOrderList()
                //MessageBox.Show(wsMobile.GetSymbolPrice("IRO1GDIR0001").ClosingPrice.ToString());
                //MessageBox.Show(Component.Parser.StrToByteArray("IRO1GDIR0001").Length.ToString());

            }
            catch (Exception exception)
            {

                MessageBox.Show(exception.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            WsQueue[] queues = wsMobile.GetSymbolQueue("IRO1BPST0001");
            var query2 = from queue in queues.ToList()
                         where queue.BestBuyPrice != 0
                         select new Queue() { Price = queue.BestBuyPrice, Quantity = queue.BestBuyQuantity, No = queue.NoBestBuy }
                                ;
            List<Queue> Buylist = query2.ToList();
            query2 = null;

            query2 = from queue in queues.ToList()
                     where queue.BestSellPrice != 0
                     select new Queue() { Price = queue.BestSellPrice, Quantity = queue.BestBuyQuantity, No = queue.NoBestSell }
                        ;
            List<Queue> Selllist = query2.ToList();


        }

        private void btnWatchList_Click(object sender, EventArgs e)
        {            
            WsWatchList wsWatchList=new WsWatchList();
            wsWatchList.NSCCode=new string[2];
            wsWatchList.NSCCode[0] = "IRO1GOST0001";
            wsWatchList.NSCCode[1] = "IRO1MKBT0001";
            WsPrice[] prices = wsMobile.GetWatchList(wsWatchList);
            MessageBox.Show(prices.Length.ToString());
        }

        private void btnCompany_Click(object sender, EventArgs e)
        {
            StockManager manager=new StockManager();
            manager.GetStockList(new byte[48], new HeaderMsg(), new StateObject());
        }
    }
}
