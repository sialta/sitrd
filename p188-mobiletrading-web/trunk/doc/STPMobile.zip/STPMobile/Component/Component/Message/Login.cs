﻿namespace Component.Message
{
    public class LoginRequest
    {
        public int LoginRequestFixLength = 5;
        public int BrokerCode =2 ;
        public int UserNameLength = 1;
        public int PasswordLength = 1;
        public int UserName = 0;
        public int Password = 0;
    }

    public class LoginResponse
    {
        public int LoginResponseFixLength = 35;
        public int ServerTime = 4;
        public int Permission = 1;
        public int CustomerId = 4;
        public int IsinCodeLength = 1;
        public int RealBalance = 5;
        public int BlockBalance = 5;

        public int BourseCode = 6;
        public int Setting = 1;
        public int OpenMarketTime = 2;
        public int CloseMarketTime = 2;
        public int MinimumOrderCountForBuy = 2;
        public int MinimumOrderCountForSell = 2;
        public int IsinCode = 0;
        
    }

}
