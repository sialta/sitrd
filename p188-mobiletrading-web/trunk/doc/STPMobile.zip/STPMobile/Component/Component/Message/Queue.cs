﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.Message
{
    public class QueueRequest
    {
        public int FixQueueReuquestLen = 18;
    }

    public class QueueResponse
    {
        public int FixQueueResponseLen = 2;
        public int SellQueueCount = 1;
        public int BuyQueueCount = 1;

        public int QueueResposneItemLength = 10;

        public int BestBuyPriceField=4;
        public int BestSellPriceField=4;
        public int BestSellQuantityField=4;
        public int BestBuyQuantityField=4;
        public int NoBestBuyField=2;
        public int NoBestSellField=2;
    }
}
