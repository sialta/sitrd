﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.Message
{
    public class MainIndicesRequest
    {
        public int FixMainIndicesRequestLen = 6;
    }

    public class MainIndicesResponse
    {
        public int FixIndicesResponseLen = 5;

        public int IndicesCount = 1;
        public int IndicesDateTime = 4;
        
        
        public int IndicesResposneItemLength = 27;
        /// <summary>
        /// indices Item
        /// </summary>
        public int NSCCode = 12;
        public int LatestValueReal = 2;
        public int LatestValueMantissa = 1;
        public int MaxValueReal = 2;
        public int MaxValueMantissa = 1;
        public int MinValueReal = 2;
        public int MinValueMantissa = 1;
        public int ChangeValueReal = 2;
        public int ChangeValueMantissa = 1;
        public int PercentReal = 1;
        public int PercentMantissa = 1;
        public int State = 1;
    }

}
