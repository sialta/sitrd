﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.Message
{
    public class HeaderRequest
    {
        public int HeaderRequestLength = 8;
    }

    public class HeaderResponse
    {
        public int HeaderResponseLength = 8;
    }

}
