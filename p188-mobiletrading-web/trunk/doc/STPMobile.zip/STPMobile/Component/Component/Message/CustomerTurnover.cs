﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.Message
{
    public class CustomerTurnoverListRequest
    {
        public int MessageLength = 8;
        public int BrokerCode = 2;
        public int CustomerId = 4;
        public int PageIndex = 1;
        public int PageSize = 1;
    }

    public class CustomerTurnoverListResponse
    {
        public int TotalRowCount = 2;
        public int PageRowCount = 1;
        public int ResposneItemLength = 1;
        public int CustomerTurnoverListLength = 23;

        public int VoucherType = 1;
        public int VoucherNo = 4;
        public int Balance = 5;
        public int VoucherDate = 2;
        public int Debitor = 5;
        public int Creditor = 5;
        public int DescLength = 1;
    }

}
