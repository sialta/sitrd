﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.Message
{
    public class MarketActivityRequest
    {
        public int FixMarketActivityRequestLen = 6;
    }

    public class MarketActivityResponse
    {
        public int MarketActivityResponseLen = 22;
        public int DateTimeField=4;
        public int TotalNoTradeField=2;
        public int TotalTradeValueField=8;
        public int TotalNoSharesTradedField=8;
    }

}
