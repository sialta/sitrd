﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.Message
{
    public class WatchListRequest
    {
        public int FixWatchListRequestLen = 7;
        public int FixWatchItemLen = 12;
        public int NSCCode = 12;
    }
    public class WatchListResponse
    {
        public int FixWatchListResponseLen = 2;
        public int FixWatchItemResponseLen = 28;

        public int NSCCode = 12;
        public int LastTradedPrice = 4;
        public int TotalNoSharesTradedField = 8;
        public int PriceVarReal = 2;
        public int PriceVarMantissa = 1;
        public int State = 1;
    }
}
