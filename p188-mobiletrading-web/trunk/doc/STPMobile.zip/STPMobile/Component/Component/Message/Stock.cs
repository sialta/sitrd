﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.Message
{
    public class StockPriceRequest
    {
        public int FixStockPriceReuquestLen = 18;
    }

    public class StockPriceResponse
    {
        //public int FixStockResponseLen = 36;
        public int FixStockResponseLen = 33;
        public int State = 1;
        public int LastTradedPrice = 4;
        //public int ChangeValue = 3;
        public int PriceVarReal = 2;
        public int PriceVarMantissa = 1;
        public int ClosePrice = 4;
        public int HighAllowedPrice = 4;
        public int LowAllowedPrice = 4;
        public int MaxAllowedCount= 3;
        public int RealBalance = 5;
        public int BlockBalance = 5;
    }

    public class StockListRequest
    {
        public int StockListRequestLen = 6;
    }

    public class StockListResponse
    {
        public int StockListResponseFixLen = 4;
        public int StockListString = 0;
    } 
}
