﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.Message
{
    public class MessagesDetailRequest
    {
        public int FixMessagesDetailRequestLen = 8;
    }

    public class MessageDetailResponse
    {
        public int FixMessageDetailResponseLen = 4;
        public int MessageId = 2;
        public int MessageLength = 2;
    }
    
    public class MessageListRequest
    {
        public int FixMessageListRequestLen = 10;
    }
    public class MessageListResponse
    {
        public int FixMessageListResponseLen = 1;
        public int FixMessageItemLen = 8;
        public int MessageId = 2;
        public int MessageDate = 4;
        public int MessageTitleLen = 1;
        public int MessageStatus = 1;
    }

}
