﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.Message
{
    public class BestOfMarketRequest
    {
        public int FixBestOfMarketRequestLen = 9;
    }
    public class BestOfMarketResponse
    {
        public int FixBestOfMarketResponseLen = 7;
        public int AllTradedCompanies = 2;
        public int ServerDateTime = 4;
        public int NumberOfItems = 1;
        
        public int FixItemsLen = 23;
        public int NSCCode = 12;
        public int LastTradedPrice = 4;
        public int PriceChange = 3;
        public int PriceVarReal = 2;
        public int PriceVarMantissa = 1;
        public int Status = 1;
    }
}
