﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.Message
{
    public class OrderRequest
    {
        public int FixOrderLength = 35;
    }

    public class OrderResponse
    {
        public int OrderId = 5;
        public int State = 1;

    }
    public class OrderListRequest
    {
        public int OrderListRequestLength = 8;
    }
    public class OrderListResposne
    {
        public int TotalRowCount = 2;
        public int PageRowCount = 1;
        public int ResposneItemLength = 1;
        public int OrderListResposneItemLength = 33;

        public int OrderId = 5;
        public int Symbol = 12;
        public int State = 1;
        public int OrderQuantiy = 3;
        public int ExcutedAmount = 3;
        public int OrderPrice = 4;
        public int OrderState = 1;
        public int ServerTime = 4;

    }

    public class CancelOrderRequest
    {
        public int CancelOrderRequestLength=11;
    }
}
