﻿
#region Using

using System;

#endregion

#region


#endregion

namespace Component
{
    public class Log
    {

        #region Property Members

        #region ActioneDate

        public DateTime ActioneDate { get; set; }

        #endregion

        #region ActionType

        public int ActionType { get; set; }

        #endregion

        #region LogId

        public long LogId { get; set; }

        #endregion

        #region RecordId

        public int RecordId { get; set; }

        #endregion

        #region TableName

        public string TableName { get; set; }

        #endregion

        #endregion

    }
}