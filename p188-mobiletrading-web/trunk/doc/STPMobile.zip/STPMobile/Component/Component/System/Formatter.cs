
#region Using

using System;
using System.Text;
using System.Text.RegularExpressions;

#endregion

namespace Component
{
    /// <summary>
    /// Summary description for Formatter.
    /// </summary>
    /// 
    public class Formatter
    {

        #region Static Members

        #region Field Members

        static Regex regex = new Regex("<[^<>]+>?", RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.Multiline);
        private static Regex isWhitespace = new Regex("[^\\w&;#]", RegexOptions.Singleline | RegexOptions.Compiled);

        #endregion

        #region Method Members

        #region Public Methods

        #region Format

        public static string Format(string input)
        {
            StringBuilder output = new StringBuilder();

            //Lets look for elements/tags
            Match mx = regex.Match(input, 0, input.Length);

            //Never seems to be null
            while (mx.Value != string.Empty)
            {
                //find the first occurence of this elment
                int index = input.IndexOf(mx.Value);

                //add the begining to this tag
                output.Append(input.Substring(0, index));
                output.Append(" ");
                //remove this from the supplied text
                input = input.Remove(0, index);

                //validate the element
                //output.Append(Validate(mx.Value));

                //remove this element from the supplied text
                input = input.Remove(0, mx.Length);


                //Get the next match
                mx = regex.Match(input, 0, input.Length);
            }

            //If not Html is found, we should just place all the input into the output container
            if (input != null && input.Trim().Length > 0)
                output.Append(input);
            return output.ToString();
        }

        #endregion

        #region GetAbstract (string,int)

        public static string GetAbstract(string str, int lenght)
        {
            return GetAbstract(str, lenght, "...");
        }

        #endregion

        #region GetAbstract (string,int,string)

        public static string GetAbstract(string str, int lenght, string extention)
        {
            if (str.Length <= lenght)
                return str;
            return str.Substring(0, lenght) + extention;
        }

        #endregion

        #region MaxLength

        /// <summary>
        /// Limits the lenght of a string and accounts for white spaces
        /// </summary>
        public static string MaxLength(string text, int charLimit)
        {
            if (Globals.IsNullorEmpty(text))
                return string.Empty;

            if (charLimit >= text.Length)
                return text;

            Match match = isWhitespace.Match(text, charLimit);
            if (!match.Success)
                return text;
            else
                return text.Substring(0, match.Index);
        }

        #endregion

        #region RemoveHtml

        public static string RemoveHtml(string html, int charLimit)
        {
            if (string.IsNullOrEmpty(html))
                return string.Empty;

            string nonhtml = spacer.Replace(htmlRegex.Replace(html, " ").Trim(), " ");
            if (charLimit <= 0 || charLimit >= nonhtml.Length)
                return nonhtml;
            else
                return MaxLength(nonhtml, charLimit);
        }

        #endregion

        #region RemoveImage

        public static string RemoveImage(string content)
        {
            string cleanText;


            content =
                Regex.Replace(content, "<img((.|\n)*?)/>", string.Empty,
                              RegexOptions.IgnoreCase | RegexOptions.Multiline);

            return content;
        }

        #endregion

        #region SetValidXml

        public static string SetValidXml(string content)
        {
            content = content.Replace('"', ' ');
            content = content.Replace("<", "&lt;");
            content = content.Replace(">", "&gt;");
            content = Regex.Replace(content, @"&#(\d*)(;)?", new MatchEvaluator(Safe));
            content = content.Replace("&", "&amp;");

            return content;
        }

        #endregion

        #region StripScriptTags

        public static string StripScriptTags(string content)
        {
            string cleanText;

            // Perform RegEx
            content =
                Regex.Replace(content, "<script((.|\n)*?)</script>", "",
                              RegexOptions.IgnoreCase | RegexOptions.Multiline);
            cleanText = Regex.Replace(content, "\"javascript:", "", RegexOptions.IgnoreCase | RegexOptions.Multiline);

            return cleanText;
        }

        #endregion

        #region WarpText

        public static string WarpText(string text, int maxLength)
        {
            if (text.Length < maxLength)
            {
                return text;
            }
            string result = string.Empty;
            for (int i = 0; i < text.Length; i = i + maxLength)
            {
                if (i + maxLength > text.Length)
                {
                    result += text.Substring(i, text.Length - i) + " <br/> ";
                }
                else
                {
                    result += text.Substring(i, maxLength) + " <br/> ";
                }
            }
            return result;
        }

        #endregion

        #endregion

        #region Private Methods

        private static string Safe(Match m)
        {
            int ascii = Convert.ToInt32(m.Groups[1].Value);
            return Convert.ToChar(ascii).ToString();
        }

        #endregion

        #endregion

        #endregion

        #region reusable regex's

        protected static Regex htmlRegex =
            new Regex(@"<[^>]+>|\&nbsp\;|&#(\d+);|&(\w+)(;)?", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        protected static Regex spacer = new Regex(@"\s{2,}", RegexOptions.Compiled);

        #endregion

    }
}