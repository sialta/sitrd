﻿
#region Using

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

#endregion

namespace Component
{
    public  class Globals
    {

        #region Static Members

        #region Property Members

        public static DateTime MinDate
        {
            get { return new DateTime(1907, 1, 1); }
        }

        public static string HostUrl
        {
            get { return HostPath(HttpContext.Current.Request.Url) + ApplicationPath; }
        }

        #endregion

        #region Field Members

        public static Regex _strayAmpRegex = new Regex("&(?!(?:#[0-9]{2,4};|[a-z0-9]+;))",
                                                       RegexOptions.Compiled | RegexOptions.IgnoreCase);
        public static string[] Units =
            new string[] { "", "يک", "دو", "سه", "چهار", "پنج", "شـش", "هفت", "هشت", "نه", "ده" };
        public const double MinMoney = -500000000000000;
        public const double MaxMoney = 500000000000000;
        // the HTML newline character 
        public const String HtmlNewLine = "<br />";

        #endregion

        #region Method Members

        #region ConvrtToValidUniCode

        public static string ConvrtToValidUniCode(string input)
        {
            input = input.Replace("ي", "ی");
            input = input.Replace("ك", "ک");
            return input;
        }

        #endregion

        #region EnsureHtmlEncoded

        public static string EnsureHtmlEncoded(string text)
        {
            text = _strayAmpRegex.Replace(text, "&amp;");
            text = text.Replace("\"", "&quot;");
            text = text.Replace("'", "&#39;");
            text = text.Replace("<", "&lt;");
            text = text.Replace(">", "&gt;");
            return text;
        }

        #endregion     

        //#region FormatDateTime

        //public static string FormatDateTime(DateTime date)
        //{
        //    string strdate = FormatDate(date, string.Empty);
        //    string strtime = date.ToShortDateString();
        //    return string.Format("<span alt='{1}' title='{1}' >{0}<br/></span>", strdate, strtime);
        //}

        //#endregion

        #region FormatNumber

        public static string FormatNumber(string num)
        {
            try
            {
                decimal val = decimal.Parse(num.ToString());
                if (val >= 0)
                {
                    return SeprateNumber(num);
                }
                else
                {
                    string ret = SeprateNumber((-val).ToString());
                    return string.Format("<span class=negative > ({0}) </span>", ret);
                }

            }
            catch (Exception ex)
            {
                return "Value not valid";
            }

        }

        #endregion

        #region FormatTopPriceNumber

        public static string FormatTopPriceNumber(string value)
        {
            Double val = Globals.SafeDouble(value, 0);
            if (val < 0)
                value = value.ToString().Replace("-", "") + "-";

            return value;
        }

        #endregion

        #region GetBourseCode

        public static string GetBourseCode(string haghataghadomBourseCode)
        {
            return haghataghadomBourseCode.Replace("999", string.Empty);
        }

        #endregion

        #region GetCode

        public static string GetCode(string code)
        {
            //string[] tokens = code.Split('-');
            //if (tokens.Length == 3)
            //{
            //    return tokens[2] + '-' + tokens[1] + '-' + tokens[0];
            //}
            //else if (tokens.Length == 2)
            //{
            //    return tokens[1] + '-' + tokens[0];
            //}
            //else 
            return code;

        }

        #endregion

        #region GetDefferntDateWithString

        public static string GetDefferntDateWithString(string beginDate)
        {
            try
            {
                DateTime date = Convert.ToDateTime(beginDate);
                return GetDefferntDate(date, DateTime.Now);
            }
            catch
            {
                return string.Empty;
            }
        }

        #endregion

        #region GetHagetaghadomId

        public static string GetHagetaghadomId(string bourseCode)
        {
            return string.Format("{0}999", bourseCode);
        }

        #endregion

        #region GetLowerPage

        public static int GetLowerPage(int pageSize, int pageIndex)
        {
            return (pageSize * pageIndex) + 1;
        }

        #endregion

        #region GetNowDate

        public static DateTime GetNowDate()
        {
            DateTime date = DateTime.Now;

            return new DateTime(date.Year, date.Month, date.Day);
        }

        public static DateTime GetNowDateTime()
        {
            return DateTime.Now;
        }

        #endregion

        #region GetNowTime

        public static DateTime GetNowTime()
        {

            return Convert.ToDateTime(DateTime.Now.ToShortTimeString());
        }

        #endregion

        #region GetUpperPage

        public static int GetUpperPage(int PageIndex, int PageSize)
        {
            return GetLowerPage(PageIndex, PageSize) + PageSize - 1;
        }

        #endregion

        #region HostPath

        public static string HostPath(Uri uri)
        {
            string portInfo = uri.Port == 80 ? string.Empty : ":" + uri.Port.ToString();
            return string.Format("{0}://{1}{2}", uri.Scheme, uri.Host, portInfo);
        }

        #endregion

        #region IsDate

        public static bool IsDate(Object date)
        {
            if (date == null)
            {
                return false;
            }
            try
            {
                DateTime D = DateTime.Parse(Convert.ToString(date));
                return true;
            }
            catch
            {
                return false;
            }
        }

        #endregion

        #region IsHaghetaghadom

        public static bool IsHaghetaghadom(string bourseCode)
        {
            return (bourseCode.EndsWith("999"));
            //return haghataghadomBourseCode.Replace("999", string.Empty);
        }

        #endregion

        #region IsMatch

        public static bool IsMatch(ICollection Arr, object value)
        {
            bool result = false;
            if (Arr is int[])
            {
                if (((int[])Arr).Length <= 0)
                    return false;
                foreach (int str in (int[])Arr)
                {
                    if (str == (int)value)
                    {
                        return true;
                    }
                }
                return false;
            }
            if (Arr is String[])
            {
                if (((string[])Arr).Length <= 0)
                    return false;
                foreach (string str in (string[])Arr)
                {
                    if ((str.Length > 0) && (str == (string)value))
                    {
                        return true;
                    }
                }
                return false;
            }
            return result;
        }

        #endregion

        #region IsNullorEmpty

        public static bool IsNullorEmpty(string text)
        {
            return text == null || text.Trim() == string.Empty;
        }

        #endregion

        #region IsNumeric

        public static bool IsNumeric(Object num)
        {
            if (num == null)
            {
                return false;
            }
            try
            {
                int n = int.Parse((string)num);
                return true;
            }
            catch
            {
                return false;
            }
        }

        #endregion

        #region IsValidFileName

        public static bool IsValidFileName(string name)
        {
            name = name.Trim().Replace(" ", "_").ToLower();
            string Pattern = @"[^0-9a-zA-Z]";
            return !Regex.IsMatch(name, Pattern);
        }

        #endregion

        #region RemoveMinets

        public static DateTime RemoveMinets(DateTime dt)
        {
            return Convert.ToDateTime(dt.ToShortDateString());
        }

        #endregion

        #region ResolveUrl

        public static string ResolveUrl(string url)
        {
            string result = string.Empty;
            if (url.StartsWith("~"))
            {
                result = SiteSetting.Instance.DomainName + url.Remove(0, 2);
            }
            return result;
        }

        #endregion

        #region Return404

        public static void Return404(HttpContext context)
        {
            context.Response.Status = "404 Not Found";
            context.Response.StatusCode = 404;
            context.Response.Redirect("~/404page.html");
            context.Response.End();
        }

        #endregion

        #region Reverse

        public static string Reverse(string str)
        {
            int len = str.Length;
            char[] arr = new char[len];

            for (int i = 0; i < len; i++)
            {
                arr[i] = str[len - 1 - i];
            }

            return new string(arr);
        }

        #endregion

        #region ReverseMelliNumber

        public static string ReverseMelliNumber(string str)
        {
            string[] arr = str.Split('-');
            if (arr.Length == 3)
            {
                //melli number
                return arr[2] + '-' + arr[1] + '-' + arr[0];
            }
            else if (arr.Length == 2)
            {
                //postal code
                return arr[1] + '-' + arr[0];
            }
            else if (arr.Length == 4)
            {
                return arr[3] + '-' + arr[2] + '-' + arr[1] + '-' + arr[0];
            }
            else return str;
        }

        #endregion

        #region ReversString

        public static string ReversString(string str)
        {
            string[] arr = str.Split(' ');
            string result = string.Empty;
            for (int i = arr.Length; i > 0; i--)
            {
                if (!string.IsNullOrEmpty(arr[i - 1]))
                {
                    result += " " + arr[i - 1];
                }
            }

            return result;
        }

        #endregion

        #region SafeDecimal

        public static decimal SafeDecimal(object text, decimal defaultValue)
        {
            if ((text != null) && (!string.IsNullOrEmpty(text.ToString())))
            {
                try
                {
                    return decimal.Parse(text.ToString());
                }
                catch (Exception)
                {
                }
            }

            return defaultValue;
        }

        #endregion

        #region SafeDouble

        public static double SafeDouble(object text, double defaultValue)
        {
            if ((text != null) && (!string.IsNullOrEmpty(text.ToString())))
            {
                try
                {
                    return double.Parse(text.ToString());
                }
                catch (Exception)
                {
                }
            }

            return defaultValue;
        }

        #endregion

        #region SafeInt

        public static int SafeInt(object text, int defaultValue)
        {
            if ((text != null) && (!string.IsNullOrEmpty(text.ToString())))
            {
                try
                {
                    return Int32.Parse(text.ToString());
                }
                catch (Exception)
                {
                }
            }

            return defaultValue;
        }

        #endregion

        #region SafeLong

        public static long SafeLong(object text, long defaultValue)
        {
            if ((text != null) && (!string.IsNullOrEmpty(text.ToString())))
            {
                try
                {
                    return Int64.Parse(text.ToString());
                }
                catch (Exception)
                {
                }
            }

            return defaultValue;
        }

        #endregion

        #region SafePersianEncode

        public static string SafePersianEncode(string str)
        {
            if (string.IsNullOrEmpty(str))
            {
                return string.Empty;
            }
            str = str.Replace("ي", "ی");
            str = str.Replace("ك", "ک");
            return str;
        }

        #endregion

        #region SafeString

        public static string SafeString(object text, string defaultValue)
        {
            if ((text != null) && (!string.IsNullOrEmpty(text.ToString())))
            {
                try
                {
                    return text.ToString();
                }
                catch (Exception)
                {
                }
            }

            return defaultValue;
        }

        #endregion

        #region SeprateNumber

        public static string SeprateNumber(string v)
        {

            try
            {
                decimal val = decimal.Parse(v.ToString());
                if (val < 0)
                    return string.Format("{0:N0}", val).Replace("-", "") + "-";
                else
                {
                    return string.Format("{0:N0}", val);
                }
            }
            catch (Exception)
            {

                return "Value Not Valid";
            }

        }

        #endregion

        #region UnSafePersianEncode

        public static string UnSafePersianEncode(string str)
        {
            if (string.IsNullOrEmpty(str))
            {
                return string.Empty;
            }
            str = str.Replace("ی", "ي");
            str = str.Replace("ک", "ك");
            return str;
        }

        #endregion

        #endregion

        //#region FormatDate

        //public static string FormatDate(DateTime date)
        //{
        //    return FormatDate(date, "");
        //}

        //public static string FormatDate(DateTime date, string defaultText)
        //{
        //    if (date == DateTime.MinValue)
        //    {
        //        return defaultText;
        //    }
        //    //if (MFContext.Current.CurrentLanguage.ToLower() == "fa")

        //    //    return JalaliDate.GetJalaliDate(date);
        //    //else
        //    //    return date.ToShortDateString();
        //}

        //#endregion

        #region FullPath

        public static string FullPath()
        {
            return FullPath(ApplicationPath);
        }

        public static string FullPath(string local)
        {
            if (IsNullorEmpty(local))
                return local;

            if (local.ToLower().StartsWith("http://"))
                return local;

            if (HttpContext.Current == null)
                return local;

            return FullPath(HostPath(HttpContext.Current.Request.Url), local);
        }

        public static string FullPath(string hostPath, string local)
        {
            return hostPath + local;
        }

        #endregion

        #region GetDefferntDate

        public static string GetDefferntDate(DateTime beginDate)
        {
            return GetDefferntDate(beginDate, DateTime.Now);
        }

        public static string GetDefferntDate(DateTime beginDate, DateTime endDate)
        {
            DateTime dDate = JalaliDate.GetDefferntDate(beginDate, endDate);
            string result = string.Empty;
            if ((dDate.Day > 1) || (dDate.Hour > 9))
            {
                return JalaliDate.GetJalaliDate(beginDate);
            }

            else
            {
                if (dDate.Hour + 1 > 10)
                    result = string.Format("{0} ساعت پيش ", Units[dDate.Hour + 1]);
                else
                    return JalaliDate.GetJalaliDate(beginDate);
            }
            return result;
        }

        #endregion

        #region GetPercent

        public static Double GetPercent(Double val)
        {
            return Math.Floor(val / 100);
        }

        public static Double GetPercent(Double val, double baseval, int digit)
        {
            double p = Math.Round((val * 100 / baseval), digit);

            return p;
        }

        #endregion

        #region SafeDate

        public static DateTime SafeDate(object text)
        {
            return SafeDate(text, MinDate);
        }

        public static DateTime SafeDate(object text, DateTime defaultValue)
        {
            if ((text != null) && (!string.IsNullOrEmpty(text.ToString())))
            {
                try
                {
                    return DateTime.Parse(text.ToString());
                }
                catch (Exception)
                {
                }
            }

            return defaultValue;
        }

        #endregion

        #endregion

        #region Encode/Decode

        /// <summary>
        /// Converts a prepared subject line back into a raw text subject line.
        /// </summary>
        /// <param name="textToFormat">The prepared subject line.</param>
        /// <returns>A raw text subject line.</returns>
        /// <remarks>This function is only needed when editing an existing message or when replying to
        /// a message - it turns the HTML escaped characters back into their pre-escaped status.</remarks>
        public static string HtmlDecode(String textToFormat)
        {
            if (IsNullorEmpty(textToFormat))
                return textToFormat;

            //ScottW: Removed Context dependency
            return HttpUtility.HtmlDecode(textToFormat);
            // strip the HTML - i.e., turn < into &lt;, > into &gt;
            //return HttpContext.Current.Server.HtmlDecode(FormattedMessageSubject);
        }

        /// <summary>
        /// Converts a prepared subject line back into a raw text subject line.
        /// </summary>
        /// <param name="textToFormat">The prepared subject line.</param>
        /// <returns>A raw text subject line.</returns>
        /// <remarks>This function is only needed when editing an existing message or when replying to
        /// a message - it turns the HTML escaped characters back into their pre-escaped status.</remarks>
        public static string HtmlEncode(String textToFormat)
        {
            // strip the HTML - i.e., turn < into &lt;, > into &gt;

            if (IsNullorEmpty(textToFormat))
                return textToFormat;

            //ScottW: Removed Context dependency
            return HttpUtility.HtmlEncode(textToFormat);
            //return HttpContext.Current.Server.HtmlEncode(FormattedMessageSubject);
        }

        public static string UrlEncode(string urlToEncode)
        {
            if (IsNullorEmpty(urlToEncode))
                return urlToEncode;

            return HttpUtility.UrlEncode(urlToEncode);
        }

        public static string UrlDecode(string urlToDecode)
        {
            if (IsNullorEmpty(urlToDecode))
                return urlToDecode;

            return HttpUtility.UrlEncode(urlToDecode);
        }

        public static string RemoveLine(string str)
        {
            if (IsNullorEmpty(str))
                return str;
            str = str.Replace("\r", "");
            str = str.Replace("\t", "");
            return str.Replace("\n", "");
        }

        #endregion

        #region Skin/App Paths

        public static string ApplicationPath
        {
            get
            {
                string applicationPath = "/";

                if (HttpContext.Current != null)
                    applicationPath = HttpContext.Current.Request.ApplicationPath;

                // Are we in an application?
                //
                if (applicationPath == "/")
                {
                    return string.Empty;
                }
                else
                {
                    return applicationPath;
                }
            }
        }
   
        #endregion

        #region Html & Xsl

        public static TextReader GetTextReader(string XmlData)
        {
            TextReader stringReader = new StringReader(XmlData);
            return stringReader;
        }

        public static string GetHtml(string XslPath, XmlReader XmlData)
        {
            return GetHtml(XslPath, null, XmlData);
        }

        public static string GetHtml(string XslPath, TextReader XmlData)
        {
            return GetHtml(XslPath, XmlData, false);
        }

        public static string GetHtml(string XslPath, TextReader XmlData, bool ProcessHtmlNewLine)
        {
            return GetHtml(XslPath, null, XmlData, ProcessHtmlNewLine);
        }

        public static string GetHtml(string XslPath, XsltArgumentList arg, TextReader XmlData)
        {
            return GetHtml(XslPath, arg, XmlData, false);
        }

        public static string GetHtml(string XslPath, XsltArgumentList arg, TextReader XmlData, bool ProcessHtmlNewLine)
        {
            try
            {
                if (XmlData == null)
                    return string.Empty;
                StringBuilder sb = new StringBuilder();
                StringWriter HtmlResult = new StringWriter(sb);

                XslCompiledTransform transform = new XslCompiledTransform();
                transform.Load(XslPath);
                XPathDocument xpathDoc = new XPathDocument(XmlData);
                transform.Transform(xpathDoc, arg, HtmlResult);
                if (ProcessHtmlNewLine)
                    return sb.ToString().Replace("\n", "<br/>");
                else
                    return sb.ToString();
            }
            catch (Exception ex)
            {
                //EventLogs.Debug(ex.Message, "GetHtml", -5001);
                return null;
            }
        }

        public static string GetHtml(string XslPath, XsltArgumentList arg, XmlReader XmlData)
        {
            try
            {
                if (XmlData == null)
                    return string.Empty;
                StringBuilder sb = new StringBuilder();
                StringWriter HtmlResult = new StringWriter(sb);

                XslCompiledTransform transform = new XslCompiledTransform();
                //XslTransform transform = new XslTransform();
                transform.Load(XslPath);
                XPathDocument xpathDoc = new XPathDocument(XmlData);
                transform.Transform(xpathDoc, arg, HtmlResult);
                return sb.ToString();
            }
            catch (Exception ex)
            {
                //EventLogs.Warn(ex.Message, "GetHtml", -5002);
                return null;
            }
        }

        public static string GetHtml(string XslPath, XsltArgumentList arg, XPathDocument XmlData)
        {
            try
            {
                if (XmlData == null)
                    return string.Empty;
                StringBuilder sb = new StringBuilder();
                StringWriter HtmlResult = new StringWriter(sb);
                XslCompiledTransform transform = new XslCompiledTransform();
                transform.Load(XslPath);
                transform.Transform(XmlData, arg, HtmlResult);
                return sb.ToString();
            }
            catch (Exception ex)
            {
                //EventLogs.Warn(ex.Message, "GetHtml", -5002);
                return null;
            }
        }

        public static string GetHtml(string XslPath, XsltArgumentList arg, string XmlData)
        {
            TextReader stringReader = new StringReader(XmlData);
            return GetHtml(XslPath, arg, stringReader);
        }

        public static string GetHtml(string XslPath, string XmlData)
        {
            TextReader stringReader = new StringReader(XmlData);
            return GetHtml(XslPath, null, stringReader);
        }

        public static byte[] GetWord(XmlReader xmlData, XsltArgumentList args, string xsltPath)
        {
            // Initialize needed variables
            XslCompiledTransform xslt = new XslCompiledTransform();

            using (MemoryStream swResult = new MemoryStream())
            {
                // Load XSLT to reader and perform transformation
                xslt.Load(xsltPath);
                xslt.Transform(xmlData, args, swResult);

                return swResult.ToArray();
            }
        }

        #endregion

        public static string GetVersion()
        {
            string key = "version";
            string ver = SKHCache.Get(key) as string;
            if(string.IsNullOrEmpty(ver))
            {
                Globals g=new Globals();
                ver = Assembly.GetAssembly(g.GetType()).GetName().Version.ToString();
            }

            return ver;
        }

        public static DateTime NowDateTime()
        {
            return DateTime.Now;
        }

        public static string GetStringTime(DateTime dt)
        {
            string strtm = "";
            if (dt.Hour < 10)
                strtm = "0" + dt.Hour.ToString();
            else
                strtm = dt.Hour.ToString();

            if (dt.Minute < 10)
                strtm += "0" + dt.Minute.ToString();
            else
                strtm += dt.Minute.ToString();

            if (dt.Second < 10)
                strtm += "0" + dt.Second.ToString();
            else
                strtm += dt.Second.ToString();
            return strtm;
        }

    }
}