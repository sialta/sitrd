
#region Using

using System;
using System.Collections.Specialized;
using System.Globalization;
using System.Reflection;
using System.Web;

#endregion

namespace Component
{
    public class SiteSetting
    {

        #region Field Members

        #region Variable Members

        private int _eventIDForUserActivity = 31;
        private double _gatheringsCostLimitation = 10000;
        private HttpContext _httpContext;
        private bool _isLock = false;
        private string smtpPortNumber = "21";
        private string smtpServer = ".";
        private string titlePage = string.Empty;

        private string _BrokerName = string.Empty;
        private bool _IsActiveWebSite = true;
        private string _MessageForDeActiveWebSite = "SiteIsDisable";
        private double _ValueConditionRange4Buy = 0.04;
        private double _ValueConditionRange4TBuy = 0.04;
        private int _DateConditionRange4Buy = 3;
        private int _DateConditionRange4Sell = 3;
        private double _MinAmountBuy = 1000000;
        private int _MinCountBuy = 50;
        private int _MinCountSell = 50;

        public int MinCountSell
        {
            get { return _MinCountSell; }
            set { _MinCountSell = value; }
        }

        private int _MaxCountSell = 50;
        private bool TEnable4Buy = false;
        private bool _BuyWithoutBalance = false;

        public bool BuyWithoutBalance
        {
            get { return _BuyWithoutBalance; }
            set { _BuyWithoutBalance = value; }
        }


        public bool Enable4Buy
        {
            get { return TEnable4Buy; }
            set { TEnable4Buy = value; }
        }

        private int _IEUser = 0;

        #endregion

        #endregion

        #region Ctors

        public SiteSetting()
        {

        }

        #endregion

        #region SiteSetting (int)

        public SiteSetting( string sqlConn)
        {
            BindSetting(1, sqlConn);
        }
        //public SiteSetting(int fundId)
        //{
        //    BindSetting(fundId,string.Empty);
        //}

        #endregion


        #region Property Members

        #region AdminEmailAddress

        public string AdminEmailAddress { get; set; }

        #endregion

        #region DomainName

        public string DomainName { get; set; }

        #endregion


        #endregion

        

        #region MailAgent

        public string MailAgent { get; set; }

        #endregion

        

        

        #region SmtpServerPassword

        public string SmtpServerPassword { get; set; }

        #endregion

        #region SmtpServerRequiredLogin

        public bool SmtpServerRequiredLogin { get; set; }

        #endregion

        #region SmtpServerUserName

        public string SmtpServerUserName { get; set; }

        #endregion

        #region SmtpServerUsingNtlm

        public bool SmtpServerUsingNtlm { get; set; }

        #endregion

        #region TitlePage

        public string TitlePage
        {
            get { return titlePage; }
            set { titlePage = value; }
        }

        #endregion

        #region Method Members

        private void BindSetting(int fundId, string sqlconn)
        {
            _httpContext = HttpContext.Current;
            Type settingsType = GetType();
            StringDictionary dic = CommonDataProvider.Instance().GetSiteSetting(fundId, sqlconn);
            foreach (string k in dic.Keys)
            {
                //------------------------------------------------------------
                //	Extract the setting's name/value pair
                //------------------------------------------------------------
                string name = k;
                string value = dic[k];

                //------------------------------------------------------------
                //	Enumerate through public properties of this instance
                //------------------------------------------------------------
                foreach (PropertyInfo propertyInformation in settingsType.GetProperties())
                {
                    //------------------------------------------------------------
                    //	Determine if configured setting matches current setting based on name
                    //------------------------------------------------------------
                    if (propertyInformation.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                    {
                        //------------------------------------------------------------
                        //	Attempt to apply configured setting
                        //------------------------------------------------------------
                        try
                        {
                            propertyInformation.SetValue(this,
                                                         Convert.ChangeType(value, propertyInformation.PropertyType,
                                                                            CultureInfo.CurrentCulture), null);
                        }
                        catch
                        {
                            // TODO: Log exception to a common logging framework?
                        }
                        break;
                    }
                }
            }
        }

        #endregion

        #region Static Members

        #region Property Members

        public static SiteSetting Instance
        {
            get
            {
                SiteSetting temp = SKHCache.Get(key) as SiteSetting;
                if (temp == null)
                {
                    temp = new SiteSetting();
                    SKHCache.Insert(key, temp);
                }
                return temp;
            }
        }

        #endregion

        #region Field Members

        private static string key = "key";
        private static SiteSetting blogSettingsSingleton;

        #endregion

        #region Method Members

        public static SiteSetting GetSiteSetting()
        {
            return new SiteSetting();
        }

        public static void Reset()
        {
            blogSettingsSingleton = null;
        }

        public static void SaveSetting(SiteSetting setting, int fundId)
        {
            CommonDataProvider.Instance().SaveSiteSetting(setting, fundId);
            blogSettingsSingleton = null;
            SKHCache.Remove(key);
        }

        #endregion

        #endregion


        public bool IsActiveWebSite
        {
            get { return _IsActiveWebSite; }
            set { _IsActiveWebSite = value; }
        }

        public string MessageForDeActiveWebSite
        {
            get { return _MessageForDeActiveWebSite; }
            set { _MessageForDeActiveWebSite = value; }
        }

        public double ValueConditionRange4Buy
        {
            get { return _ValueConditionRange4Buy; }
            set { _ValueConditionRange4Buy = value; }
        }

        public double ValueConditionRange4TBuy
        {
            get { return _ValueConditionRange4TBuy; }
            set { _ValueConditionRange4TBuy = value; }
        }

        public int DateConditionRange4Buy
        {
            get { return _DateConditionRange4Buy; }
            set { _DateConditionRange4Buy = value; }
        }

        public int DateConditionRange4Sell
        {
            get { return _DateConditionRange4Sell; }
            set { _DateConditionRange4Sell = value; }
        }

        public double MinAmountBuy
        {
            get { return _MinAmountBuy; }
            set { _MinAmountBuy = value; }
        }

        public int MinCountBuy
        {
            get { return _MinCountBuy; }
            set { _MinCountBuy = value; }
        }

        public int MaxCountSell
        {
            get { return _MaxCountSell; }
            set { _MaxCountSell = value; }
        }


    }
}