
#region Using

using System;

#endregion

namespace Component
{

    #region Enum Members

    public enum EventType
    {
        Information = 0,
        Warning = 1,
        Error = 2,
        Debug = 3,
        UserActivity = 4
    }

    #endregion

    public class EventLogEntry
    {

        #region Field Members

        #region Variable Members

        private EventType _et = EventType.Information;
        private DateTime _eventDate;
        private int _eventid, _entryid;
        private string _ipaddress = "-1.0.0.0";
        private string _message, _category, _machineName;
        private string _url = "NoNo";
        private string _userName;

        #endregion

        #endregion

        #region Property Members

        #region Category

        public string Category
        {
            get { return _category; }
            set { _category = value; }
        }

        #endregion

        #region EntryID

        public int EntryID
        {
            get { return _entryid; }
            set { _entryid = value; }
        }

        #endregion

        #region EventDate

        public DateTime EventDate
        {
            get { return _eventDate; }
            set { _eventDate = value; }
        }

        #endregion

        #region EventID

        public int EventID
        {
            get { return _eventid; }
            set { _eventid = value; }
        }

        #endregion

        #region EventType

        public EventType EventType
        {
            get { return _et; }
            set { _et = value; }
        }

        #endregion

        #region IpAddress

        public string IpAddress
        {
            get { return _ipaddress; }
            set { _ipaddress = value; }
        }

        #endregion

        #region MachineName

        public string MachineName
        {
            get { return _machineName; }
            set { _machineName = value; }
        }

        #endregion

        #region Message

        public string Message
        {
            get { return _message; }
            set { _message = value; }
        }

        #endregion

        #region Url

        public string Url
        {
            get { return _url; }
            set { _url = value; }
        }

        #endregion

        #region UserName

        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        #endregion

        #endregion

    }
}