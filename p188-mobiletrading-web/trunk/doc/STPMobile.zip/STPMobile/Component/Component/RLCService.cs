﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using Component.wsOnlineRLC;

namespace Component.Component
{
  public  class RLCService
    {
      public static WS_Mobile GetRLCServiceObject()
      {
          wsOnlineRLC.WS_Mobile wsMobile = new wsOnlineRLC.WS_Mobile();

          wsMobile.Url = ConfigurationManager.AppSettings["wsRLC"];
          wsMobile.CookieContainer = new CookieContainer();
          return wsMobile;
      }
    }
}
