﻿using System.Runtime.InteropServices;
using System;

namespace Component
{

    /// <summary>
    /// سفارش خرید/فروش
    /// </summary>
    [StructLayout(LayoutKind.Sequential, Size = 33, Pack = 1, CharSet = CharSet.Ansi)]
    public class Order
    {
        public Int16 BrokerCode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public byte[] NscCode;

        public byte Status;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public byte[] OrderTotalQuantity;
        
        public Int32 OrderPrice;
     
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public byte[] MinimumQuantity;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
        public byte[] MaxShown;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public byte[] OrderValidity;

        public Int32 CustomerId;

        public byte IsinLength;

    }

    [StructLayout(LayoutKind.Sequential, Size = 8, Pack = 1, CharSet = CharSet.Ansi)]
    public class HeaderMessage
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public byte[] MessageLenght;
        public byte SeqNo = 0;
        public byte ResponseCode = 0;
        public short EncryptionKey = 0;
        public byte Flags = 0;
        public byte ServiceType = 0;
    }

    [StructLayout(LayoutKind.Sequential, Size = 8, Pack = 1, CharSet = CharSet.Ansi)]
    public class CustomerAccountList
    {
        public Int16 BrokerCode;
        public Int32 CustomerId;
        public byte PageNo;
        public byte PageSize;
    }

    [StructLayout(LayoutKind.Sequential, Size = 8, Pack = 1, CharSet = CharSet.Ansi)]
    public class OrderList
    {
        public Int16 BrokerCode;
        public Int32 CustomerId;
        public byte PageNo;
        public byte PageSize;
    }

    [StructLayout(LayoutKind.Sequential, Size = 4, Pack = 1, CharSet = CharSet.Ansi)]
    public class FirstLogin
    {
        public Int16 BrokerCode;
        public byte Version;
        public byte UserLen;
        public byte PassLen;
    }

    [StructLayout(LayoutKind.Sequential, Size = 18, Pack = 1, CharSet = CharSet.Ansi)]
    public class StockPrice
    {
        public Int16 BrokerCode;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public byte[] NscCode;
        public Int32 CustomerId;
    }

    [StructLayout(LayoutKind.Sequential, Size = 18, Pack = 1, CharSet = CharSet.Ansi)]
    public class StockQueue
    {
        public Int16 BrokerCode;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        public byte[] NscCode;
        public Int32 CustomerId;
    }

    [StructLayout(LayoutKind.Sequential, Size = 11, Pack = 1)]
    public class CancelOrder
    {
        public Int16 BrokerCode;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public byte[] OrderId;
        public Int32 CustomerId;
    }

    [StructLayout(LayoutKind.Sequential, Size = 6, Pack = 1)]
    public class Logout
    {
        public Int16 BrokerCode;
        public Int32 CustomerId;
    }

    [StructLayout(LayoutKind.Sequential, Size = 6, Pack = 1)]
    public class MainIndices
    {
        public Int16 BrokerCode;
        public Int32 CustomerId;
    }

    [StructLayout(LayoutKind.Sequential, Size = 7, Pack = 1)]
    public class WatchList
    {
        public Int16 BrokerCode;
        public Int32 CustomerId;
        public byte WatchListCount;
    }

    [StructLayout(LayoutKind.Sequential, Size = 6, Pack = 1, CharSet = CharSet.Ansi)]
    public class StockList
    {
        public Int16 BrokerCode;        
        public Int32 CustomerId;
    }

    [StructLayout(LayoutKind.Sequential, Size = 6, Pack = 1)]
    public class MarketActivity
    {
        public Int16 BrokerCode;
        public Int32 CustomerId;
    }
    [StructLayout(LayoutKind.Sequential, Size = 9, Pack = 1, CharSet = CharSet.Ansi)]
    public class BestOfMarket
    {
        public Int16 BrokerCode;
        public Int32 CustomerId;
        public byte PageNo;
        public byte PageSize;
        public byte Status;
    }

    [StructLayout(LayoutKind.Sequential, Size = 11, Pack = 1, CharSet = CharSet.Ansi)]
    public class MessageList
    {
        public Int16 BrokerCode;
        public Int32 CustomerId;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public byte[] LastMessageDateTime;
        public byte Status;
    }

    [StructLayout(LayoutKind.Sequential, Size = 8, Pack = 1, CharSet = CharSet.Ansi)]
    public class MessageDetailById
    {
        public Int16 BrokerCode;
        public Int32 CustomerId;
        public Int16 MessageId;
    }
}