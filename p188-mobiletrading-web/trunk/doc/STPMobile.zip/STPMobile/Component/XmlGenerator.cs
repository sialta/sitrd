﻿
#region Using

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Web.UI;
using System.Xml;
using System.Xml.Serialization;

#endregion

namespace Component
{
    public class XmlGenerator
    {

        #region Static Members

        #region Method Members

        public static string ToXml(Object obj, bool FullFlag)
        {
            StringBuilder SB = new StringBuilder();
            StringWriter SW = new StringWriter(SB);
            HtmlTextWriter W = new HtmlTextWriter(SW);

            Object o; //=Activator.CreateInstance(this.GetType());
            o = obj;

            PropertyInfo[] myPropertyInfo;

            myPropertyInfo = obj.GetType().GetProperties();

            if (FullFlag) W.WriteFullBeginTag(o.GetType().FullName.ToLower());

            for (int i = 0; i < myPropertyInfo.Length; i++)
            {
                W.WriteFullBeginTag(myPropertyInfo[i].Name.ToLower());
                if (myPropertyInfo[i].PropertyType == typeof(DateTime))
                {
                    W.Write(((DateTime)myPropertyInfo[i].GetValue(o, null)).ToString("yyyy-MM-dd"));

                }
                else
                {
                    W.Write(myPropertyInfo[i].GetValue(o, null));

                }
                W.WriteEndTag(myPropertyInfo[i].Name.ToLower());
            }

            if (FullFlag) W.WriteEndTag(o.GetType().FullName.ToLower());

            return SW.ToString();
        }

        #endregion

        #endregion

    }
}