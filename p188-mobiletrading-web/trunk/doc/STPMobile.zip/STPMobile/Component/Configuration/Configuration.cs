
#region Using

using System;
using System.Collections;
using System.IO;
using System.Web;
using System.Web.Caching;
using System.Xml;

#endregion

namespace Component
{
    /// <summary>
    /// Summary description for Configuration.
    /// </summary>
    public class Configuration
    {

        #region Property Members

        #region ApplicationOverride

        public string ApplicationOverride
        {
            get { return applicationOverride; }
        }

        #endregion

        #region CacheFactor

        public int CacheFactor
        {
            get { return cacheFactor; }
        }

        #endregion

        #region Extensions

        public Hashtable Extensions
        {
            get { return extensions; }
        }

        #endregion

        #region FilesPath

        public string FilesPath
        {
            get { return filesPath; }
        }

        #endregion

        #region IsBackgroundThreadingDisabled

        public bool IsBackgroundThreadingDisabled
        {
            get { return disableBackgroundThreads; }
        }

        #endregion

        #region Providers

        public Hashtable Providers
        {
            get { return providers; }
        }

        #endregion

        #region SmtpServerConnectionLimit

        public short SmtpServerConnectionLimit
        {
            get { return smtpServerConnectionLimit; }
        }

        #endregion

        #endregion

        #region Method Members

        internal void GetProviders(XmlNode node, Hashtable table)
        {
            foreach (XmlNode provider in node.ChildNodes)
            {
                switch (provider.Name)
                {
                    case "add":
                        table.Add(provider.Attributes["name"].Value, new Provider(provider.Attributes));
                        break;

                    case "remove":
                        table.Remove(provider.Attributes["name"].Value);
                        break;

                    case "clear":
                        table.Clear();
                        break;
                }
            }
        }

        internal void LoadValuesFromConfigurationXml()
        {
            XmlNode node = GetConfigSection("Web/Core");


            XmlAttributeCollection attributeCollection = node.Attributes;
            XmlAttribute att;
            att = attributeCollection["cacheFactor"];
            if (att != null)
                cacheFactor = Int32.Parse(att.Value);
            else
                cacheFactor = 5;



            att = attributeCollection["applicationOverride"];
            if (att != null)
                applicationOverride = att.Value;
            else
                applicationOverride = null;

            att = attributeCollection["smtpServerConnectionLimit"];
            if (att != null)
                smtpServerConnectionLimit = Convert.ToInt16(att.Value);
            else
                smtpServerConnectionLimit = 10;




            foreach (XmlNode child in node.ChildNodes)
            {
                if (child.Name == "providers")
                    GetProviders(child, providers);

                if (child.Name == "extensionModules")
                    GetProviders(child, extensions);
            }
        }

        #endregion

        #region Static Members

        #region Field Members

        public static Configuration Cache = null;
        public static readonly string CacheKey = "Configuration";

        #endregion

        #endregion

        #region private members

        private int cacheFactor = 5;
        //private PasswordTypeStatus membershipPasswordFormat;// = PasswordTypeStatus.Hashed;
        private Hashtable providers = new Hashtable();
        private Hashtable extensions = new Hashtable();
        private const bool disableBackgroundThreads = false;

        private string applicationOverride = null;
        private const string filesPath = "/";

        private XmlDocument XmlDoc = null;

        private short smtpServerConnectionLimit;

        #endregion

        #region cnstr

        public Configuration(XmlDocument doc)
        {
            XmlDoc = doc;
            LoadValuesFromConfigurationXml();
        }

        #endregion

        #region GetXML

        /// <summary>
        /// Enables reading of the configuration file's XML without reloading the file
        /// </summary>
        /// <param name="nodePath"></param>
        /// <returns></returns>
        public XmlNode GetConfigSection(string nodePath)
        {
            return XmlDoc.SelectSingleNode(nodePath);
        }

        #endregion

        #region GetConfig

        public static Configuration GetConfig()
        {
            Configuration config = SKHCache.Get(CacheKey) as Configuration;
            if (config == null)
            {
                string path;
                if (HttpContext.Current != null)
                    path = HttpContext.Current.Server.MapPath("~/App_Data/Site.config");
                else
                    path = Directory.GetCurrentDirectory() + Path.DirectorySeparatorChar + "Site.config";

                XmlDocument doc = new XmlDocument();
                doc.Load(path);
                config = new Configuration(doc);
                SKHCache.Max(CacheKey, config, new CacheDependency(path));

                SKHCache.ReSetFactor(config.CacheFactor);
            }
            return config;
        }

        #endregion

        //public string DomainName
        //{
        //    get { return domainName; }
        //}




    }
}