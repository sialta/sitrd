﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class MSG_BuyRequest : Parser
    {
        //public static Request DecodeBuyRequest(byte[] msg)
        //{
        //    byte[] BodyMsg = new byte[19];
        //    Array.Copy(msg, 8, BodyMsg, 0, 19);

        //    Request req = new Request();
        //    req.RequestType = RequestType.Buy;

        //    BuyRequest buyMsg = (BuyRequest)RawDataToObject(ref BodyMsg, typeof(BuyRequest));

        //    Int16 CompanyCode = BitConverter.ToInt16(buyMsg.CompanyCode, 0);
        //    req.Stock.StockId = CompanyCode;

        //    int compType = buyMsg.Status & 2;

        //    if (compType == 2)
        //    {
        //        req.Stock.Type = StockType.HaghTaghadom;
        //    }
        //    else
        //    {
        //        req.Stock.Type = StockType.Stock;
        //    }

        //    int i = buyMsg.Status & 4;
        //    if (i == 4)
        //        req.Stock.StockId *= -1;

        //    int ReqType = buyMsg.Status & 1;
        //    long CountOrVal = ParseByteToInt64(buyMsg.ReqCountOrValue);

        //    if (ReqType == 1)
        //    {
        //        req.QuantityFirstEntered = true;
        //        req.EnteredPrice = req.RemainedPrice = CountOrVal;
        //    }
        //    else
        //    {
        //        req.QuantityFirstEntered = false;
        //        req.EnteredNumber = req.RemainedNumber = Convert.ToInt32(CountOrVal);
        //    }

        //    req.FromDate = req.RequestDate = Globals.GetNowDateTime();
        //    req.UntilDate = ParseByteToDate(buyMsg.UntilDate);
        //    req.PriceLimit = ParseByteToInt32(buyMsg.MaxPrice);
        //    req.Customer.BourseCode = MSG_BourseCode.DecodeBourseCode(buyMsg.BourseCode);
        //    byte[] AccCode = new byte[buyMsg.AccCodeLen];
        //    Array.Copy(msg, 27, AccCode, 0, buyMsg.AccCodeLen);
        //    req.Customer.AccountCode = MSG_AccountCode.DecodeAccountCode(AccCode);
        //    req.RequestFrom = RequestFromType.SMS;
        //    req.FinalState = RequestFinalState.Waiting;
        //    return req;
        //}

    }
}
