﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class MSG_Tops : Parser
    {
        public static TopsQuery DecodeMsgTops(byte[] msg)
        {
            byte[] bodyMsg = new byte[4];
            Array.Copy(msg, 8, bodyMsg, 0, 4);
            TopRequest ca = (TopRequest)RawDataToObject(ref bodyMsg, typeof(TopRequest));

            TopsQuery query=new TopsQuery();
            query.PageIndex = ca.PageNo;
            query.PageSize = ca.PageSize;
            query.State = ca.State;

            byte[] accCode = new byte[ca.AccCodeLen];
            Array.Copy(msg, 11, accCode, 0, ca.AccCodeLen);
            query.AccountCode = MSG_AccountCode.DecodeAccountCode(accCode);
            return query;
        }
    }
}
