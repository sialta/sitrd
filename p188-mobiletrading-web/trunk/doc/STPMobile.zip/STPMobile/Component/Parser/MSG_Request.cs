﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using Component.wsOnline;
using Component.Message;
using Component.wsOnline;

namespace Component
{
    public class MSG_Request:Parser
    {
        public static Order DecodeMessage(byte[] msg)
        {
            OrderRequest orderRequest=new OrderRequest();
            byte[] BodyMsg = new byte[orderRequest.FixOrderLength];
            Array.Copy(msg, 8, BodyMsg, 0, orderRequest.FixOrderLength);

            
            Order orderMsg = (Order) RawDataToObject(ref BodyMsg, typeof (Order));

            //WsOrderMessage bom = ConvertOrderToWsOrderMessage(orderRequest, msg, orderMsg);
            return orderMsg;
        }

        public static WsOrderMessage ConvertOrderToWsOrderMessage(byte[] msg, Order orderMsg)
        {
            OrderRequest orderRequest = new OrderRequest();
            WsOrderMessage bom = new WsOrderMessage();
            bom.BrokerId = orderMsg.BrokerCode;
            ExchangeSymbols exchangeSymbols = new ExchangeSymbols();
            exchangeSymbols.NSCCode = ByteArrayToStr(orderMsg.NscCode);
            bom.ExchangeSymbols = exchangeSymbols;
            DateTime dateTime = Globals.NowDateTime();
            bom.OrderEntryDate = dateTime;

            bom.OrderPrice = Globals.SafeDecimal(orderMsg.OrderPrice,-1);
            bom.OrderTotalQuantity = ParseByteToInt32(orderMsg.OrderTotalQuantity);
            int state = orderMsg.Status;
            int tmp = state;
            tmp &= 1;
            if (tmp == 1)
                bom.OrderSide =  WsOrderSide.Sell;
            else if(tmp==0)
                bom.OrderSide = WsOrderSide.Buy;
            else
                bom.OrderSide = WsOrderSide.None;

            tmp &= 56;
            //MobileOrderType orderType = (MobileOrderType) tmp;
            //bom.OrderType = (OrderType)Enum.Parse(typeof(OrderType), orderType.ToString());
            bom.OrderValidity = 74;
            bom.OrderValidityDate = DateTime.Now;  // Parser.ParseByteToDate(orderMsg.OrderValidity);
            bom.TriggerPrice = 0;
            bom.MinimumQuantity = Parser.ParseByteToInt32(orderMsg.MinimumQuantity);
            bom.MaxShown = Parser.ParseByteToInt32(orderMsg.MaxShown);
            
            byte[] isinCode = new byte[orderMsg.IsinLength];
            Array.Copy(msg, orderRequest.FixOrderLength+ 8, isinCode, 0, isinCode.Length);
            bom.IsinCode = Parser.ByteArrayToStr(isinCode);
            bom.CustomerId = orderMsg.CustomerId;
            return bom;
        }

        public static RequestQuery DecodeViewRequestList(byte[] msg)
        {
            OrderListRequest orderListRequest=new OrderListRequest();
            byte[] BodyMsg = new byte[orderListRequest.OrderListRequestLength];
            Array.Copy(msg, 8, BodyMsg, 0, orderListRequest.OrderListRequestLength);

            OrderList ca = (OrderList)RawDataToObject(ref BodyMsg, typeof(OrderList));

            RequestQuery query = new RequestQuery();
            query.BrokerCode = ca.BrokerCode;
            query.CustomerId = ca.CustomerId;
            query.PageIndex = ca.PageNo;
            query.PageSize = ca.PageSize;
            return query;
        }

        public static RequestQuery DecodeCancelOrder(byte[] msg)
        {
            CancelOrderRequest cancelOrderRequest=new CancelOrderRequest();
            byte[] BodyMsg = new byte[cancelOrderRequest.CancelOrderRequestLength];
            HeaderRequest headerRequest = new HeaderRequest();
            Array.Copy(msg, headerRequest.HeaderRequestLength, BodyMsg, 0, cancelOrderRequest.CancelOrderRequestLength);
            CancelOrder ca = (CancelOrder)Parser.RawDataToObject(ref BodyMsg, typeof(CancelOrder));
            RequestQuery query = new RequestQuery();
            query.BrokerCode = ca.BrokerCode;
            query.CustomerId = ca.CustomerId;
            query.OrderId = Parser.ParseByteToInt64(ca.OrderId);
            return query;
        }

    }
}
