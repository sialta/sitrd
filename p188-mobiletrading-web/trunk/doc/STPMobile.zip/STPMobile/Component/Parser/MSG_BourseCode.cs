﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class MSG_BourseCode : Parser
    {

        private static char[] UTF = {
                                        '\u0621', // Hamza
                                        '\u0622', // Alef with Madda
                                        '\u0627', // Alef
                                        '\u0628', // Beh
                                        '\u067E', // Peh
                                        '\u062A', // Teh
                                        '\u062B', // Theh
                                        '\u062C', // Jeem
                                        '\u0686', // Tcheh
                                        '\u062D', // Hah
                                        '\u062E', // Khah
                                        '\u062F', // Dal
                                        '\u0630', // Thal
                                        '\u0631', // Reh
                                        '\u0632', // Zain
                                        '\u0698', // Jeh
                                        '\u0633', // Seen
                                        '\u0634', // Sheen
                                        '\u0635', // Sad
                                        '\u0636', // Dad
                                        '\u0637', // Tah
                                        '\u0638', // Zah
                                        '\u0639', // Ain
                                        '\u063A', // Ghain
                                        '\u0641', // Feh
                                        '\u0642', // Qaf
                                        '\u0643', // Kaf
                                        '\u06A9', // Keheh
                                        '\u06AF', // Gaf
                                        '\u0644', // Lam
                                        '\u0645', // Meem
                                        '\u0646', // Noon
                                        '\u0647', // Heh
                                        '\u0648', // Waw
                                        '\u064A', // Yeh
                                        '\u06CC', // Yeh Farsi
                                        '\u0626', // Yeh with Hamza
                                        '\u0649', // Yeh Alef Maksura
                                        '\u0030', // 0
                                        '\u0031', // 1
                                        '\u0032', // 2
                                        '\u0033', // 3
                                        '\u0034', // 4
                                        '\u0035', // 5
                                        '\u0036', // 6
                                        '\u0037', // 7
                                        '\u0038', // 8
                                        '\u0039', // 9
                                    };



        private static char[][] UNICODE = {
            // {isolated,  initial,   medial,    final}
                                          new char[] {'\uFE80', '\uFE80', '\uFE80', '\uFE80'},   //'\u0622'   // Hamza
                                          new char[] {'\uFE81', '\uFE81', '\uFE82', '\uFE82'},   //'\u0622'   // Alef with Madda
                                          new char[] {'\uFE8D', '\uFE8D', '\uFE8E', '\uFE8E'},   //'\u0627'   // Alef
                                          new char[] {'\uFE8F', '\uFE91', '\uFE92', '\uFE90'},   //'\u0628'   // Beh
                                          new char[] {'\uFB56', '\uFB58', '\uFB59', '\uFB57'},   //'\u067E'   // Peh
                                          new char[] {'\uFE95', '\uFE97', '\uFE98', '\uFE96'},   //'\u062A'   // Teh
                                          new char[] {'\uFE99', '\uFE9B', '\uFE9C', '\uFE9A'},   //'\u062B'   // Theh
                                          new char[] {'\uFE9D', '\uFE9F', '\uFEA0', '\uFE9E'},   //'\u062C'   // Jeem
                                          new char[] {'\uFB7A', '\uFB7C', '\uFB7D', '\uFB7B'},   //'\u0686'   // Tcheh
                                          new char[] {'\uFEA1', '\uFEA3', '\uFEA4', '\uFEA2'},   //'\u062D'   // Hah
                                          new char[] {'\uFEA5', '\uFEA7', '\uFEA8', '\uFEA6'},   //'\u062E'   // Khah
                                          new char[] {'\uFEA9', '\uFEA9', '\uFEAA', '\uFEAA'},   //'\u062F'   // Dal
                                          new char[] {'\uFEAB', '\uFEAB', '\uFEAC', '\uFEAC'},   //'\u0630'   // Thal
                                          new char[] {'\uFEAD', '\uFEAD', '\uFEAE', '\uFEAE'},   //'\u0631'   // Reh
                                          new char[] {'\uFEAF', '\uFEAF', '\uFEB0', '\uFEB0'},   //'\u0632'   // Zain
                                          new char[] {'\uFB8A', '\uFB8A', '\uFB8B', '\uFB8B'},   //'\u0698'   // Jeh
                                          new char[] {'\uFEB1', '\uFEB3', '\uFEB4', '\uFEB2'},   //'\u0633'   // Seen
                                          new char[] {'\uFEB5', '\uFEB7', '\uFEB8', '\uFEB6'},   //'\u0634'   // Sheen
                                          new char[] {'\uFEB9', '\uFEBB', '\uFEBC', '\uFEBA'},   //'\u0635'   // Sad
                                          new char[] {'\uFEBD', '\uFEBF', '\uFEC0', '\uFEBE'},   //'\u0636'   // Dad
                                          new char[] {'\uFEC1', '\uFEC3', '\uFEC4', '\uFEC2'},   //'\u0637'   // Tah
                                          new char[] {'\uFEC5', '\uFEC7', '\uFEC8', '\uFEC6'},   //'\u0638'   // Zah
                                          new char[] {'\uFEC9', '\uFECB', '\uFECC', '\uFECA'},   //'\u0639'   // Ain
                                          new char[] {'\uFECD', '\uFECF', '\uFED0', '\uFECE'},   //'\u063A'   // Ghain
                                          new char[] {'\uFED1', '\uFED3', '\uFED4', '\uFED2'},   //'\u0641'   // Feh
                                          new char[] {'\uFED5', '\uFED7', '\uFED8', '\uFED6'},   //'\u0642'   // Qaf
                                          new char[] {'\uFED9', '\uFEDB', '\uFEDC', '\uFEDA'},   //'\u0643'   // Kaf
                                          new char[] {'\uFB8E', '\uFB90', '\uFB91', '\uFB8F'},   //'\u06A9'   // Keheh
                                          new char[] {'\uFB92', '\uFB94', '\uFB95', '\uFB93'},   //'\u06AF'   // Gaf
                                          new char[] {'\uFEDD', '\uFEDF', '\uFEE0', '\uFEDE'},   //'\u0644'   // Lam
                                          new char[] {'\uFEE1', '\uFEE3', '\uFEE4', '\uFEE2'},   //'\u0645'   // Meem
                                          new char[] {'\uFEE5', '\uFEE7', '\uFEE8', '\uFEE6'},   //'\u0646'   // Noon
                                          new char[] {'\uFEE9', '\uFEEB', '\uFEEC', '\uFEEA'},   //'\u0647'   // Heh
                                          new char[] {'\uFEED', '\uFEED', '\uFEEE', '\uFEEE'},   //'\u0648'   // Waw
                                          new char[] {'\uFBFC', '\uFEF3', '\uFEF4', '\uFBFD'},   //'\u0649'   // Yeh
                                          new char[] {'\uFBFC', '\uFEF3', '\uFEF4', '\uFBFD'},   //'\u0649'   // Yeh Farsi
                                          new char[] {'\uFE89', '\uFE8B', '\uFE8C', '\uFE8A'},   //'\u0649'   // Yeh with Hamza
                                          new char[] {'\uFEEF', '\uFEF3', '\uFEF4', '\uFEF0'},   //'\u0649'   // Yeh Alef Maksura
            /*{'\uFEF1', '\uFEF3', '\uFEF4', '\uFEF2'},   //'\u0649'   // Yeh
            {'\uFBFC', '\uFBFE', '\uFBFF', '\uFBFD'},   //'\u0649'   // Yeh Farsi
            {'\uFE89', '\uFE8B', '\uFE8C', '\uFE8A'},   //'\u0649'   // Yeh with Hamza
            {'\uFEEF', '\uFEF3', '\uFEF4', '\uFEF0'},   //'\u0649'   // Yeh Alef Maksura*/
                                          new char[] {'\u0660', '\u0660', '\u0660', '\u0660'},   //'\u0030'   // 0
                                          new char[] {'\u0661', '\u0661', '\u0661', '\u0661'},   //'\u0031'   // 1
                                          new char[] {'\u0662', '\u0662', '\u0662', '\u0662'},   //'\u0032'   // 2
                                          new char[] {'\u0663', '\u0663', '\u0663', '\u0663'},   //'\u0033'   // 3
                                          new char[] {'\u0664', '\u0664', '\u0664', '\u0664'},   //'\u0034'   // 4
                                          new char[] {'\u0665', '\u0665', '\u0665', '\u0665'},   //'\u0035'   // 5
                                          new char[] {'\u0666', '\u0666', '\u0666', '\u0666'},   //'\u0036'   // 6
                                          new char[] {'\u0667', '\u0667', '\u0667', '\u0667'},   //'\u0037'   // 7
                                          new char[] {'\u0668', '\u0668', '\u0668', '\u0668'},   //'\u0038'   // 8
                                          new char[] {'\u0669', '\u0669', '\u0669', '\u0669'},   //'\u0039'   // 9
    };

        //public static int[] characterCodes = {'\uFB56','\uFB57','\uFB58','\uFB59',
        //    '\uFB7A','\uFB7B','\uFB7C','\uFB7D','\uFB8A','\uFB8B',
        //    '\uFB92','\uFB93','\uFB94','\uFB95',
        //    '\uFE80', '\uFE81','\uFE82', //'\uFE83','\uFE84', 
        //    '\uFE85','\uFE86',
        //    //'\uFE87','\uFE88', 
        //    '\uFE89','\uFE8A', '\uFE8B','\uFE8C', '\uFE8D','\uFE8E', '\uFE8F',
        //    '\uFE90','\uFE91','\uFE92','\uFE93','\uFE94','\uFE95','\uFE96','\uFE97','\uFE98','\uFE99','\uFE9A','\uFE9B',
        //    '\uFE9C','\uFE9D','\uFE9E','\uFE9F',
        //    '\uFEA0','\uFEA1','\uFEA2','\uFEA3','\uFEA4','\uFEA5','\uFEA6','\uFEA7','\uFEA8','\uFEA9','\uFEAA','\uFEAB',
        //    '\uFEAC','\uFEAD','\uFEAE','\uFEAF',
        //    '\uFEB0','\uFEB1','\uFEB2','\uFEB3','\uFEB4','\uFEB5','\uFEB6','\uFEB7','\uFEB8','\uFEB9','\uFEBA','\uFEBB',
        //    '\uFEBC','\uFEBD','\uFEBE','\uFEBF',
        //    '\uFEC0','\uFEC1','\uFEC2','\uFEC3','\uFEC4','\uFEC5','\uFEC6','\uFEC7','\uFEC8','\uFEC9','\uFECA','\uFECB',
        //    '\uFECC','\uFECD','\uFECE','\uFECF',
        //    '\uFED0','\uFED1','\uFED2','\uFED3','\uFED4','\uFED5','\uFED6','\uFED7','\uFED8','\uFED9','\uFEDA','\uFEDB',
        //    '\uFEDC','\uFEDD','\uFEDE','\uFEDF',
        //    '\uFEE0','\uFEE1','\uFEE2','\uFEE3','\uFEE4','\uFEE5','\uFEE6','\uFEE7','\uFEE8','\uFEE9','\uFEEA','\uFEEB',
        //    '\uFEEC','\uFEED','\uFEEE','\uFEEF',
        //    '\uFEF0','\uFEF1','\uFEF2','\uFEF3','\uFEF4'
        //    };

        public static char[] characterCodes = {
                                                  '\uFB56', '\uFB57', '\uFB58', '\uFB59', // Arabic Peh
                                                  '\uFB7A', '\uFB7B', '\uFB7C', '\uFB7D', // Arabic Tcheh
                                                  '\uFB8A', '\uFB8B', // Arabic Jeh
                                                  '\uFB92', '\uFB93', '\uFB94', '\uFB95', // Arabic Gaf
                                                  '\uFE80', // Arabic Hamza
                                                  '\uFE81', '\uFE82', //Arabic Alef
                                                  '\uFE85', '\uFE86', //Arabic Waw With Hamza
                                                  '\uFE89', '\uFE8A', '\uFE8B', '\uFE8C', //Arabic Yeh With Hamza
                                                  '\uFE8D', '\uFE8E', //Arabic Alef
                                                  '\uFE8F', '\uFE90', '\uFE91', '\uFE92', //Arabic Beh
                                                  '\uFE93', '\uFE94', '\uFE95', '\uFE96', '\uFE97', '\uFE98',
                                                  //Arabic Teh
                                                  '\uFE99', '\uFE9A', '\uFE9B', '\uFE9C', //Arabic Seh
                                                  '\uFE9D', '\uFE9E', '\uFE9F', '\uFEA0', //Arabic Jeem
                                                  '\uFEA1', '\uFEA2', '\uFEA3', '\uFEA4', //Arabic Hah
                                                  '\uFEA5', '\uFEA6', '\uFEA7', '\uFEA8', //Arabic Khah
                                                  '\uFEA9', '\uFEAA', //Arabic Dal
                                                  '\uFEAB', '\uFEAC', //Arabic Thal
                                                  '\uFEAD', '\uFEAE', //Arabic Reh
                                                  '\uFEAF', '\uFEB0', //Arabic Zain
                                                  '\uFEB1', '\uFEB2', '\uFEB3', '\uFEB4', //Arabic Seen
                                                  '\uFEB5', '\uFEB6', '\uFEB7', '\uFEB8', //Arabic Sheen
                                                  '\uFEB9', '\uFEBA', '\uFEBB', '\uFEBC', //Arabic Sad
                                                  '\uFEBD', '\uFEBE', '\uFEBF', '\uFEC0', //Arabic Dad
                                                  '\uFEC1', '\uFEC2', '\uFEC3', '\uFEC4', //Arabic Tah
                                                  '\uFEC5', '\uFEC6', '\uFEC7', '\uFEC8', //Arabic Zah
                                                  '\uFEC9', '\uFECA', '\uFECB', '\uFECC', //Arabic Ain
                                                  '\uFECD', '\uFECE', '\uFECF', '\uFED0', //Arabic Ghain
                                                  '\uFED1', '\uFED2', '\uFED3', '\uFED4', //Arabic Feh
                                                  '\uFED5', '\uFED6', '\uFED7', '\uFED8', //Arabic Qaf
                                                  '\uFED9', '\uFEDA', '\uFEDB', '\uFEDC', //Arabic Kaf
                                                  '\uFEDD', '\uFEDE', '\uFEDF', '\uFEE0', //Arabic Lam
                                                  '\uFEE1', '\uFEE2', '\uFEE3', '\uFEE4', //Arabic Meem
                                                  '\uFEE5', '\uFEE6', '\uFEE7', '\uFEE8', //Arabic Noon
                                                  '\uFEE9', '\uFEEA', '\uFEEB', '\uFEEC', //Arabic Heh
                                                  '\uFEED', '\uFEEE', //Arabic Waw
                                                  '\uFEEF', '\uFEF0', '\uFEF1', '\uFEF2', '\uFEF3', '\uFEF4'
                                                  //Arabic Yeh
                                              };

        public static string DecodeBourseCode(byte[] buyMsgbourseCode)
        {
            byte _chr = buyMsgbourseCode[5];

            char[] bourseCode = new char[8];
            bourseCode[0] = (char)(char)characterCodes[_chr];

            _chr = buyMsgbourseCode[4];
            byte temp = Convert.ToByte(_chr);
            bourseCode[1] = (char)characterCodes[temp];

            _chr = buyMsgbourseCode[3];
            temp = Convert.ToByte(_chr);
            bourseCode[2] = (char)characterCodes[temp];

            ///numeric part
            byte leftValue = 0, RightValue = 0;
            _chr = Convert.ToByte(buyMsgbourseCode[0]);

            leftValue = RightValue = _chr;
            leftValue &= 240;
            leftValue >>= 4;
            bourseCode[3] = Convert.ToChar(leftValue + 48);

            //RightValue &= 15;
            //bourseCode[6] = Convert.ToChar(RightValue + 48);

            _chr = Convert.ToByte(buyMsgbourseCode[1]);
            leftValue = RightValue = _chr;
            leftValue &= 240;
            leftValue >>= 4;
            bourseCode[4] = Convert.ToChar(leftValue + 48);

            RightValue &= 15;
            bourseCode[5] = Convert.ToChar(RightValue + 48);

            _chr = Convert.ToByte(buyMsgbourseCode[2]);

            leftValue = RightValue = _chr;
            leftValue &= 240;
            leftValue >>= 4;
            bourseCode[6] = Convert.ToChar(leftValue + 48);

            RightValue &= 15;
            bourseCode[7] = Convert.ToChar(RightValue + 48);


            String value = new String(bourseCode);
            return value;
        }

        public static byte[] EncodeBourseCode(string bourseCode)
        {
            byte[] ret = new byte[6];
            char[] bourseCodeArray = SafePersianEncode(bourseCode.Trim()).ToCharArray();            
            //System.Text.UTF8Encoding s = new UTF8Encoding();
            //s.
            if(bourseCodeArray.Length==9)
            {
                for(int j=4;j<bourseCodeArray.Length;j++)
                    bourseCodeArray[j - 1] = bourseCodeArray[j];
            }
            
            byte tmp = Convert.ToByte(bourseCodeArray[3]);
            ret[0] = Convert.ToByte(tmp - 48);
            tmp = Convert.ToByte(bourseCodeArray[4]);
            tmp = Convert.ToByte(tmp - 48);
            tmp <<= 4;
            ret[1] = tmp;
            
            tmp = Convert.ToByte(bourseCodeArray[5]);
            ret[1] += Convert.ToByte(tmp - 48);

            tmp = Convert.ToByte(bourseCodeArray[6]);
            tmp = Convert.ToByte(tmp - 48);
            tmp <<= 4;
            ret[2] = tmp;
            tmp = Convert.ToByte(bourseCodeArray[7]);
            ret[2] += Convert.ToByte(tmp - 48);
            int i = Array.IndexOf(UTF, bourseCodeArray[0]);
            char ch = UNICODE[i][1];
            i = Array.BinarySearch(characterCodes, ch);
            ret[5] = Convert.ToByte(i);

            i = Array.IndexOf(UTF, bourseCodeArray[1]);
             ch = UNICODE[i][2];
            i = Array.BinarySearch(characterCodes, ch);
            ret[4] = Convert.ToByte(i);
            i = Array.IndexOf(UTF, bourseCodeArray[2]);
             ch = UNICODE[i][2];
            i = Array.BinarySearch(characterCodes, ch);
            ret[3] = Convert.ToByte(i);

            //characterCodes.Last()
            //System.Text.UnicodeEncoding nn=new UnicodeEncoding();
            //byte[] rr = Encoding.Unicode.GetBytes("م");
            //nn.GetBytes(bourseCodeArray,0,1);
            //long j = BitConverter.ToInt32(rr,0);)

            return ret;

        }

        public static byte[] EncodeBourseCode1(string bourseCode)
        {
            byte[] ret = new byte[6];
            for (int i = 0; i < ret.Length; i++)
            {
                ret[i] = 0;
            }
            return ret;

        }

        public static string SafePersianEncode(string str)
        {

            if (string.IsNullOrEmpty(str))
            {
                return string.Empty;
            }
            str = str.Replace("ي", "ی");
            str = str.Replace("ك", "ک");
            str = str.Replace("‍", "");
            str = str.Replace("دِ", "د");
            str = str.Replace("بِ", "ب");
            str = str.Replace("زِ", "ز");
            str = str.Replace("ذِ", "ذ");
            str = str.Replace("ِشِ", "ش");
            str = str.Replace("ِسِ", "س");
            str = str.Replace("‌", "");
            str = str.Replace("ض", "ض");
            str = str.Replace("فِ", "ف");

            return str.Trim();
        }
        //public static string DecodeBourseCode(byte[] buyMsgbourseCode)
        //{
        //    int _chr = buyMsgbourseCode[5];

        //    _chr <<= 1; _chr >>= 1;

        //    char[] bourseCode = new char[8];
        //    bourseCode[0] = (char)(char)characterCodes[_chr];

        //    _chr = buyMsgbourseCode[4];
        //    _chr &= 63;
        //    _chr <<= 1;
        //    byte temp = buyMsgbourseCode[5];
        //    temp >>= 7;
        //    temp &= 1;
        //    temp += Convert.ToByte(_chr);
        //    bourseCode[1] = (char)characterCodes[temp];

        //    _chr = buyMsgbourseCode[3];
        //    _chr &= 31;
        //    _chr <<= 2;
        //    temp = buyMsgbourseCode[4];
        //    temp >>= 6;
        //    temp &= 3;
        //    temp += Convert.ToByte(_chr);
        //    bourseCode[2] = (char)characterCodes[temp];

        //    ///numeric part
        //    _chr = buyMsgbourseCode[3];
        //    _chr &= 224;
        //    _chr >>= 5;
        //    temp = buyMsgbourseCode[2];
        //    temp &= 1;
        //    temp <<= 3;
        //    temp += Convert.ToByte(_chr);
        //    bourseCode[7] = Convert.ToChar(temp + 48);

        //    _chr = buyMsgbourseCode[2];
        //    _chr &= 15;
        //    _chr >>= 1;
        //    bourseCode[6] = Convert.ToChar(_chr + 48);

        //    _chr = buyMsgbourseCode[2];
        //    _chr &= 224;
        //    _chr >>= 5;
        //    temp = buyMsgbourseCode[1];
        //    temp &= 1;
        //    temp <<= 3;
        //    temp += Convert.ToByte(_chr);
        //    bourseCode[5] = Convert.ToChar(temp + 48);


        //    _chr = buyMsgbourseCode[1];
        //    _chr &= 15;
        //    _chr >>= 1;
        //    bourseCode[4] = Convert.ToChar(_chr + 48);

        //    _chr = buyMsgbourseCode[1];
        //    _chr &= 224;
        //    _chr >>= 5;
        //    temp = buyMsgbourseCode[0];
        //    temp &= 1;
        //    temp <<= 3;
        //    temp += Convert.ToByte(_chr);
        //    bourseCode[3] = Convert.ToChar(temp + 48);
        //    String value = new String(bourseCode);
        //    return value;
        //}
    }
}
