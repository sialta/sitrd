﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Component.Message;

namespace Component
{
    public class MSG_ViewAccount : Parser
    {
        public static CustomerTurnoverQuery DecodeViewAccountList(byte[] msg)
        {
            CustomerTurnoverListRequest listRequest = new CustomerTurnoverListRequest();
            byte[] BodyMsg = new byte[listRequest.MessageLength];
            Array.Copy(msg, 8, BodyMsg, 0, listRequest.MessageLength);

            CustomerAccountList ca = (CustomerAccountList)RawDataToObject(ref BodyMsg, typeof(CustomerAccountList));

            CustomerTurnoverQuery query = new CustomerTurnoverQuery();
            query.CustomerId = ca.CustomerId;
            query.BrokerCode = ca.BrokerCode;
            query.PageIndex = ca.PageNo;
            query.PageSize = ca.PageSize;
            return query;
        }  
    }
}
