﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Component.Message;

namespace Component
{
    class MSG_Message : Parser
    {
        public static MessageListQuery DecodeMessageList(byte[] msg)
        {
            MessageListRequest request = new MessageListRequest();

            byte[] BodyMsg = new byte[request.FixMessageListRequestLen];
            Array.Copy(msg, 8, BodyMsg, 0, request.FixMessageListRequestLen);

            MessageList ca = (MessageList)RawDataToObject(ref BodyMsg, typeof(MessageList));
            MessageListQuery query = new MessageListQuery();
            query.BrokerCode = ca.BrokerCode;
            query.CustomerId = ca.CustomerId;
            query.LastMessageDateTime = ParseByetToDateTime(ca.LastMessageDateTime);
            return query;
        }

        public static MessageDetailByIdQuery DecodeMessageDetailById(byte[] msg)
        {
            MessagesDetailRequest request = new MessagesDetailRequest();

            byte[] BodyMsg = new byte[request.FixMessagesDetailRequestLen];
            Array.Copy(msg, 8, BodyMsg, 0, request.FixMessagesDetailRequestLen);

            MessageDetailById ca = (MessageDetailById)RawDataToObject(ref BodyMsg, typeof(MessageDetailById));
            MessageDetailByIdQuery query = new MessageDetailByIdQuery();
            query.BrokerCode = ca.BrokerCode;
            query.CustomerId = ca.CustomerId;
            query.MessageId = ca.MessageId;
            return query;
        }
    }
}
