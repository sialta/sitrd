﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Component.Message;

namespace Component
{    

    public class MSG_Login : Parser
    {

        public static LoginQuery DecodeLogin(byte[] msg)
        {
            LoginRequest request = new LoginRequest();

            byte[] BodyMsg = new byte[request.LoginRequestFixLength];
            Array.Copy(msg, 8, BodyMsg, 0, request.LoginRequestFixLength);
            //decode the fix segment of login message
            FirstLogin ca = (FirstLogin) RawDataToObject(ref BodyMsg, typeof (FirstLogin));

            LoginQuery query = new LoginQuery();
            byte[] username = new byte[ca.UserLen];
            Array.Copy(msg, 8 + request.LoginRequestFixLength, username, 0, ca.UserLen);

            byte[] password = new byte[ca.PassLen];
            Array.Copy(msg, 8 + request.LoginRequestFixLength + ca.UserLen, password, 0, ca.PassLen);
            query.Version = ca.Version;
            query.Username = ByteArrayToStr(username);
            query.Password = ByteArrayToStr(password);
            query.BrokerCode = ca.BrokerCode;
            return query;
        }

     }
}
