﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class MSG_Logout:Parser
    {
        public static LogoutQuery DecodeLogout(byte[] msg)
        {
            byte[] BodyMsg = new byte[4];
            Array.Copy(msg, 8, BodyMsg, 0, 4);

            Logout ca = (Logout)RawDataToObject(ref BodyMsg, typeof(Logout));

            LogoutQuery query = new LogoutQuery();

            query.CustomerId = ca.CustomerId;
            query.BrokerCode = ca.BrokerCode;
            query.BrokerCode = ca.BrokerCode;
            return query;
        }
    }
}
