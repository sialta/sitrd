﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace Component
{
    public class Parser
    {
        public static object RawDataToObject(ref byte[] rawData, Type overlayType)
        {
            object result = null;

            GCHandle pinnedRawData = GCHandle.Alloc(rawData,
                GCHandleType.Pinned);
            try
            {

                // Get the address of the data array
                IntPtr pinnedRawDataPtr =
                    pinnedRawData.AddrOfPinnedObject();

                // overlay the data type on top of the raw data
                result = Marshal.PtrToStructure(
                    pinnedRawDataPtr,
                    overlayType);
            }
            finally
            {
                // must explicitly release
                pinnedRawData.Free();
            }

            return result;
        }
        /// <summary>
        /// convert int value to 2 byte
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[] GetInt2Byte(int value)
        {
            return BitConverter.GetBytes(Convert.ToInt16(value));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[] GetInt4Byte(int value)
        {
            return BitConverter.GetBytes(Convert.ToInt32(value));
        }

        public static byte[] GetInt3Byte(int value)
        {
            byte[] ret64 = BitConverter.GetBytes(Convert.ToInt32(value));
            byte[] ret24 = new byte[3];
            Array.Copy(ret64, ret24, 3);
            return ret24;
        }

        public static byte[] GetInt8Byte(double value)
        {
            //byte[] ret64 = 
            //byte[] ret40 = new byte[5];
            //Array.Copy(ret64, ret40, 5);
            return BitConverter.GetBytes(Convert.ToInt64(value)); ;
        }

        public static Int64 ParseByteToInt64(byte[] intByte)
        {
            byte[] RetVal = new byte[8];

            for (int i = 0; i < intByte.Length; i++)
                RetVal[i] = intByte[i];

            RetVal[5] = RetVal[6] = RetVal[7] = 0;


            return BitConverter.ToInt64(RetVal, 0);
        }

        public static int ParseByteToInt32(byte[] intByte)
        {

            byte[] RetVal = { 0, 0, 0, 0 };

            for (int i = 0; i < intByte.Length; i++)
                RetVal[i] = intByte[i];

            return BitConverter.ToInt32(RetVal, 0);
        }

        //public static DateTime ParseByetToDateTime(byte[] dateByte)
        //{
        //    int y = dateByte[0] >> 1;
        //    int d = dateByte[1] & 31;
        //    int m = dateByte[1] >> 5;

        //    int m1 = 0;
        //    m1 = dateByte[0] & 1;
        //    m1 <<= 3;
        //    m1 = m1 + m;
        //    return JalaliDate.ConvertJalaliToMiladi(string.Format("13{0}/{1}/{2}", y, m1, d));
        //}



        public static DateTime ParseByetToDateTime(byte[] dateByte)
        {
            //Year
            int y = dateByte[0] >> 2;
            y += 50;

            //Day
            int d = (dateByte[1] >> 1) & 31;

            //Month
            int m = dateByte[1] >> 5;
            int m1 = dateByte[0] & 3;
            int m2 = dateByte[1] >> 6;
            m1 <<= 2;
            int m3 = m1 + m2;

            //Hour
            int h = dateByte[1] & 1;
            int h2 = dateByte[2] >> 4;
            h <<= 4;
            int h3 = h + h2;

            //Minute
            int mi = dateByte[2] & 15;
            int mi2 = dateByte[3] >> 6;
            mi <<= 2;
            int mi3 = mi2 + mi;

            //Second
            int se = dateByte[3] & 63;

            return JalaliDate.ConvertJalaliToMiladiDateTime(string.Format("13{0}/{1}/{2} {3}:{4}:{5}", y, m3, d, h3, mi3, se));
        }



        //public static DateTime ParseByetToDateTime(byte[] dateByte)
        //{
        //    string byteArrayToStr = ByteArrayToStr(dateByte);

        //    int year = Convert.ToInt32(byteArrayToStr.Substring(0, 2)) + 50;
        //    int month = Convert.ToInt32(byteArrayToStr.Substring(2, 2));
        //    int day = Convert.ToInt32(byteArrayToStr.Substring(4, 2));

        //    int hour = Convert.ToInt32(byteArrayToStr.Substring(6, 2));
        //    int minute = Convert.ToInt32(byteArrayToStr.Substring(8, 2));
        //    int second = Convert.ToInt32(byteArrayToStr.Substring(10, 2));

        //    return JalaliDate.ConvertJalaliToMiladi(string.Format("13{0}/{1}/{2} {3}:{4}:{5}", year, month, day, hour, minute, second));
        //}

        public static DateTime ParseByteToDate(byte[] dateByte)
        {
            int y = dateByte[0] >> 1;
            int d = dateByte[1] & 31;
            int m = dateByte[1] >> 5;

            int m1 = 0;
            m1 = dateByte[0] & 1;
            m1 >>= 4;
            m1 = m1 + m;
            return JalaliDate.ConvertJalaliToMiladi(string.Format("13{0}/{1}/{2}", y, m1, d));
        }

        public static byte[] ParseDateToByte(string date)
        {
            byte[] dateByte = { 0, 0 };
            string[] dateArray = date.Split('/');
            byte tmp = Convert.ToByte(Globals.SafeInt(dateArray[0], 0) - 1300);
            tmp <<= 1;
            dateByte[0] = Convert.ToByte(tmp);

            tmp = Convert.ToByte(dateArray[1]);
            if (tmp >= 8)
                dateByte[0] = Convert.ToByte(Globals.SafeInt(dateByte[0], 0) + 1);
            tmp <<= 5;

            byte tmp1 = tmp;

            tmp = Convert.ToByte(dateArray[2]);
            tmp = Convert.ToByte(tmp1 + tmp);
            dateByte[1] = Convert.ToByte(tmp);

            return dateByte;
        }



        //Wrong method
        //public static byte[] ParseDateTimeToByte(DateTime date)
        //{
        //    string dt = JalaliDate.GetJalaliDate(date);
        //    byte[] dateByte = { 0, 0 };

        //    string[] dateArray = dt.Split('/');
        //    byte tmp = Convert.ToByte(Globals.SafeInt(dateArray[0], 0) - 1300);
        //    tmp <<= 2;
        //    dateByte[0] = Convert.ToByte(tmp);

        //    tmp = Convert.ToByte(dateArray[1]);
        //    tmp >>= 2;
        //    dateByte[0] += tmp;

        //    tmp = Convert.ToByte(dateArray[1]);
        //    tmp &= 3;
        //    dateByte[1]= tmp;
        //    dateByte[1] <<= 6;


        //    tmp = Convert.ToByte(dateArray[2]);
        //    tmp <<= 1;
        //    dateByte[1] += tmp;

        //    int t = date.Hour;
        //    tmp = Convert.ToByte(t);
        //    if (t > 16)
        //        dateByte[1]++;
        //    tmp <<= 4;
        //    dateByte[2] =tmp;

        //    //byte tmp1 = tmp;

        //    //tmp = Convert.ToByte(dateArray[2]);
        //    //tmp = Convert.ToByte(tmp1 + tmp);
        //    //dateByte[1] = Convert.ToByte(tmp);)

        //    return dateByte;
        //}


        public static byte[] ParseDateTimeToByte(DateTime dateTime)
        {
            string clearPerDateTime = JalaliDate.GetJalaliDateTime(dateTime) + ":" + dateTime.Second.ToString();
            string[] dttm = clearPerDateTime.Split(' ');

            string[] dtArr = dttm[0].Split('/');

            string date = string.Empty;
            foreach (string s in dtArr)
            {
                string spl = string.Empty;
                if (s.Length <= 1)
                {
                    spl = "0";
                }
                date += spl + s;
            }

            string time = string.Empty;
            string[] tmArr = dttm[1].Split(':');

            foreach (string s in tmArr)
            {
                string spl = string.Empty;
                if (s.Length <= 1)
                {
                    spl = "0";
                }
                time += spl + s;
            }

            byte[] dateByte = { 0, 0, 0, 0 };
            string[] dateArray = new string[6];

            dateArray[0] = date.Substring(0, 4);
            dateArray[1] = date.Substring(4, 2);
            dateArray[2] = date.Substring(6, 2);
            dateArray[3] = time.Substring(0, 2);
            dateArray[4] = time.Substring(2, 2);
            if (time.Length > 4)
                dateArray[5] = time.Substring(4, 2);
            else
            {
                dateArray[5] = "00";
            }

            byte tmp = Convert.ToByte(Globals.SafeInt(dateArray[0], 0) - 1350);
            tmp <<= 2;
            dateByte[0] = Convert.ToByte(tmp);

            tmp = Convert.ToByte(dateArray[1]);
            if (tmp < 4)
            {
                tmp <<= 6;
                dateByte[1] = tmp;

            }
            else
            {
                tmp <<= 6;
                dateByte[1] = tmp;
                tmp = Convert.ToByte(dateArray[1]);
                tmp >>= 2;
                dateByte[0] += tmp;
            }


            tmp = Convert.ToByte(dateArray[2]);
            tmp <<= 1;
            dateByte[1] += Convert.ToByte(tmp);

            tmp = Convert.ToByte(dateArray[3]);
            if (tmp > 16)
            {
                dateByte[1]++;
                tmp &= 15;
                tmp <<= 4;
                dateByte[2] = tmp;
            }
            else
            {
                tmp <<= 4;
                dateByte[2] = tmp;
            }

            tmp = Convert.ToByte(dateArray[4]);
            tmp >>= 2;
            dateByte[2] += tmp;

            tmp = Convert.ToByte(dateArray[4]);
            tmp &= 3;
            tmp <<= 6;
            dateByte[3] = tmp;

            tmp = Convert.ToByte(dateArray[5]);
            dateByte[3] += tmp;

            return dateByte;
        }



        public static byte[] ParseShamciDateToByte(string date, string time)
        {
            byte[] dateByte = { 0, 0, 0, 0 };
            string[] dateArray = new string[6];

            dateArray[0] = date.Substring(0, 4);
            dateArray[1] = date.Substring(4, 2);
            dateArray[2] = date.Substring(6, 2);
            dateArray[3] = time.Substring(0, 2);
            dateArray[4] = time.Substring(2, 2);
            if (time.Length > 4)
                dateArray[5] = time.Substring(4, 2);
            else
            {
                dateArray[5] = "00";
            }

            byte tmp = Convert.ToByte(Globals.SafeInt(dateArray[0], 0) - 1350);
            tmp <<= 2;
            dateByte[0] = Convert.ToByte(tmp);

            tmp = Convert.ToByte(dateArray[1]);
            if (tmp < 4)
            {
                tmp <<= 6;
                dateByte[1] = tmp;

            }
            else
            {
                tmp <<= 6;
                dateByte[1] = tmp;
                tmp = Convert.ToByte(dateArray[1]);
                tmp >>= 2;
                dateByte[0] += tmp;
            }


            tmp = Convert.ToByte(dateArray[2]);
            tmp <<= 1;
            dateByte[1] += Convert.ToByte(tmp);

            tmp = Convert.ToByte(dateArray[3]);
            if (tmp > 16)
            {
                dateByte[1]++;
                tmp &= 15;
                tmp <<= 4;
                dateByte[2] = tmp;
            }
            else
            {
                tmp <<= 4;
                dateByte[2] = tmp;
            }

            tmp = Convert.ToByte(dateArray[4]);
            tmp >>= 2;
            dateByte[2] += tmp;

            tmp = Convert.ToByte(dateArray[4]);
            tmp &= 3;
            tmp <<= 6;
            dateByte[3] = tmp;

            tmp = Convert.ToByte(dateArray[5]);
            dateByte[3] += tmp;

            return dateByte;
        }

        // C# to convert a string to a byte array.
        public static byte[] StrToByteArray(string str)
        {
            string res = str;
            int result;
            Regex r = new Regex("(\\()([\u0600-\u06FF 0-9 % () \\s]+)(\\))");
            if (r.IsMatch(str))
            {
                if (!int.TryParse(r.Replace(str, "$2"), out result))
                {
                    res = res.Replace("(", "afs1").Replace(")", "afs2");
                    res = res.Replace("afs1", ")").Replace("afs2", "(");
                }
            }

            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            return encoding.GetBytes(res);
        }

        // C# to convert a string to a byte array.
        public static string ByteArrayToStr(byte[] str)
        {
            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
            return encoding.GetString(str);
        }

        public static byte[] ParseTimeToByte(string time)
        {
            byte[] timeByte = { 0, 0 };
            string[] timeArray = time.Split(':');

            byte tmp = Convert.ToByte(timeArray[0]);
            if (tmp > 15)
                tmp = 15;

            tmp <<= 4;
            timeByte[0] += Convert.ToByte(tmp);

            timeByte[1] = tmp = Convert.ToByte(timeArray[1]);
            tmp &= 60;//high Value of minute
            tmp >>= 2;
            timeByte[0] += tmp;

            timeByte[1] &= 3;//low Value of minute
            timeByte[1] <<= 6;

            tmp = Convert.ToByte(timeArray[2]);
            timeByte[1] += tmp;

            return timeByte;
        }
        /// <summary>
        /// convert double value to 3 byte,2 byte real value and 1 byte Mantissa
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static byte[] ParseDoubleTo3Byte(double value)
        {
            value = Math.Round(value, 2);
            string[] s = value.ToString().Split('.');
            byte[] retVal = new byte[3];
            byte[] ret = GetInt2Byte(Convert.ToInt16(s[0]));
            //Array.Copy(ret,retVal,0);
            Buffer.BlockCopy(ret, 0, retVal, 0, 2);

            byte mantis = 0;
            if (s.Length > 1)
            {
                mantis = Convert.ToByte(s[1]);
            }
            retVal[2] = mantis;
            return retVal;
        }

        /// <summary>
        /// convert double value to 2 byte,1 byte real value and 1 byte Mantissa
        /// used for Percent Value
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>

        public static byte[] ParseDoubleTo2Byte(double value)
        {
            value = Math.Round(value, 2);
            string[] s = value.ToString().Split('.');
            byte[] ret = new byte[2];
            ret[0] = Convert.ToByte(s[0]);
            if (s.Length > 1)
                ret[1] = Convert.ToByte(s[1]);

            return ret;
        }

    }
}
