﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Component;
using Component.Message;

namespace Component
{
    public class MSG_Stock : Parser
    {
        public static StockQuery GetStockPrice(byte[] msg)
        {
            StockPriceRequest request = new StockPriceRequest();
            byte[] BodyMsg = new byte[request.FixStockPriceReuquestLen];
            Array.Copy(msg, 8, BodyMsg, 0, request.FixStockPriceReuquestLen);

            StockPrice ca = (StockPrice) RawDataToObject(ref BodyMsg, typeof (StockPrice));

            StockQuery query = new StockQuery();
            query.NscCode = ByteArrayToStr(ca.NscCode);
            query.BrokerCode = ca.BrokerCode;
            return query;
        }

        public static StockQuery GetStockQueue(byte[] msg)
        {
            QueueRequest queueRequest = new QueueRequest();
            byte[] BodyMsg = new byte[queueRequest.FixQueueReuquestLen];
            Array.Copy(msg, 8, BodyMsg, 0, queueRequest.FixQueueReuquestLen);

            StockQueue ca = (StockQueue)RawDataToObject(ref BodyMsg, typeof(StockQueue));

            StockQuery query = new StockQuery();
            query.NscCode = ByteArrayToStr(ca.NscCode);
            query.BrokerCode = ca.BrokerCode;
            return query;
        }

        public static StockQuery GetStockList(byte[] msg)
        {
            StockListRequest stockListRequest = new StockListRequest();
            byte[] BodyMsg = new byte[stockListRequest.StockListRequestLen];
            Array.Copy(msg, 8, BodyMsg, 0, stockListRequest.StockListRequestLen);

            StockList ca = (StockList)RawDataToObject(ref BodyMsg, typeof(StockList));

            StockQuery query = new StockQuery();
            query.BrokerCode = ca.BrokerCode;
            query.CustomerId = ca.CustomerId;
            query.GetAll = true;
            return query;
        }
    }
}
