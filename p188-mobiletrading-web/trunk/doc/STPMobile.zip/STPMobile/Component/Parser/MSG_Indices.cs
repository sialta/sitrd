﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Component.Message;

namespace Component
{
    public class MSG_Indices:Parser
    {
        public static IndicesQuery DecodeMainIndices(byte[] msg)
        {
            //indi
            MainIndicesRequest request = new MainIndicesRequest();;

            byte[] BodyMsg = new byte[request.FixMainIndicesRequestLen];
            Array.Copy(msg, 8, BodyMsg, 0, request.FixMainIndicesRequestLen);

            MainIndices ca = (MainIndices)RawDataToObject(ref BodyMsg, typeof(MainIndices));
            IndicesQuery query=new IndicesQuery();
            query.BrokerCode = ca.BrokerCode;
            query.CustomerId = ca.CustomerId;
           return query;
        }
    }
}
