﻿using System;
using System.Collections.Generic;
using Component.Message;

namespace Component
{
    public class MSG_WatchList : Parser
    {
        public static WatchListQuery WatchList(byte[] msg )
        {
            WatchListRequest request=new WatchListRequest();
            byte[] BodyMsg = new byte[request.FixWatchListRequestLen];
            Array.Copy(msg, 8, BodyMsg, 0, request.FixWatchListRequestLen);

            WatchList ca = (WatchList)RawDataToObject(ref BodyMsg, typeof(WatchList));            
            WatchListQuery query = new WatchListQuery();
            query.BrokerCode = ca.BrokerCode;
            query.CustomerId = ca.CustomerId;
            query.SymbolCount = ca.WatchListCount;
            if (ca.WatchListCount > 0)
            {
                query.NSCCode = new List<string>(query.SymbolCount);
                for (int i = 0; i < ca.WatchListCount; i++)
                {
                    int index = i * request.NSCCode + 15;
                    byte[] bytes = new byte[request.NSCCode];
                    Buffer.BlockCopy(msg, index, bytes, 0, request.NSCCode);
                    query.NSCCode.Add(ByteArrayToStr(bytes));
                }
            }
            return query;
        }
    }
}
