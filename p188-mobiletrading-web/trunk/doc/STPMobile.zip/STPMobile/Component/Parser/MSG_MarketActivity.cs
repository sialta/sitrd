﻿using System;
using Component.Message;

namespace Component
{
    public class MSG_MarketActivity:Parser
    {
        public static MarketActivityQuery DecodeMarketActivity(byte[] msg)
        {
            //indi
            MarketActivityRequest request = new MarketActivityRequest(); ;

            byte[] BodyMsg = new byte[request.FixMarketActivityRequestLen];
            Array.Copy(msg, 8, BodyMsg, 0, request.FixMarketActivityRequestLen);

            MarketActivity ca = (MarketActivity)RawDataToObject(ref BodyMsg, typeof(MarketActivity));
            MarketActivityQuery query=new MarketActivityQuery();
            query.BrokerCode = ca.BrokerCode;
            query.CustomerId = ca.CustomerId;
            return query;
        }

        public static BestOfMarketQuery DecodeBestOfMarket(byte[] msg)
        {
            BestOfMarketRequest request = new BestOfMarketRequest(); 

            byte[] BodyMsg = new byte[request.FixBestOfMarketRequestLen];
            Array.Copy(msg, 8, BodyMsg, 0, request.FixBestOfMarketRequestLen);

            BestOfMarket ca = (BestOfMarket)RawDataToObject(ref BodyMsg, typeof(BestOfMarket));
            BestOfMarketQuery query = new BestOfMarketQuery();
            query.BrokerCode = ca.BrokerCode;
            query.CustomerId = ca.CustomerId;
            query.PageSize = ca.PageSize;
            query.PageIndex = ca.PageNo;
            query.Status = ca.Status;
            return query;
        }
    }
}
