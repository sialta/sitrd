﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class MSG_AccountCode : Parser
    {
        public static string DecodeAccountCode(byte[] AccCode)
        {
            string Acc = "";
            int i = 0;            
            while (i < AccCode.Length)
            {
                byte leftValue = 0, rightValue = 0, chr = AccCode[i];

                leftValue = rightValue = chr;
                leftValue &= 240;
                leftValue >>= 4;
                if (leftValue > 9)
                    Acc += "-";
                else
                    Acc += Convert.ToChar(leftValue + 48);

                rightValue &= 15;
                if (rightValue == 10)
                    Acc += "-";                
                else
                    if(rightValue!=15)
                        Acc += Convert.ToChar(rightValue + 48);

                i++;

            }
            return Acc;
        }

        public static byte[] EncodeAccountCode(string accountCode)
        {
            byte[] AccCode = new byte[(int)Math.Ceiling((float)accountCode.Length / 2)];
            //char[] c = accountCode.ToCharArray();
            int index = 0,i =0;
            char ch;
            while (index < accountCode.Length)
            {
                ch = accountCode[index];
                if (ch != '-')
                    AccCode[i] = (byte) (ch - 48);
                else //set 10 for '-' in account code
                    AccCode[i] = 10;
                AccCode[i] <<= 4;

                index++;
                if (index < accountCode.Length)
                {
                    ch = accountCode[index];
                    if (ch != '-')
                        AccCode[i] += (byte) (ch - 48);
                    else
                        AccCode[i] += 15;
                    index++;
                }
                else
                {
                    AccCode[i] += 15;
                }
                i++;
            }

            return AccCode;
        }
    }
}