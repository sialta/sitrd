﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class MSG_SellRequest:Parser
    {
        //public static Request DecodeSellRequest(byte[] msg)
        //{
        //    byte[] BodyMsg = new byte[17];
        //    Array.Copy(msg, 8, BodyMsg, 0, 17);

        //    Request req = new Request();
        //    req.RequestType = RequestType.Sell;

        //    SellRequest SellMsg = (SellRequest)RawDataToObject(ref BodyMsg, typeof(SellRequest));

        //    Int16 CompanyCode = BitConverter.ToInt16(SellMsg.CompanyCode, 0);
        //    req.Stock.StockId = CompanyCode;
        //    int compType = SellMsg.Status & 1;

        //    if (compType == 1)
        //        req.Stock.Type = StockType.HaghTaghadom;
        //    else
        //        req.Stock.Type = StockType.Stock;

        //    int i = SellMsg.Status & 4;
        //    if (i == 4)
        //        req.Stock.StockId *= -1;

        //    req.RequestDate = req.FromDate = Globals.GetNowDateTime();

        //    req.UntilDate = ParseByteToDate(SellMsg.UntilDate);
        //    req.EnteredNumber = Convert.ToInt32(ParseByteToInt64(SellMsg.ReqCount));
        //    req.PriceLimit = ParseByteToInt32(SellMsg.MaxPrice);
        //    req.Customer.BourseCode = MSG_BourseCode.DecodeBourseCode(SellMsg.BourseCode);
        //    byte[] AccCode = new byte[SellMsg.AccCodeLen];
        //    Array.Copy(msg, 25, AccCode, 0, SellMsg.AccCodeLen);
        //    req.Customer.AccountCode = MSG_AccountCode.DecodeAccountCode(AccCode);
        //    req.RequestFrom = RequestFromType.SMS;
        //    req.FinalState = RequestFinalState.Waiting;
        //    return req;

        //}
    }
}
