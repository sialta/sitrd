﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class MSG_Header:Parser
    {
        public static HeaderMsg DecodeHeader(byte[] Header)
        {
            HeaderMessage _headerMessage = (HeaderMessage)RawDataToObject(
                ref Header, typeof(HeaderMessage));


            if (_headerMessage.MessageLenght[0] == 0)
            {
                _headerMessage.MessageLenght[0] = _headerMessage.MessageLenght[1];
                _headerMessage.MessageLenght[1] = 0;
            }

            HeaderMsg rh = new HeaderMsg();
            rh.MessageLenght = BitConverter.ToInt16(_headerMessage.MessageLenght, 0);
            rh.ResponseCode = _headerMessage.ResponseCode;
            rh.SeqNo = _headerMessage.SeqNo;
            rh.ServiceType = _headerMessage.ServiceType;
            rh.Flags = _headerMessage.Flags;
            rh.EncryptionKey = _headerMessage.EncryptionKey;
            return rh;
        }

    }
}
