﻿
#region Using

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#endregion

namespace Component
{

    public class BussinessException : System.Exception
    {

        #region Ctors

        public BussinessException(string messageName)
        {
            this.MessageName = messageName;
        }

        #endregion

        #region Property Members

        public string MessageName { get; set; }

        #endregion

    }
}
