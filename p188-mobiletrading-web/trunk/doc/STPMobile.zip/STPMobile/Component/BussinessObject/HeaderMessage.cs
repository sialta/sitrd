﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class HeaderMsg
    {
        
        public int MessageLenght;
        public byte SeqNo = 0;
        public byte ResponseCode = 0;
        public short EncryptionKey = 0;
        public byte Flags = 0;
        public int ServiceType = 0;
    }
}
