﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.BussinessObject
{
    public class RequestBussinessObject:BitUtil
    {
        private Int16 SuccessLength = 4;
        private Int16 FailedLength = 4;

        //private void BuyRequest(byte[] msg, RealHeaderMessage _header)
        //{
        //    byte retVal = 0;
        //    int ReturnValueID = 0;

        //    Request req = MSG_BuyRequest.DecodeBuyRequest(msg);
        //    //ShowRequest(req);
            
        //    retVal = RequestManager.InsertCustomerRequest(req, ref ReturnValueID);
        //    // Send back a response.
        //    if (retVal == 100)
        //    {
        //        byte[] buffer = new byte[HeaderFixLength+SuccessLength];
        //        buffer = ResponeHeader(_header, SuccessLength);
        //        buffer[8] = 1;

        //        //byte[] ret = BitConverter.GetBytes(ReturnValueID);
        //        //buffer[9] = ret[0];
        //        //buffer[10] = ret[1]; buffer[11] = ret[2];
        //        //st.workSocket.Send(buffer);
        //        //SetControlTextInAThreadSafeWay(txtEvent, "Output\n");
        //        //SetControlTextInAThreadSafeWay(txtEvent, BitConverter.ToString(buffer, 0).Replace("-", ","));

        //    }
        //    else
        //    {
        //        byte[] buffer = new byte[8];
        //        buffer[2] = _header.SeqNo;
        //        buffer[3] = retVal;
        //        buffer[4] = 0;
        //        buffer[5] = 0;
        //        buffer[6] = 0;
        //        buffer[7] = 1;

        //        buffer[0] = 0; buffer[1] = 0;
        //        //st.workSocket.Send(buffer);

        //        //SetControlTextInAThreadSafeWay(txtEvent, "Output\n");
        //        //SetControlTextInAThreadSafeWay(txtEvent, BitConverter.ToString(buffer, 0).Replace("-", ","));


        //    }
        //}
    }
}
