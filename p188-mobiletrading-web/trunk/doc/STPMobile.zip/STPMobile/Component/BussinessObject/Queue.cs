﻿using System;

namespace Component
{
    //public class TopLoser
    //{
    //    public string Date { get; set; }
    //    public string Time { get; set; }
    //    public bool IsNegative{get; set;}
    //    public bool IsRight { get; set; }
    //    public  bool IsFaraBourse { get; set; }
    //    public Int16 CompanyCode { get; set; }
    //    public Int16 LastTradedPrice { get; set; }
    //    public byte RealChangePrice{ get; set; }
    //    public byte Mantissa { get; set; }
    //    public Int16 ClosingPrice { get; set; }
    //}

    //public class AskBid
    //{
    //    public string Date { get; set; }
    //    public string Time { get; set; }
    //    public bool IsRight { get; set; }
    //    public bool IsFaraBourse { get; set; }
    //    public Int16 CompanyCode { get; set; }
    //    public Int16 Price { get; set; }
    //    public int Volume { get; set; }
    //    public Int16 No { get; set; }
    //    public int Value { get; set; }
    //}

    //public class Indices
    //{
    //    public byte Code { get; set;}
    //    public Int16 ShValueReal { get; set; }
    //    public byte ShValueMantissa { get; set; }
    //    public Int16 MaxValueReal { get; set; }
    //    public byte MaxValueMantissa { get; set; }
    //    public Int16 MinValueReal { get; set; }
    //    public byte MinValueMantissa { get; set; }
    //    public Int16 ChangeReal { get; set; }
    //    public byte ChangeMantissa { get; set; }
    //    public byte ChangePercentReal { get; set; }
    //    public byte ChangePercentMantissa { get; set; }
    //    public bool IsNegative { get; set; }
    //    public string Date { get; set; }
    //    public string Time { get; set; }
    //}

    public class Queue
    {
        public Int32 Price{ get; set; }
        public Int32 Quantity{ get; set; }
        public Int32 No { get; set; }
    }
}
