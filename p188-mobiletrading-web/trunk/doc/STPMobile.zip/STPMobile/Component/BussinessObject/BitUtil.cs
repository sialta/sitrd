﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component.BussinessObject
{
    public class BitUtil
    {
        public Int16 HeaderFixLength=8;

        public byte[] ResponeHeader(HeaderMsg _header,int length)
        {
            byte[] bytes = new byte[length + HeaderFixLength];
            bytes[0] = GetByte(length);
            bytes[2] = _header.SeqNo;
            bytes[3] = 0;
            bytes[4] = 0;
            bytes[5] = 0;
            bytes[6] = 0;
            bytes[7] = GetByte(_header.ServiceType);
            return bytes;
        }

        public byte GetByte(int value)
        {
            return Convert.ToByte(value);
        }

        public byte[] Get3BytetInt(Int64 Value)
        {
            byte[] ret = BitConverter.GetBytes(Value);            
            byte[] retVal=new byte[3];
            retVal[0] = ret[0];
            retVal[1] = ret[1];
            retVal[2] = ret[2];
            return retVal;
        }
    }
}
