﻿using System;
using System.Collections.Generic;

using System.Linq;
using Component.Component;
using Component.Message;
using Component.wsOnlineRLC;

namespace Component.ObjectManager
{
    public class StockManager : BaseManager,IDisposable
    {
        public byte[] GetStockPrice(byte[] msg, HeaderMsg _header, StateObject st)
        {
            try
            {

                StockQuery query = MSG_Stock.GetStockPrice(msg);
                wsOnlineRLC.WS_Mobile wsMobile = RLCService.GetRLCServiceObject();
                //wsMobile.Url = ConfigurationManager.AppSettings[query.BrokerCode.ToString()];
               

                WsPrice price = wsMobile.GetSymbolPrice(query.NscCode);
                if (price != null)
                {
                    //HeaderResponse headerResponse = new HeaderResponse();
                    StockPriceResponse response = new StockPriceResponse();
                    byte[] buffer = new byte[response.FixStockResponseLen];
                    int index = 0;
                    byte tmp = 0;
                    if (price.IsNegative)
                        tmp += 1;

                    index = Copy(buffer, tmp, index);
                    index = Copy(Parser.GetInt4Byte(price.LastTradedPrice), buffer, index, response.LastTradedPrice);
                    index = Copy(Parser.GetInt2Byte(price.RealChangePrice), buffer, index, response.PriceVarReal);

                    //tmp = ;
                    //index = Copy(buffer, tmp, index);
                    tmp = price.Mantissa;
                    index = Copy(buffer, tmp, index);
                    index = Copy(Parser.GetInt4Byte(price.ClosingPrice), buffer, index, response.ClosePrice);
                    index = Copy(Parser.GetInt4Byte(price.HighAllowedPrice), buffer, index, response.HighAllowedPrice);
                    index = Copy(Parser.GetInt4Byte(price.LowAllowedPrice), buffer, index, response.LowAllowedPrice);
                    index = Copy(Parser.GetInt4Byte(0), buffer, index, response.MaxAllowedCount);
                    index = Copy(Parser.GetInt8Byte(0), buffer, index, response.RealBalance);
                    index = Copy(Parser.GetInt8Byte(0), buffer, index, response.BlockBalance);
                    return buffer;
                }
                else
                {
                    byte[] st1 = new byte[2];
                    return st1;
                }

            }
            catch (Exception exception)
            {
                byte[] st1 = new byte[2];
                return st1;

                throw;
            }

        }

        public byte[] GetStockQueue(byte[] msg, HeaderMsg _header, StateObject st)
        {

            try
            {
                StockQuery query = MSG_Stock.GetStockQueue(msg);

                wsOnlineRLC.WS_Mobile wsMobile = RLCService.GetRLCServiceObject();
                

                WsQueue[] queues = wsMobile.GetSymbolQueue(query.NscCode);
                if (queues.Length > 0)
                {
                    HeaderResponse headerResponse = new HeaderResponse();
                    QueueResponse response = new QueueResponse();
                    //queues.ToList().Select(x => x.BestBuyPrice != 0);
                    int queueCount = 0;
                    var query2 = from queue in queues.ToList()
                                 where queue.BestBuyPrice != 0
                                 select
                                     new Queue()
                                         {
                                             Price = queue.BestBuyPrice,
                                             Quantity = queue.BestBuyQuantity,
                                             No = queue.NoBestBuy
                                         };
                    List<Queue> Buylist = query2.ToList();

                    query2 = null;

                    query2 = from queue in queues.ToList()
                             where queue.BestSellPrice != 0
                             select
                                 new Queue()
                                     {
                                         Price = queue.BestSellPrice,
                                         Quantity = queue.BestSellQuantity,
                                         No = queue.NoBestSell
                                     };

                    List<Queue> Selllist = query2.ToList();

                    queueCount = Buylist.Count + Selllist.Count;
                    byte[] buffer = new byte[response.FixQueueResponseLen + queueCount*response.QueueResposneItemLength];
                    int index = 0;
                    byte tmp = Convert.ToByte(Selllist.Count);
                    index = Copy(buffer, tmp, index);

                    foreach (Queue queue in Selllist)
                    {
                        index = Copy(Parser.GetInt4Byte(queue.Price), buffer, index, response.BestSellPriceField);
                        index = Copy(Parser.GetInt4Byte(queue.Quantity), buffer, index, response.BestSellQuantityField);
                        index = Copy(Parser.GetInt2Byte(queue.No), buffer, index, response.NoBestSellField);
                    }

                    tmp = Convert.ToByte(Buylist.Count);
                    index = Copy(buffer, tmp, index);
                    foreach (Queue queue in Buylist)
                    {
                        index = Copy(Parser.GetInt4Byte(queue.Price), buffer, index, response.BestBuyPriceField);
                        index = Copy(Parser.GetInt4Byte(queue.Quantity), buffer, index, response.BestBuyQuantityField);
                        index = Copy(Parser.GetInt2Byte(queue.No), buffer, index, response.NoBestBuyField);
                    }

                    return buffer;
                }
                else
                {
                    _header.ResponseCode = 0x03;
                    _header.Flags = 0;
                    byte[] retVal = Parser.StrToByteArray("noqueue");
                    byte[] buffer = new byte[retVal.Length + 2];
                    Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                    Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                    return buffer;

                    //_header.ResponseCode = Convert.ToByte("noqueue");
                    //_header.Flags = 0;
                    ////retVal = new byte[ret.Length];
                    //return Parser.StrToByteArray("noqueue");   
                }

            }
            catch (Exception exception)
            {
                //EventLogs.Write(exception);
                //_header.ResponseCode = 0x02;
                //_header.Flags = 0;
                //byte[] retVal = Parser.StrToByteArray(exception.Source);
                //byte[] buffer = new byte[retVal.Length + 2];
                //Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                //Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                //return buffer;
                return GetError(exception, _header);
   
            }
            return null;
        }

        public byte[] GetStockPrice2(byte[] msg, HeaderMsg _header, StateObject st)
        {
            try
            {

                StockQuery query = MSG_Stock.GetStockPrice(msg);
                wsOnlineRLC.WS_Mobile wsMobile = RLCService.GetRLCServiceObject();
               

                WsPrice price = wsMobile.GetSymbolPrice(query.NscCode);
                if (price != null)
                {
                    //HeaderResponse headerResponse = new HeaderResponse();
                    StockPriceResponse response = new StockPriceResponse();
                    byte[] buffer = new byte[response.FixStockResponseLen];
                    int index = 0;
                    byte tmp = 0;
                    if (price.IsNegative)
                        tmp += 4;

                    if ( Math.Abs(price.PriceVar) - Math.Abs(price.RealChangePrice) < 0.1)
                        tmp += 8;

                    index = Copy(buffer, tmp, index);
                    index = Copy(Parser.GetInt4Byte(price.LastTradedPrice), buffer, index, response.LastTradedPrice);
                    int priceChange = price.PriceChange;
                    if (priceChange < 0) priceChange *= -1;
                    //index = Copy(Parser.GetInt3Byte(priceChange), buffer, index, response.ChangeValue);
                    index = Copy(Parser.GetInt2Byte(price.RealChangePrice), buffer, index, response.PriceVarReal);
                    //tmp = price.RealChangePrice;
                    //index = Copy(buffer, tmp, index);
                    tmp = price.Mantissa;
                    index = Copy(buffer, tmp, index);
                    index = Copy(Parser.GetInt4Byte(price.ClosingPrice), buffer, index, response.ClosePrice);
                    index = Copy(Parser.GetInt4Byte(price.HighAllowedPrice), buffer, index, response.HighAllowedPrice);
                    index = Copy(Parser.GetInt4Byte(price.LowAllowedPrice), buffer, index, response.LowAllowedPrice);
                    index = Copy(Parser.GetInt4Byte(0), buffer, index, response.MaxAllowedCount);
                    return buffer;
                }
                else
                {                 
                    //_header.ResponseCode = Convert.ToByte("noprice");
                    //_header.Flags = 0;
                    ////retVal = new byte[ret.Length];
                    //return Parser.StrToByteArray("noprice");

                    _header.ResponseCode = 0x03;
                    _header.Flags = 0;
                    byte[] retVal = Parser.StrToByteArray("noprice");
                    byte[] buffer = new byte[retVal.Length + 2];
                    Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                    Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                    return buffer;

                }

            }
            catch (Exception exception)
            {
                return GetError(exception, _header);


                //byte[] st1 = new byte[2];
                //return st1;

                //throw;
                //EventLogs.Write(exception);
                //_header.ResponseCode = 0x02;
                //_header.Flags = 0;
                //byte[] retVal = Parser.StrToByteArray(exception.Source);
                //byte[] buffer = new byte[retVal.Length + 2];
                //Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                //Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                //return buffer;

            }

        }

        public void Dispose()
        {
            
        }

        public byte[] GetWatchList(byte[] msg, HeaderMsg _header, StateObject st)
        {
            try
            {

                WatchListQuery query = MSG_WatchList.WatchList(msg);
                wsOnlineRLC.WS_Mobile wsMobile = RLCService.GetRLCServiceObject();

                WsWatchList wsWatchList = new WsWatchList();
                wsWatchList.NSCCode = new string[query.SymbolCount];
                int i = 0;
                foreach (string s in query.NSCCode)
                {
                    wsWatchList.NSCCode[i] = s;
                    i++;
                }
                //WsPrice price = wsMobile.GetSymbolPrice(query.NSCCode[0]);
                WsPrice[] prices = wsMobile.GetWatchList(wsWatchList);

                if (prices != null && prices.Length > 0)
                {
                    WatchListResponse response = new WatchListResponse();
                    byte[] buffer =
                        new byte[response.FixWatchListResponseLen + prices.Length*response.FixWatchItemResponseLen];

                    int index = 0;
                    byte tmp = 0;
                    tmp = Convert.ToByte(prices.Length);
                    index = Copy(buffer, tmp, index);
                    tmp = Convert.ToByte(response.FixWatchItemResponseLen);
                    index = Copy(buffer, tmp, index);
                    foreach (WsPrice price in prices)
                    {
                        index = Copy(Parser.StrToByteArray(price.NscCode), buffer, index, response.NSCCode);
                        index = Copy(Parser.GetInt4Byte(price.LastTradedPrice), buffer, index, response.LastTradedPrice);
                        index = Copy(Parser.GetInt8Byte(price.TotalNumberOfSharesTraded), buffer, index, response.TotalNoSharesTradedField);
                        index = Copy(Parser.GetInt2Byte(price.RealChangePrice), buffer, index, response.PriceVarReal);
                        index = Copy(buffer, price.Mantissa, index);
                        tmp = 0;
                        if (price.IsNegative)
                            tmp += 1;

                        if (Math.Abs(price.PriceVar) - Math.Abs(price.RealChangePrice) < 0.1)
                            tmp += 2;

                        index = Copy(buffer, tmp, index);

                    }

                    return buffer;
                }
                else
                {
                    _header.ResponseCode = 0x03;
                    _header.Flags = 0;
                    byte[] retVal = Parser.StrToByteArray("nowatchlist");
                    byte[] buffer = new byte[retVal.Length + 2];
                    Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                    Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                    return buffer;
                }

            }
            catch (Exception exception)
            {
                return GetError(exception, _header);
                //EventLogs.Write(exception);
                //_header.ResponseCode = 0x02;
                //_header.Flags = 0;
                //byte[] retVal = Parser.StrToByteArray(exception.Source);
                //byte[] buffer = new byte[retVal.Length + 2];
                //Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                //Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                //return buffer;

            }

        }

        public byte[] GetStockList(byte[] msg, HeaderMsg _header, StateObject st)
        {
            StockQuery query = MSG_Stock.GetStockList(msg);
            wsOnlineRLC.WS_Mobile wsMobile = RLCService.GetRLCServiceObject();

            StockListResponse response=new StockListResponse();
            if (query.GetAll)
            {
                string s = wsMobile.ExchangeCompanyList();
                byte[] listValue = Parser.StrToByteArray(s);
                response.StockListString = listValue.Length;
                byte[] retVal = new byte[listValue.Length + 4];
                int index = 0;
                index = Copy(Parser.GetInt4Byte(listValue.Length), retVal, index, response.StockListResponseFixLen);
                index = Copy(listValue, retVal, index, response.StockListString);
                return retVal;
            }
            byte[] st1 = new byte[2];
            return st1;
        }
    }
}
