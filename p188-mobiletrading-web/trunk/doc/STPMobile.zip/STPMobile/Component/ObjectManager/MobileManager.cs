﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class MobileManager
    {
        public static SiteSetting GetSiteSetting()
        {
            return MobileProvider.Instance().GetSetting();
        }

    }
}
