﻿using System;

namespace Component.ObjectManager
{
    public class BaseManager
    {
        /// <summary>
        /// add source array to destination array from start index
        /// </summary>
        /// <param name="sourceArray"></param>
        /// <param name="destinationArray"></param>
        /// <param name="start"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        protected int Copy(byte[] sourceArray, byte[] destinationArray, int start, int length)
        {
            Buffer.BlockCopy(sourceArray, 0, destinationArray, start, length);
            return start + length;
        }
        /// <summary>
        /// add a byte(value) to destination array in index
        /// </summary>
        /// <param name="destinationArray"></param>
        /// <param name="value"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        protected int Copy(byte[] destinationArray, byte value, int index)
        {
            //Buffer.BlockCopy(sourceArray, 0, destinationArray, start, lenght);
            destinationArray[index] = value;
            return index+1;
        }

        protected byte[] GetError(Exception exception,HeaderMsg _header)
        {
            
            _header.ResponseCode = 0x02;
            _header.Flags = 0;
            byte[] retVal = Parser.StrToByteArray(exception.Source);
            byte[] buffer = new byte[retVal.Length + 2];
            Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
            Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
            return buffer;
        }

    }
}
