﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net;
using Component.Message;
using Component.wsOnline;
//using OMS;
//using OMS.Component;
using OMSSetting = Component.wsOnline.OMSSetting;
//using Setting = OMS.Setting;


namespace Component.ObjectManager
{
    public class CustomerManager : BaseManager
    {
        static Dictionary<string , CustomerManager> CustomerDictionary = new Dictionary<string, CustomerManager>();
        WS_Mobile wsMobile = null;
        public CustomerManager(int brokerCode)
        {            
            wsMobile = new WS_Mobile();
            //Set Web Service URL
            wsMobile.Url = ConfigurationManager.AppSettings[brokerCode.ToString()];
            wsMobile.CookieContainer = new CookieContainer();
            //wsMobile.Discover();

        }
        public byte[] Login(HeaderMsg _header, LoginQuery query)
        {
            try
            {
                //Validate username and password
                WsPersonInfo personInfo = wsMobile.Login(query.Username, query.Password);

                if (personInfo != null)
                {

                    LoginResponse loginResponse = new LoginResponse();
                    loginResponse.IsinCode = personInfo.IsinCodes.Length;

                    //set the output array size
                    byte[] buffer = new byte[loginResponse.LoginResponseFixLength + loginResponse.IsinCode];
                    byte setting = 0;
                    DateTime dt = Globals.NowDateTime();

                    string strtm = Globals.GetStringTime(dt);

                    byte[] ret = null;

                    int index = 0;

                    index = Copy(Parser.ParseShamciDateToByte(
                        JalaliDate.GetJalaliDateString(dt.ToShortDateString()).Replace("/", ""), strtm), buffer, index,
                                 loginResponse.ServerTime);

                    byte permission = 31;
                    index = Copy(buffer, permission, index);

                    index = Copy(Parser.GetInt4Byte(personInfo.CustomerId), buffer, index, loginResponse.CustomerId);
                    index = Copy(buffer, Convert.ToByte(loginResponse.IsinCode), index);
                    index = Copy(Parser.GetInt8Byte(personInfo.Remain.RealBalance), buffer, index,
                                 loginResponse.RealBalance);
                    index = Copy(Parser.GetInt8Byte(personInfo.Remain.BlockedBalance), buffer, index,
                                 loginResponse.BlockBalance);
                    //index = Copy(MSG_BourseCode.EncodeBourseCode(personInfo.BourseCodes), buffer, index,
                    //             loginResponse.BourseCode);

                    index = Copy(MSG_BourseCode.EncodeBourseCode1(personInfo.BourseCodes), buffer, index,
                         loginResponse.BourseCode);

                    OMSSetting omsSetting = wsMobile.GetSetting();
                    if (omsSetting.ActiveRightForBuy)
                        setting += 128;

                    setting++;
                    index = Copy(buffer, setting, index);

                    index = Copy(Parser.ParseTimeToByte(omsSetting.MarketOpenTime), buffer, index,
                                 loginResponse.OpenMarketTime);
                    index = Copy(Parser.ParseTimeToByte(omsSetting.MarketCloseTime), buffer, index, //
                                 loginResponse.CloseMarketTime);
                    index = Copy(Parser.GetInt2Byte(omsSetting.MinimumOrderCountForBuy), buffer, index,
                                 loginResponse.MinimumOrderCountForBuy);
                    index = Copy(Parser.GetInt2Byte(omsSetting.MinimumOrderCountForSell), buffer, index,
                                 loginResponse.MinimumOrderCountForSell);

                    Copy(Parser.StrToByteArray(personInfo.IsinCodes), buffer, index, loginResponse.IsinCode);
                    _header.ResponseCode = 0;
                    _header.Flags = 0;
                    //create dictionary for user for next operation
                    if (CustomerDictionary.ContainsKey(query.BrokerCode + personInfo.CustomerId.ToString()))
                        CustomerDictionary.Remove(query.BrokerCode + personInfo.CustomerId.ToString());
                    CustomerDictionary.Add(query.BrokerCode + personInfo.CustomerId.ToString(), this);
                    return buffer;

                }

            }
            catch (Exception exception)
            {

                
                
                
                if (exception.HelpLink != null)
                {
                    string ret = exception.HelpLink;
                    _header.ResponseCode = Convert.ToByte(ret.Length);
                    _header.Flags = 0;
                    return Parser.StrToByteArray(ret);

                }
                else
                {
                    //Set error for login error
                    byte[] retVal = null;
                    if (exception.Message.ToLower() == "Unable to connect to the remote server".ToLower())
                    {
                        retVal = Parser.StrToByteArray("امکان ارتباط با سرور کارگزاری وجود ندارد.");
                        _header.ResponseCode = 0x03;
                        _header.Flags = 0;
                    }
                    if(exception.Message.IndexOf("LoginFailed")>0)
                    {
                        string ret = "login_1000";
                        _header.ResponseCode = 0x01;
                        _header.Flags = 0;
                        retVal = Parser.StrToByteArray(ret);
                    }
                    if (exception.Message.IndexOf("UserNotApproved") > 0)
                    {
                        string ret = "login_1003";
                        //comment for new version for error code
                        //_header.ResponseCode = Convert.ToByte(ret);
                        _header.ResponseCode = 0x01;
                        _header.Flags = 0;
                        retVal = Parser.StrToByteArray(ret);
                    }

                    byte[] buffer=new byte[retVal.Length+2];
                    int index = 0;

                    index = Copy(Parser.GetInt2Byte(retVal.Length), buffer, index, 2);
                    Buffer.BlockCopy(retVal,0,buffer,2,retVal.Length);
                    return buffer;
                    //_header.ResponseCode = 1;
                    //_header.Flags = 0;
                    //byte[] tmp = new byte[1];
                    //tmp[0] = 1;
                    //return tmp;
                }
                

            }
            byte[] st21 = new byte[2];
            return st21;

        }

        public static CustomerManager GetCustomerManger(int customerId, int brokerId)
        {
            if (CustomerDictionary[brokerId + customerId.ToString()] != null)
                return CustomerDictionary[brokerId + customerId.ToString()];
            else
            {
                return null;
            }
        }

        public byte[] AddOrder(byte[] msg, HeaderMsg _header, StateObject st, WsOrderMessage om)
        {
            try
            {
                string ret = wsMobile.AddOrder(ref om);
                byte[] retVal = null;
                if (string.IsNullOrEmpty(ret))
                {
                    _header.ResponseCode = 0;
                    _header.Flags = 0;
                    retVal = new byte[6];
                    int index = 0;
                    OrderResponse response = new OrderResponse();
                    index = base.Copy(retVal, (byte)om.OrderState, index);
                    index = base.Copy(Parser.GetInt8Byte((double)om.Id.Value), retVal, index, response.OrderId);
                    return retVal;

                }
                else
                {
                    if (ret.ToLower().StartsWith("oms_5000|"))
                    {
                        _header.ResponseCode = 0x02;
                        _header.Flags = 0;
                        string ruleError = ret.Replace("oms_5000|", "");
                        retVal = Parser.StrToByteArray(ruleError);
                        byte[] retbuffer = new byte[retVal.Length + 2];
                        Copy(Parser.GetInt2Byte(retVal.Length), retbuffer, 0, 2);
                        Buffer.BlockCopy(retVal, 0, retbuffer, 2, retVal.Length);
                        return retbuffer;
                    }
                    _header.ResponseCode = 0x01;
                    _header.Flags = 0;
                    retVal = Parser.StrToByteArray(ret);
                    byte[] buffer = new byte[retVal.Length + 2];
                    Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                    Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                    return buffer;
                    //_header.ResponseCode = Convert.ToByte(ret.Length);
                    //_header.Flags = 0;
                    ////retVal = new byte[ret.Length];
                    ///// 
                    //return Parser.StrToByteArray(ret);
                }
            }
            catch (Exception exception)
            {

                return GetError(exception, _header);
                //_header.ResponseCode = 1;
                //_header.Flags = 0;
                //byte[] tmp = new byte[1];
                //tmp[0] = 1;
                //return tmp;
                //EventLogs.Write(exception,EventLogEntry);

                //EventLogs.Write(exception);
                //_header.ResponseCode = 0x02;
                //_header.Flags = 0;
                //byte[] retVal = Parser.StrToByteArray(exception.Source);
                //byte[] buffer = new byte[retVal.Length + 2];
                //Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                //Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                //return buffer;
            }
        }

        public byte[] OrderList(byte[] msg, HeaderMsg _header, StateObject st,OrderListType orderListType)
        {
            try
            {
                RequestQuery query = MSG_Request.DecodeViewRequestList(msg);
                int totalRow = 0;
                WsOrderMessage[] wsOrderMessages = null;
                if (orderListType == OrderListType.OrderList)
                    wsOrderMessages = wsMobile.GetOrderList(query.CustomerId, query.PageIndex, query.PageSize,
                                                            ref totalRow);
                else

                    wsOrderMessages = wsMobile.GetOrderBook(query.CustomerId, query.PageIndex, query.PageSize,
                                                            ref totalRow);


                OrderListResposne resposne = new OrderListResposne();
                int count = query.PageSize;

                if (query.PageSize > totalRow)
                    count = totalRow;


                if (wsOrderMessages.Length > 0)
                {
                    byte[] buffer =
                        new byte[
                            count*resposne.OrderListResposneItemLength + resposne.PageRowCount +
                            resposne.OrderListResposneItemLength + resposne.ResposneItemLength];

                    int index = 0;
                    index = Copy(Parser.GetInt2Byte(totalRow), buffer, index, resposne.TotalRowCount);
                    index = Copy(buffer, Convert.ToByte(wsOrderMessages.Length), index);
                    index = Copy(Parser.GetInt2Byte(resposne.OrderListResposneItemLength), buffer, index,
                                 resposne.ResposneItemLength);
                    foreach (WsOrderMessage message in wsOrderMessages)
                    {
                        index = Copy(Parser.GetInt8Byte(message.Id.Value), buffer, index, resposne.OrderId);
                        index = Copy(Parser.StrToByteArray(message.ExchangeSymbols.NSCCode), buffer, index,
                                     resposne.Symbol);
                        byte tmp = 0;
                        if (message.ExchangeSymbols.SymbolTypeId == 6)
                            tmp++;
                        if (message.OrderSide == WsOrderSide.Sell)
                            tmp += 4;
                        if (message.HidenOrder > 0)
                            tmp += 8;
                        index = Copy(buffer, tmp, index);
                        index = Copy(Parser.GetInt4Byte(message.OrderTotalQuantity), buffer, index,
                                     resposne.OrderQuantiy);
                        index = Copy(Parser.GetInt4Byte(message.ExcutedAmount), buffer, index, resposne.ExcutedAmount);
                        index = Copy(Parser.GetInt4Byte((int) message.OrderPrice), buffer, index, resposne.OrderPrice);
                        tmp = (byte) message.OrderState;
                        index = Copy(buffer, tmp, index);
                        string strtm = Globals.GetStringTime(message.OrderEntryDate);
                        index = Copy(Parser.ParseShamciDateToByte(
                            JalaliDate.GetJalaliDateString(message.OrderEntryDate.ToShortDateString()).Replace("/", ""),
                            strtm), buffer, index,
                                     resposne.ServerTime);

                    }
                    _header.ResponseCode = 0;
                    _header.Flags = 0;

                    return buffer;
                }
                else
                {
                    _header.ResponseCode = 0x03;
                    _header.Flags = 0;
                    byte[] retVal = Parser.StrToByteArray("noorder");
                    byte[] buffer = new byte[retVal.Length + 2];
                    Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                    Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                    return buffer;
                }

            }
            catch (Exception exception)
            {
                return GetError(exception, _header);

                //EventLogs.Write(exception);
                //_header.ResponseCode = 0x02;
                //_header.Flags = 0;
                //byte[] retVal = Parser.StrToByteArray(exception.Source);
                //byte[] buffer = new byte[retVal.Length + 2];
                //Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                //Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                //return buffer;
                
            }
            return new byte[2];
        }

        public byte[] CancelOrder(byte[] msg, HeaderMsg _header, StateObject st, RequestQuery cancelquery)
        {
            try
            {
                if ((cancelquery.OrderId > 0) && (cancelquery.CustomerId > 0))
                {
                    string str = wsMobile.CancelOrder((int)cancelquery.OrderId);
                    _header.Flags = 0;
                    if (str == "")
                    {
                        _header.ResponseCode = 0;
                        return null;
                    }
                    _header.ResponseCode = (byte)str.Length;
                    byte[] bytes = new byte[str.Length];
                    return Parser.StrToByteArray(str);
                }
            }
            catch (Exception exception)
            {
                return GetError(exception, _header);

                //_header.ResponseCode = 1;
                //_header.Flags = 0;
                //byte[] tmp = new byte[1];
                //tmp[0] = 1;
                //return tmp;

                
                //EventLogs.Write(exception);
                //_header.ResponseCode = 0x02;
                //_header.Flags = 0;
                //byte[] retVal = Parser.StrToByteArray(exception.Source);
                //byte[] buffer = new byte[retVal.Length + 2];
                //Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                //Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                //return buffer;
            }
            return null;
        }

        public byte[] ViewAccount(byte[] msg, HeaderMsg _header, StateObject st, CustomerTurnoverQuery query)
        {
            try
            {
                if (query.CustomerId > 0 && query.BrokerCode > 0)
                {
                    int totalRow = 0;
                    WsCirculationAccount[] circulationAccounts = wsMobile.GetCirculationAccountList(query.CustomerId,
                                                                                                  query.PageIndex,
                                                                                                    query.PageSize,ref totalRow);


                    CustomerTurnoverListResponse response = new CustomerTurnoverListResponse();
                    int count = query.PageSize;

                    if (query.PageSize > circulationAccounts.Length)
                        count = circulationAccounts.Length;
                    Dictionary<int,byte []> desc=new Dictionary<int, byte[]>();
                    int DescLength = 0;
                    int i = 0;
                    if(circulationAccounts.Length >0)
                    {
                        
                        foreach (WsCirculationAccount account in circulationAccounts)
                        {
                            desc.Add(i,Parser.StrToByteArray(account.DetailDescription));
                            DescLength += desc[i].Length;
                            i++;
                        }
                    }

                    //List<byte> list=new List<byte>();
                    i = 0;
                    if (circulationAccounts.Length > 0)
                    {
                        byte[] buffer =
                            new byte[
                                count*response.CustomerTurnoverListLength + response.TotalRowCount +
                                response.ResposneItemLength + DescLength];

                        int index = 0;
                        index = Copy(Parser.GetInt2Byte(totalRow), buffer, index, response.TotalRowCount);
                        index = Copy(buffer, Convert.ToByte(circulationAccounts.Length), index);
                        foreach (WsCirculationAccount account in circulationAccounts)
                        {
                            index = Copy(buffer, (byte) account.VoucherType, index);
                            index = Copy(Parser.GetInt4Byte(i + 1), buffer, index,
                                         response.VoucherNo);
                            index = Copy(Parser.GetInt8Byte(account.Balanced), buffer, index, response.Balance);
                            index = Copy(Parser.GetInt8Byte(account.Debtor), buffer, index, response.Debitor);
                            index = Copy(Parser.GetInt8Byte(account.Creditor), buffer, index, response.Creditor);
                            index = Copy(buffer, (byte) desc[i].Length, index);
                            index = Copy(Parser.ParseDateToByte(
                                JalaliDate.GetJalaliDateString(account.VoucherDate.ToString())), buffer, index,
                                         response.VoucherDate);
                            index = Copy(desc[i], buffer, index, desc[i].Length);
                            i++;
                        }
                        _header.ResponseCode = 0;
                        _header.Flags = 0;

                        return buffer;
                    }
                    else
                    {
                        //int index = 0;
                        //byte[] buffer = new byte[];
                        //index = Copy(Parser.GetInt2Byte(0), buffer, index, response.TotalRowCount);
                        //index = Copy(buffer, Convert.ToByte(circulationAccounts.Length), index);
                        //return buffer;
                        _header.ResponseCode = 0x03;
                        _header.Flags = 0;
                        byte[] retVal = Parser.StrToByteArray("novoucher");
                        byte[] buffer = new byte[retVal.Length + 2];
                        Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                        Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                        return buffer;
                    }
                }
            }
            catch (Exception exception)
            {
                return GetError(exception, _header);

                //EventLogs.Write(exception);
                //_header.ResponseCode = 0x02;
                //_header.Flags = 0;
                //byte[] retVal = Parser.StrToByteArray(exception.Source);
                //byte[] buffer = new byte[retVal.Length + 2];
                //Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                //Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                //return buffer;

                //_header.ResponseCode = 1;
                //_header.Flags = 0;
                //byte[] tmp = new byte[1];
                //tmp[0] = 1;
                //return tmp;
            }
            return new byte[2];

        }

        public void Logout(LogoutQuery query)
        {
            if (CustomerDictionary.ContainsKey(query.BrokerCode.ToString() + query.CustomerId.ToString()))
                CustomerDictionary.Remove(query.BrokerCode.ToString() + query.CustomerId.ToString());            
        }
    }
}
