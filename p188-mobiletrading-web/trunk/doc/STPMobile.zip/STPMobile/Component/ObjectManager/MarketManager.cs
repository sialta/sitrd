﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using Component.Component;
using Component.Message;
using Component.wsOnlineRLC;
using WS_Mobile = Component.wsOnline.WS_Mobile;

namespace Component.ObjectManager
{
    public class MarketManager : BaseManager, IDisposable
    {
        public byte[] GetMainIndices(byte[] msg, HeaderMsg _header, StateObject st)
        {
            //MarketManager manager=new MarketManager();
            //manager.
            IndicesQuery query = MSG_Indices.DecodeMainIndices(msg);
            wsOnlineRLC.WS_Mobile wsMobile = RLCService.GetRLCServiceObject();

            WsIndices[] indices = wsMobile.GetMainIndices();
            if (indices != null && indices.Length > 0)
            {
                MainIndicesResponse response = new MainIndicesResponse();
                byte[] buffer = new byte[response.FixIndicesResponseLen + indices.Length * response.IndicesResposneItemLength];
                int index = 0;
                DateTime dateTime = indices[0].DateTime;
                string strtm = Globals.GetStringTime(dateTime);

                index = Copy(Parser.ParseShamciDateToByte(
                    JalaliDate.GetJalaliDateString(dateTime.ToShortDateString()).Replace("/", ""),
                    strtm), buffer, index,
                             response.IndicesDateTime);

                //index = Copy(Parser.GetInt2Byte(indices.Length), buffer, index, response.IndicesCount);
                index = Copy(buffer, Convert.ToByte(indices.Length), index);
                foreach (WsIndices wsIndices in indices)
                {
                    index = Copy(Parser.StrToByteArray(wsIndices.NscCode), buffer, index, response.NSCCode);

                    index = Copy(Parser.ParseDoubleTo3Byte(wsIndices.LastValue), buffer, index,
                                 response.LatestValueReal + response.LatestValueMantissa);
                    index = Copy(Parser.ParseDoubleTo3Byte(wsIndices.MaxValue), buffer, index,
                                 response.MaxValueReal + response.MaxValueMantissa);
                    index = Copy(Parser.ParseDoubleTo3Byte(wsIndices.MinValue), buffer, index,
                                 response.MinValueReal + response.MinValueMantissa);
                    index = Copy(Parser.ParseDoubleTo3Byte(wsIndices.ChangeReal), buffer, index,
                                 response.ChangeValueReal + response.ChangeValueMantissa);
                    index = Copy(Parser.ParseDoubleTo2Byte(wsIndices.ChangePercent), buffer, index,
                                 response.PercentReal + response.PercentMantissa);

                    byte state = 0;

                    if (wsIndices.ChangePercent > 0)
                        state++;
                    else if (wsIndices.ChangePercent < 0)
                        state += 2;

                    if (Math.Abs(wsIndices.ChangePercent) - Math.Floor(Math.Abs(wsIndices.ChangePercent)) < 0.1)
                        state += 4;

                    index = Copy(buffer, state, index);

                }
                return buffer;
            }
            else
            {
                //_header.ResponseCode = Convert.ToByte("noindices");
                //_header.Flags = 0;
                ////retVal = new byte[ret.Length];
                //return Parser.StrToByteArray("noindices");

                _header.ResponseCode = 0x03;
                _header.Flags = 0;
                byte[] retVal = Parser.StrToByteArray("noindices");
                byte[] buffer = new byte[retVal.Length + 2];
                Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                return buffer;

            }
        }

        public byte[] GetMarketInfo(byte[] msg, HeaderMsg _header, StateObject st)
        {
            MarketActivityQuery query = MSG_MarketActivity.DecodeMarketActivity(msg);
            wsOnlineRLC.WS_Mobile wsMobile = RLCService.GetRLCServiceObject();

            WsMarketActivity marketActivity = wsMobile.GetMarketActivity();
            if (marketActivity != null)
            {
                MarketActivityResponse response = new MarketActivityResponse();
                byte[] buffer = new byte[response.MarketActivityResponseLen];
                int index = 0;

                DateTime dateTime = marketActivity.DateTime;
                string strtm = Globals.GetStringTime(dateTime);

                index = Copy(Parser.GetInt8Byte(Convert.ToInt32(marketActivity.TotalTradeValue / 1000000)), buffer, index,
                             response.TotalTradeValueField);
                index = Copy(Parser.GetInt8Byte(marketActivity.TotalNoSharesTraded), buffer, index,
                             response.TotalNoSharesTradedField);
                index = Copy(Parser.GetInt3Byte(marketActivity.TotalNoTrade), buffer, index, response.TotalNoTradeField);
                index = Copy(Parser.ParseShamciDateToByte(
                    JalaliDate.GetJalaliDateString(dateTime.ToShortDateString()).Replace("/", ""),
                    strtm), buffer, index,
                             response.DateTimeField);
                return buffer;
            }
            else
            {
                _header.ResponseCode = 0x03;
                _header.Flags = 0;
                byte[] retVal = Parser.StrToByteArray("nomarketactivity");
                byte[] buffer = new byte[retVal.Length + 2];
                Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                return buffer;
            }
        }

        public void Dispose()
        {

        }

        public byte[] GetBestOfMarket(byte[] msg, HeaderMsg _header, StateObject st)
        {
            try
            {
                BestOfMarketQuery query = MSG_MarketActivity.DecodeBestOfMarket(msg);
                wsOnlineRLC.WS_Mobile wsMobile = RLCService.GetRLCServiceObject();

                
               
                wsMobile.CookieContainer = new CookieContainer();

                WsPrice[] bestOfMarket;
                if (query.Status == 0)
                {
                    bestOfMarket = wsMobile.GetBestOfMarket(true);
                }
                else
                {
                    bestOfMarket = wsMobile.GetBestOfMarket(false);
                }

                if (bestOfMarket!=null)
                {
                    BestOfMarketResponse bestOfMarketResponse = new BestOfMarketResponse();
                    int index = 0;
                    byte[] buffer = new byte[bestOfMarketResponse.FixBestOfMarketResponseLen + bestOfMarket.Length * bestOfMarketResponse.FixItemsLen];
                    
                    //We put empty bytes
                    byte[] totalTradedCompanies = new byte[2];
                    index = Copy(buffer, totalTradedCompanies, index, 2);

                    //Current datetime
                    string strtm = Globals.GetStringTime(DateTime.Now);
                    index = Copy(Parser.ParseShamciDateToByte(
                            JalaliDate.GetJalaliDateString(DateTime.Now.ToShortDateString()).Replace("/", ""),
                            strtm), buffer, index, bestOfMarketResponse.ServerDateTime);
                    
                    //All items count
                    byte tmp = Convert.ToByte(bestOfMarket.Length);
                    index = Copy(buffer, tmp, index);

                    foreach (WsPrice wsPrice in bestOfMarket)
                    {
                        index = Copy(Parser.StrToByteArray(wsPrice.NscCode), buffer, index, bestOfMarketResponse.NSCCode);
                        index = Copy(Parser.GetInt4Byte(wsPrice.LastTradedPrice), buffer, index, bestOfMarketResponse.LastTradedPrice);
                        int changePrice = wsPrice.PriceChange;

                        //Make price change +
                        if (changePrice < 0) changePrice *= -1;
                        index = Copy(Parser.GetInt3Byte(changePrice), buffer, index, bestOfMarketResponse.PriceChange);

                        //Percent of price change
                        index = Copy(Parser.GetInt2Byte(wsPrice.RealChangePrice), buffer, index, bestOfMarketResponse.PriceVarReal);
                        index = Copy(buffer, wsPrice.Mantissa, index);

                        tmp = 0;
                        if (wsPrice.IsNegative)
                            tmp += 1;

                        if (Math.Abs(wsPrice.PriceVar) - Math.Abs(wsPrice.RealChangePrice) < 0.1)
                            tmp += 2;

                        index = Copy(buffer, tmp, index);
                    }

                    return buffer;

                }
                else
                {
                    _header.ResponseCode = 0x03;
                    _header.Flags = 0;
                    byte[] retVal = Parser.StrToByteArray("nobestofmarket");
                    byte[] buffer = new byte[retVal.Length + 2];
                    Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                    Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                    return buffer;
                }


            }
            catch (Exception exception)
            {
                return GetError(exception, _header);
            }

            return null;
        }
    }

}
