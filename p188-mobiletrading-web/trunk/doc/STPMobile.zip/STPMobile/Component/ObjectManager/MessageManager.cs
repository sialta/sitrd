﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Component.Component;
using Component.Message;
using Component.wsOnlineRLC;

namespace Component.ObjectManager
{
    public class MessageManager : BaseManager, IDisposable
    {
        public byte[] GetMessageDetailById(byte[] msg, HeaderMsg _header, StateObject st)
        {
            try
            {
                MessageDetailByIdQuery query = MSG_Message.DecodeMessageDetailById(msg);
                wsOnlineRLC.WS_Mobile wsMobile = RLCService.GetRLCServiceObject();
                Ws_Message messageDetail = wsMobile.GetMessageById(query.MessageId);

                if(messageDetail!=null)
                {
                    MessageDetailResponse messageDetailResponse = new MessageDetailResponse();
                    int index = 0;
                    byte[] strByteMessageText = Parser.StrToByteArray(messageDetail.MessageDetail);
                    byte[] buffer = new byte[messageDetailResponse.FixMessageDetailResponseLen + strByteMessageText.Length];
                    index = Copy(Parser.GetInt2Byte(messageDetail.MessageId), buffer, index, messageDetailResponse.MessageId);
                    index = Copy(Parser.GetInt2Byte(strByteMessageText.Length), buffer, index, messageDetailResponse.MessageLength);
                    Copy(strByteMessageText, buffer, index, strByteMessageText.Length);

                    return buffer;
                }
                else
                {
                    _header.ResponseCode = 0x03;
                    _header.Flags = 0;
                    byte[] retVal = Parser.StrToByteArray("nomessagefound");
                    byte[] buffer = new byte[retVal.Length + 2];
                    Copy(Parser.GetInt2Byte(retVal.Length), buffer, 0, 2);
                    Buffer.BlockCopy(retVal, 0, buffer, 2, retVal.Length);
                    return buffer;
                }

            }
            catch (Exception exception)
            {
                return GetError(exception, _header);
            }

            return null;
        }

        public byte[] GetMessageList(byte[] msg, HeaderMsg _header, StateObject st)
        {
            try
            {
                MessageListQuery query = MSG_Message.DecodeMessageList(msg);
                wsOnlineRLC.WS_Mobile wsMobile = RLCService.GetRLCServiceObject();
                Ws_Message[] listOfMessages = wsMobile.GetListOfMessages(query.LastMessageDateTime);

                if (listOfMessages!=null && listOfMessages.Length > 0)
                {
                    MessageListResponse messageListResponse = new MessageListResponse();
                    int index = 0;
                    int byetLen = messageListResponse.FixMessageListResponseLen;
                    int messageCount = 0;
                    foreach (Ws_Message listOfMessage in listOfMessages)
                    {
                        if(!String.IsNullOrEmpty(listOfMessage.MessageDetail.Trim()))
                        {
                            byte[] strByteMessageText = Parser.StrToByteArray(listOfMessage.MessageTitle);
                            byetLen += strByteMessageText.Length + messageListResponse.FixMessageItemLen;
                            messageCount++;
                        }
                    }
                     
                    byte[] buffer = new byte[byetLen];

                    //All items count
                    byte tmp = Convert.ToByte(messageCount);
                    index = Copy(buffer, tmp, index);

                    foreach (Ws_Message listOfMessage in listOfMessages)
                    {
                        if (!String.IsNullOrEmpty(listOfMessage.MessageDetail.Trim()))
                        {
                            index = Copy(Parser.GetInt2Byte(listOfMessage.MessageId), buffer, index,
                                         messageListResponse.MessageId);
                            index = Copy(Parser.ParseDateTimeToByte(listOfMessage.MessageDate), buffer, index,
                                         messageListResponse.MessageDate);
                            byte[] strByteMessageText = Parser.StrToByteArray(listOfMessage.MessageTitle);
                            index = Copy(Parser.GetInt2Byte(strByteMessageText.Length), buffer, index,
                                         messageListResponse.MessageTitleLen);
                            index = Copy(strByteMessageText, buffer, index, strByteMessageText.Length);

                            //Message Status
                            byte[] messageSatus = new byte[1];
                            index = Copy(messageSatus, buffer, index, 1);
                        }
                    }

                    return buffer;
                }
                else
                {
                    MessageListResponse messageListResponse = new MessageListResponse();
                    int index = 0;
                    int byetLen = messageListResponse.FixMessageListResponseLen;
                    byte[] buffer = new byte[byetLen];
                    byte tmp = Convert.ToByte(0);
                    Copy(buffer, tmp, index);
                    return buffer;
                }
            }
            catch (Exception exception)
            {
                return GetError(exception, _header);
            }

            return null;
        }

        public void Dispose()
        {
        }
    }
}
