﻿namespace Component
{
    public enum SortDirection
    {
        Asc,Desc
    }

    public enum Header
    {
        MessageLength = 2,
        SeqNo = 1,
        ResponseCode = 1,
        EncryptionKey = 1,
        Flags = 1,
        ServiceType = 1
    }

    public enum RequestFromType
    {
        Shobe = 8,
        Kargozari = 1,
        WebSite = 2,
        Tel = 3,
        SMS = 4,
        Baje = 5,
        Stand = 6,
        Portfolio = 7,
        MobileInternet = 12
    }

    public enum RequestFinalState
    {
        RequestCanceled = 5, //ابطال شده
        RequestPerformed = 0, //انجام شده
        RequestExpired = 4, //منقضی شده
        BeingProcessed = 15, //در حال بررسی
        BeingSent = 6, //در حال ارسال
        InActive = 3, //غیر فعال
        Done = 0, //انجام شده
        Waiting = 1,
        NotChecked = 9, //تأیید نشده
        Launch = 2, //در حال اقدام
        NotSet = -1,
        IgnoredRemain = 7, //جزؤ باقیمانده
        Stand = 8, //stand ورودی
        IgnoredKarmozd = 10, //حداقل کارمزد
        OtherRequestDone = 11, //در درخواست دیگر انجام شده
        VAP = 12//اینترنت موبایل
    }

    public enum RequestType
    {
        Buy = 0,
        Sell = 1,
        Cross = 2,
        None = -1
    }

    public enum StockType
    {
        Stock = 0,
        HaghTaghadom = 1,
        OraghMosharekat = 2
    }

    public enum GenderType
    {
        Male = 1,
        Female = 0,
        NotSet = 3,
        Sherkat = 2
    }

    public enum PaymentVoucherState
    {
        Payed = 1, //دریافت شده
        Canceled = 0, //ابطال شده
        BeingProcessed = 2 //در حال بررسی
    }

    public enum ReceiptVoucherState
    {
        Confirmed = 1,
        Deleted = 0,
        BeingProcessed = 2
    }

    public enum RequestMoneyFromType
    {
        Shobe = 1,
        Customer = 2,
        InsteadOfSale = 3,
        Automation = 4,
        Unknown = 0
    }
    public enum ReceiptVoucherType
    {
        Fish = 0,
        Havale = 1,
        Check = 2,
        Travel = 3
    }

    public enum VoucherType
    {
        Daryaft=104,
        Pardakht=107,
        Kharid=106,
        Forosh=105,
        Enteghali=108
    }

    public enum ExtensionType
    {
        Security,
        Unknown
    }

    public enum MobileOrderType
    {
        LimiteOrder = 1,
        Market_on_Opening_order = 2,
        Market_Order = 3,
        Stop_Order = 4,
        Market_to_Limit_order = 5,
        None = -1
    }

    public enum ServiceType
    {
        AddOrder = 1,
        OrderList = 2,
        CancelOrder = 3,
        Login = 4,
        ViewAccount = 5,
        Logout = 6,
        StockInfo = 7,
        OrderBook=8,
        CompanyList=0x09,
        StockQueue = 0x10,
        MainIndices = 0x11,
        MarketInfo = 0x12,
        WatchList=0x13,
        StockPrice=0x14,
        BestOfMarket=0x15,
        MessageList=0x16,
        MessageDetail=0x17
    }
 
    public enum OrderListType
    {
        OrderList,
        OrderBook
    }
}