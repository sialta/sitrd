
#region Using

using System;
using System.Configuration;
using System.Reflection;

#endregion

namespace Component
{
    /// <summary>
    /// DataProviders is responible for loading and managing the various CS DataProviders
    /// </summary>
    public sealed class DataProviders
    {

        #region Ctors

        static DataProviders()
        {
            //defaultConnectionString = ConfigurationManager.ConnectionStrings["SqlMFConn"].ConnectionString;
            defaultConnectionString = "server=87.107.120.75;database=host258;uid=sa;pwd=TadbirPardaz@))(;";
            //ConfigurationSettings.GetConfig()
        }

        #endregion

        #region Static Members

        #region Field Members

        private static string defaultConnectionString;
        /// <summary>
        /// This class can not be instantiated
        /// </summary>
        public static readonly string ProviderName = "BaseDataProvider";

        #endregion

        #region Method Members

        #region Public Methods

        /// <summary>
        /// Creates and Caches the ConstructorInfo for the specified provider. 
        /// </summary>
        public static ConstructorInfo CreateConstructorInfo(Provider dataProvider)
        {
            // The assembly should be in \bin or GAC, so we simply need
            // to get an instance of the type
            //
            //Configuration config = Configuration.GetConfig();
            ConstructorInfo providerCnstr = null;
            try
            {
                //string providerTypeName = ((Provider) config.Providers[providerName]).Type;
                Type type = Type.GetType(dataProvider.Type);

                // Insert the type into the cache
                //
                Type[] paramTypes = new Type[2];
                paramTypes[0] = typeof(string);
                paramTypes[1] = typeof(string);

                providerCnstr = type.GetConstructor(paramTypes);
            }
            catch
            {
                ProviderException(dataProvider.Name);
            }

            if (providerCnstr == null)
                ProviderException(dataProvider.Name);

            return providerCnstr;
        }

        /// <summary>
        /// Creates an instance of the provider using Activator. This instance should be
        /// cached since it is an expesivie operation
        /// </summary>
        public static object CreateInstance(Provider dataProvider)
        {
            //Find the current attributes
            string connectionString = null; //dataProvider.Attributes["connectionString"];
            string databaseOwner = null; // dataProvider.Attributes["databaseOwner"];

            GetDataStoreParameters(dataProvider, out connectionString, out databaseOwner);

            //Get the type
            Type type = Type.GetType(dataProvider.Type);

            object newObject = null;
            if (type != null)
            {
                newObject = Activator.CreateInstance(type, new object[] { connectionString });
            }

            if (newObject == null) //If we can not create an instance, throw an exception
                ProviderException(dataProvider.Name);

            return newObject;
        }

        /// <summary>
        /// Creates an instance of the specified provider using the Cached
        /// ConstructorInfo from CreateConstructorInfo
        /// </summary>
        public static object Invoke(Provider dataProvider)
        {
            object[] paramArray = new object[2];


            string dbOwner = null;
            string connstring = null;

            GetDataStoreParameters(dataProvider, out connstring, out dbOwner);

            paramArray[0] = dbOwner;
            paramArray[1] = connstring;

            return CreateConstructorInfo(dataProvider).Invoke(paramArray);
        }

        #endregion

        #region Private Methods

        private static void GetDataStoreParameters(Provider dataProvider, out string connectionString,
                                                   out string databaseOwner)
        {
            databaseOwner = dataProvider.Attributes["databaseOwner"];
            if (databaseOwner == null || databaseOwner.Trim().Length == 0)
                databaseOwner = ConfigurationSettings.AppSettings[dataProvider.Attributes["databaseOwnerStringName"]];

            connectionString = dataProvider.Attributes["connectionString"];
            if (connectionString == null || connectionString.Trim().Length == 0)
                connectionString = defaultConnectionString;
            // ConfigurationSettings.AppSettings[dataProvider.Attributes["databaseOwnerStringName"]];
        }

        #endregion

        #endregion

        #endregion

        #region Exception

        private static void ProviderException(string providerName)
        {
            throw new Exception("Unable to load " + providerName);
        }

        #endregion

    }
}