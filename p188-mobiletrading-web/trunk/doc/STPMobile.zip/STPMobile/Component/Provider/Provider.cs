
#region Using

using System;
using System.Collections.Specialized;
using System.Xml;

#endregion

namespace Component
{
    /// <summary>
    /// Summary description for Provider.
    /// </summary>
    public class Provider
    {

        #region Field Members

        private ExtensionType extensionType;
        private string name;
        private NameValueCollection providerAttributes = new NameValueCollection();
        private string providerType;

        #endregion

        #region Ctors

        public Provider(XmlAttributeCollection attributes)
        {
            // Set the name of the provider
            //
            name = attributes["name"].Value;

            // Set the extension type
            //
            try
            {
                extensionType =
                    (ExtensionType)Enum.Parse(typeof(ExtensionType), attributes["extensionType"].Value, true);
            }
            catch
            {
                // Occassionally get an exception on parsing the extensiontype, so set it to Unknown
                extensionType = ExtensionType.Unknown;
            }

            // Set the type of the provider
            //
            providerType = attributes["type"].Value;

            // Store all the attributes in the attributes bucket
            //
            foreach (XmlAttribute attribute in attributes)
            {
                if ((attribute.Name != "name") && (attribute.Name != "type"))
                    providerAttributes.Add(attribute.Name, attribute.Value);
            }
        }

        #endregion

        #region Property Members

        public NameValueCollection Attributes
        {
            get { return providerAttributes; }
        }

        public ExtensionType ExtensionType
        {
            get { return extensionType; }
        }

        public string Name
        {
            get { return name; }
        }

        public string Type
        {
            get { return providerType; }
        }

        #endregion

    }
}