
#region Using

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Web.Security;

#endregion

namespace Component
{
    /// <summary>
    /// Summary description for BasicDataProvider.
    /// </summary>
    public abstract class CommonDataProvider
    {

        #region Method Members

        public abstract StringDictionary GetSiteSetting(int fundId, string sqlconn);

        public abstract void SaveSiteSetting(SiteSetting setting, int fundId);

        #endregion

        #region Static Members

        #region Field Members

        public static readonly string ProviderName = "CommonDataProvider";

        #endregion

        //#region Method Members

        //public static MembershipUser PopulateMembershipUserFromIDataReader(IDataReader dr)
        //{
        //    string userName = Convert.ToString(dr["UserName"]);
        //    //string email = Convert.ToString(dr["Email"]);
        //    string passwordQuestion = Convert.ToString(dr["PasswordQuestion"]);

        //    DateTime creationDate = Convert.ToDateTime(dr["CreateDate"]);
        //    DateTime LastPasswordChangedDate = Convert.ToDateTime(dr["LastPasswordChangedDate"]);
        //    DateTime lastLockoutDate = Convert.ToDateTime(dr["LastLockoutDate"]);
        //    bool IsLockedOut = Convert.ToBoolean(dr["IsLockedOut"]);

        //    MembershipUser user = MemberShipManagement.GetInstanceUser(userName, passwordQuestion, IsLockedOut, creationDate,
        //                                             LastPasswordChangedDate, lastLockoutDate);
        //    user.IsApproved = Convert.ToBoolean(dr["IsApproved"]);
        //    user.LastActivityDate = Convert.ToDateTime(dr["LastActivityDate"]);
        //    user.LastLoginDate = Convert.ToDateTime(dr["LastLoginDate"]);
        //    user.Comment = Convert.ToString(dr["Comment"]);
        //    user.Email = Convert.ToString(dr["Email"]);

        //    return user;
        //}

        //#endregion

        #endregion

        #region Instance

        private static CommonDataProvider _defaultInstance = null;

        static CommonDataProvider()
        {
            CreateDefaultCommonProvider();
        }

        /// <summary>
        /// Returns an instance of the user-specified data provider class.
        /// </summary>
        /// <returns>An instance of the user-specified data provider class.  This class must inherit the
        /// CommonDataProvider interface.</returns>
        public static CommonDataProvider Instance()
        {
            return _defaultInstance;
        }

        public static CommonDataProvider Instance(Provider dataProvider)
        {
            CommonDataProvider fdp = SKHCache.Get(dataProvider.Name) as CommonDataProvider;
            if (fdp == null)
            {
                fdp = DataProviders.Invoke(dataProvider) as CommonDataProvider;
                SKHCache.Max(dataProvider.Name, fdp);
            }
            return fdp;
        }

        /// <summary>
        /// Creates the Default CommonDataProvider
        /// </summary>
        private static void CreateDefaultCommonProvider()
        {
            // Get the names of the providers
            //
            Configuration config = Configuration.GetConfig();

            // Read the configuration specific information
            // for this provider
            //
            Provider sqlProvider = (Provider)config.Providers[ProviderName];


            _defaultInstance = DataProviders.CreateInstance(sqlProvider) as CommonDataProvider;
        }

        #endregion

        #region EventLog

        public abstract EventLogEntry GetEventLogEntry(int entryID);
        public abstract void WriteEventLogEntry(EventLogEntry entry);
        public abstract void ClearEventLog(DateTime date);

        public abstract List<EventLogEntry> GetEventLogEntries(EventType eventType, int eventNumber, int pageIndex,
                                                               int pageSize,
                                                               out int totalRecord);

        public static EventLogEntry PopulateEventLogEntryFromIDataReader(IDataReader dr)
        {
            EventLogEntry entry = new EventLogEntry();
            entry.EntryID = Convert.ToInt32(dr["EventLogID"]);
            entry.Message = Convert.ToString(dr["Message"]).Replace(@"\n", "<br/>");
            entry.Category = Convert.ToString(dr["Category"]).Trim();
            entry.EventID = Convert.ToInt32(dr["EventID"]);
            entry.EventType = (EventType)Enum.Parse(typeof(EventType), dr["EventType"].ToString());
            entry.EventDate = Convert.ToDateTime(dr["EventDate"]);
            entry.MachineName = Convert.ToString(dr["MachineName"]).Trim();
            entry.IpAddress = Convert.ToString(dr["IpAddress"]).Trim();
            entry.UserName = Convert.ToString(dr["UserName"]).Trim();
            entry.Url = Convert.ToString(dr["Url"]).Trim();
            return entry;
        }

        #endregion

    }
}