#region

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Xml;

#endregion

#region

#endregion

namespace Component
{
    public abstract class MobileProvider
    {
        //public abstract List<Pages> GetPages();


        public static readonly string ProviderName = "MobileProvider";

        private static bool HasColumn(string columnName, IDataReader dr, DataTable retrivedColumn)
        {
            columnName = columnName.ToLower();
            foreach (DataRow row in retrivedColumn.Rows)
            {
                if (row["ColumnName"] != null && row["ColumnName"].ToString().ToLower() == columnName &&
                    dr[columnName] != DBNull.Value)
                {
                    return true;
                }
            }
            return false;
        }


        public abstract SiteSetting GetSetting();

        #region Instance

        private static MobileProvider _defaultInstance;

        static MobileProvider()
        {
            CreateDefaultMutualFundProvider();
        }

        /// <summary>
        /// Returns an instance of the user-specified data provider class.
        /// </summary>
        /// <returns>An instance of the user-specified data provider class.  This class must inherit the
        /// CommonDataProvider interface.</returns>
        public static MobileProvider Instance()
        {
            return _defaultInstance;
        }

        /// <summary>
        /// Creates the Default CommonDataProvider
        /// </summary>
        private static void CreateDefaultMutualFundProvider()
        {
            // Get the names of the providers
            //
            Configuration config = Configuration.GetConfig();

            // Read the configuration specific information
            // for this provider
            //
            Provider sqlProvider = (Provider)config.Providers[ProviderName];


            _defaultInstance = DataProviders.CreateInstance(sqlProvider) as MobileProvider;
        }

        #endregion



        public static SiteSetting PopulateSiteSettingFromDataReader(IDataReader reader)
        {
            SiteSetting ret = new SiteSetting();
            DataTable dt = reader.GetSchemaTable();

            if (HasColumn("IfActiveWebSite", reader, dt) && reader["IfActiveWebSite"] != DBNull.Value)
                ret.IsActiveWebSite = Convert.ToBoolean(reader["IfActiveWebSite"]);

            if (HasColumn("DisableSiteMessage", reader, dt) && reader["DisableSiteMessage"] != DBNull.Value)
                ret.MessageForDeActiveWebSite = Convert.ToString(reader["DisableSiteMessage"]);

            if (HasColumn("ValueConditionRange4Buy", reader, dt) && reader["ValueConditionRange4Buy"] != DBNull.Value)
                ret.ValueConditionRange4Buy = Convert.ToDouble(reader["ValueConditionRange4Buy"]);

            if (HasColumn("ValueConditionRange4TBuy", reader, dt) && reader["ValueConditionRange4TBuy"] != DBNull.Value)
                ret.ValueConditionRange4TBuy = Convert.ToDouble(reader["ValueConditionRange4TBuy"]);

            if (HasColumn("DateConditionRange4Buy", reader, dt) && reader["DateConditionRange4Buy"] != DBNull.Value)
                ret.DateConditionRange4Buy = Convert.ToInt32(reader["DateConditionRange4Buy"]);

            if (HasColumn("DateConditionRange4Sell", reader, dt) && reader["DateConditionRange4Sell"] != DBNull.Value)
                ret.DateConditionRange4Sell = Convert.ToInt32(reader["DateConditionRange4Sell"]);

            //if (HasColumn("IeUser", reader, dt) && reader["IeUser"] != DBNull.Value)
            //    ret.IEUser = Convert.ToInt32(reader["IeUser"]);

            //if (HasColumn("BrokerName", reader, dt) && reader["BrokerName"] != DBNull.Value)
            //    ret.BrokerName = reader["BrokerName"].ToString();

            return ret;
        }
        
        public abstract byte CancelRequest(RequestQuery query);
    }
}