﻿
#region Using

using System;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

#endregion

#region


#endregion

namespace Component
{
    public class CommonUtility
    {

        #region Static Members

        #region Method Members

        public static string accForm(string num)
        {
            if (num.Length < 3)
                return num;

            StringBuilder sb = new StringBuilder(num);
            for (int i = 0; i < num.Length; i += 4)
            {
                if (sb.Length < i + 4)
                    break;
                sb.Insert(sb.Length - i - 3, "،");
            }
            if (sb[0] == '،')
            {
                sb.Remove(0, 1);
            }
            return sb.ToString();
        }

        #endregion

        #endregion

    }
}