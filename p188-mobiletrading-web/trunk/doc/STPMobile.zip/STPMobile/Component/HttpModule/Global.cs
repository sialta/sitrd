
#region Using

using System;
using System.Reflection;
using System.Security.Principal;
using System.Web;
using System.Web.Security;

#endregion

/// <summary>
/// Summary description for Global
/// </summary>

namespace Component
{
    public class Global : HttpApplication
    {

        #region Method Members

        #region Application_AuthenticateRequest

        protected void Application_AuthenticateRequest(Object sender, EventArgs e)
        {

        }

        #endregion

        #region Application_BeginRequest

        protected void Application_BeginRequest(Object sender, EventArgs e)
        {
        }

        #endregion

        #region Application_End

        protected void Application_End(Object sender, EventArgs e)
        {
            //string errorMessage = "App Stopped";

            //HttpRuntime runtime =
            //    (HttpRuntime)
            //    typeof (HttpRuntime).InvokeMember("_theRuntime",
            //                                      BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.GetField,
            //                                      null, null, null);
            //if (runtime != null)
            {
                //string shutDownMessage =(string)
                //    runtime.GetType().InvokeMember("_shutDownMessage",
                //                                   BindingFlags.NonPublic | BindingFlags.Instance |
                //                                   BindingFlags.GetField, null, runtime, null);
                //string shutDownStack = string.Empty;
                // (string)runtime.GetType().InvokeMember("_shutDownStack", BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.GetField, null, runtime, null);
                //errorMessage =string.Format("{0}\r\n\r\n_shutDownMessage={1}\r\n\r\n_shutDownStack={2}", errorMessage,shutDownMessage, shutDownStack);
            }

            //EventLogs.Info("Application_End " + errorMessage, "Application", 201);

            //Jobs.Instance().Stop();
        }

        #endregion

        #region Application_EndRequest

        protected void Application_EndRequest(Object sender, EventArgs e)
        {
        }

        #endregion

        #region Application_Error

        protected void Application_Error(Object sender, EventArgs e)
        {
            string errorMessage = "App Stopped";

            HttpRuntime runtime =
                (HttpRuntime)
                typeof(HttpRuntime).InvokeMember("_theRuntime",
                                                  BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.GetField,
                                                  null, null, null);
            if (runtime != null)
            {
                string shutDownMessage =
                    (string)
                    runtime.GetType().InvokeMember("_shutDownMessage",
                                                   BindingFlags.NonPublic | BindingFlags.Instance |
                                                   BindingFlags.GetField, null, runtime, null);
                string shutDownStack =
                    (string)
                    runtime.GetType().InvokeMember("_shutDownStack",
                                                   BindingFlags.NonPublic | BindingFlags.Instance |
                                                   BindingFlags.GetField, null, runtime, null);
                errorMessage =
                    string.Format("{0}\r\n\r\n_shutDownMessage={1}\r\n\r\n_shutDownStack={2}", errorMessage,
                                  shutDownMessage, shutDownStack);
            }

            //EventLogs.Info("Application_Error " + errorMessage, "Application", 201);

            //Jobs.Instance().Stop();
        }

        #endregion

        #region Application_Start

        protected void Application_Start(Object sender, EventArgs e)
        {
            //EventLogs.Info("App Started", "Application", 200);
            //Jobs.Instance().Start();

        }

        #endregion

        #region Session_End

        protected void Session_End(Object sender, EventArgs e)
        {
        }

        #endregion

        #region Session_Start

        protected void Session_Start(Object sender, EventArgs e)
        {
        }

        #endregion

        #endregion

    }
}