﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class LoginQuery:BaseQuery
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string BourseCode { get; set; }
        public DateTime LastLoginDateTime { get; set; }
        public int BrokerCode { get; set; }
        public int Version { get; set; }
    }

    public class LogoutQuery:BaseQuery
    {
        public int BrokerCode { get; set; }
        public int CustomerId { get; set; }
    }
}
