﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Component
{
    public class CustomerTurnoverQuery : BaseQuery
    {        
        public int CustomerId { get; set; }
        public int VoucherNo { get; set; }
    }
}
