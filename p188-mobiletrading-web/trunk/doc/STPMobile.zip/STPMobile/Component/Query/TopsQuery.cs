﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class TopsQuery:BaseQuery
    {
        public int State { get; set; }
        public string AccountCode { get; set; }
    }
}
