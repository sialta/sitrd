﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Component
{
    public class RequestQuery: BaseQuery
    {
        public RequestQuery()
        {
            SortOrderItem = "RequestDate";
            SortOrderType = SortDirection.Desc;
        }

        public int CustomerId { get; set; }

        public long OrderId { get; set; }
    }
}