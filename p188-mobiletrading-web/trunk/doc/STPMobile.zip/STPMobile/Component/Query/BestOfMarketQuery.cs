﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class BestOfMarketQuery : BaseQuery
    {
        public byte Status{ set; get; }
    }
}
