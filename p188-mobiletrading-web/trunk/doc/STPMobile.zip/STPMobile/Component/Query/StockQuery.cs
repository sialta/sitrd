﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Component
{
    public class StockQuery:BaseQuery
    {
        public string NscCode { get; set; }
        public string symbolId { get; set; }
        public bool GetAll { get; set; }
    }

    public class WatchListQuery:BaseQuery
    {
        public int SymbolCount { get; set; }
        public List<string> NSCCode { get; set; }        

    }
}
