
#region Using

using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;

#endregion

namespace Component
{
    public abstract class BaseQuery
    {

        #region Field Members

        private int _brokerCode = 0;
        private int _pageIndex = 0;
        private int _pageSize = 5;
        private string _sortOrderItem;
        private SortDirection _sortOrderType = SortDirection.Asc;
        private int _customerId;
        #endregion

        #region Property Members

        public int BrokerCode
        {
            get { return _brokerCode; }
            set { _brokerCode = value; }
        }

        public int CustomerId
        {
            get { return _customerId; }
            set { _customerId = value; }
        }

        #region PageIndex

        public int PageIndex
        {
            get { return _pageIndex; }
            set { _pageIndex = value; }
        }

        #endregion

        #region PageSize

        public int PageSize
        {
            get { return _pageSize; }
            set { _pageSize = value; }
        }

        #endregion

        #region SortOrderItem

        public string SortOrderItem
        {
            get { return _sortOrderItem; }
            set { _sortOrderItem = value; }
        }

        #endregion

        #region SortOrderType

        public SortDirection SortOrderType
        {
            get { return _sortOrderType; }
            set { _sortOrderType = value; }
        }

        #endregion

        #region TopResult

        public int TopResult { get; set; }

        #endregion

        #region TotalRecord

        public int TotalRecord { get; set; }

        #endregion

        #region XmlOutPut

        public bool XmlOutPut { get; set; }

        #endregion

        #endregion

        #region Method Members

        protected int GetLower()
        {
            return Globals.GetLowerPage(_pageSize, _pageIndex);
        }

        protected int GetUpper()
        {
            return Globals.GetUpperPage(_pageIndex, _pageSize);
        }

        #endregion

        #region Static Members

        #region Method Members

        protected static string CleanSearchString(string searchString)
        {
            //return searchString;

            if (Globals.IsNullorEmpty(searchString))
                return null;

            // Do wild card replacements
            //searchString = searchString.Replace("*", "%");

            // Remove known bad SQL characters
            searchString = Regex.Replace(searchString, "--|;|'|\"", " ", RegexOptions.Compiled | RegexOptions.Multiline);

            // Finally remove any extra spaces from the string
            //searchString = Regex.Replace(searchString, " {1,}", " ", RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.Multiline);

            return searchString;
        }

        #endregion

        #endregion

    }
}