/**
 * WS_MobileSoap_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface WS_MobileSoap_PortType extends Remote {
    public GetMainIndicesResponse getMainIndices(GetMainIndices parameters) throws RemoteException;
    public GetMarketActivityResponse getMarketActivity(GetMarketActivity parameters) throws RemoteException;
    public GetSymbolPriceResponse getSymbolPrice(GetSymbolPrice parameters) throws RemoteException;
    public GetWatchListResponse getWatchList(GetWatchList parameters) throws RemoteException;
    public GetBestOfMarketResponse getBestOfMarket(GetBestOfMarket parameters) throws RemoteException;
    public GetListOfMessagesResponse getListOfMessages(GetListOfMessages parameters) throws RemoteException;
    public GetMessageByIdResponse getMessageById(GetMessageById parameters) throws RemoteException;
    public GetSymbolQueueResponse getSymbolQueue(GetSymbolQueue parameters) throws RemoteException;
    public ExchangeCompanyListResponse exchangeCompanyList(ExchangeCompanyList parameters) throws RemoteException;
}
