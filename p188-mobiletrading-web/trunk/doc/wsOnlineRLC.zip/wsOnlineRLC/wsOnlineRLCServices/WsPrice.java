/**
 * WsPrice.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices;
/**
 * WsPrice.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

public class WsPrice  implements java.io.Serializable {
    private String date;

    private String time;

    private boolean isNegative;

    private boolean isRight;

    private boolean isFaraBourse;

    private String nscCode;

    private int lastTradedPrice;

    private int realChangePrice;

    private org.apache.axis.types.UnsignedByte mantissa;

    private int closingPrice;

    private int highAllowedPrice;

    private int lowAllowedPrice;

    private double priceVar;

    private int priceChange;

    private long totalNumberOfSharesTraded;

    public WsPrice() {
    }

    public WsPrice(
           String date,
           String time,
           boolean isNegative,
           boolean isRight,
           boolean isFaraBourse,
           String nscCode,
           int lastTradedPrice,
           int realChangePrice,
           org.apache.axis.types.UnsignedByte mantissa,
           int closingPrice,
           int highAllowedPrice,
           int lowAllowedPrice,
           double priceVar,
           int priceChange,
           long totalNumberOfSharesTraded) {
           this.date = date;
           this.time = time;
           this.isNegative = isNegative;
           this.isRight = isRight;
           this.isFaraBourse = isFaraBourse;
           this.nscCode = nscCode;
           this.lastTradedPrice = lastTradedPrice;
           this.realChangePrice = realChangePrice;
           this.mantissa = mantissa;
           this.closingPrice = closingPrice;
           this.highAllowedPrice = highAllowedPrice;
           this.lowAllowedPrice = lowAllowedPrice;
           this.priceVar = priceVar;
           this.priceChange = priceChange;
           this.totalNumberOfSharesTraded = totalNumberOfSharesTraded;
    }


    /**
     * Gets the date value for this WsPrice.
     *
     * @return date
     */
    public String getDate() {
        return date;
    }


    /**
     * Sets the date value for this WsPrice.
     *
     * @param date
     */
    public void setDate(String date) {
        this.date = date;
    }


    /**
     * Gets the time value for this WsPrice.
     *
     * @return time
     */
    public String getTime() {
        return time;
    }


    /**
     * Sets the time value for this WsPrice.
     *
     * @param time
     */
    public void setTime(String time) {
        this.time = time;
    }


    /**
     * Gets the isNegative value for this WsPrice.
     *
     * @return isNegative
     */
    public boolean isIsNegative() {
        return isNegative;
    }


    /**
     * Sets the isNegative value for this WsPrice.
     *
     * @param isNegative
     */
    public void setIsNegative(boolean isNegative) {
        this.isNegative = isNegative;
    }


    /**
     * Gets the isRight value for this WsPrice.
     *
     * @return isRight
     */
    public boolean isIsRight() {
        return isRight;
    }


    /**
     * Sets the isRight value for this WsPrice.
     *
     * @param isRight
     */
    public void setIsRight(boolean isRight) {
        this.isRight = isRight;
    }


    /**
     * Gets the isFaraBourse value for this WsPrice.
     *
     * @return isFaraBourse
     */
    public boolean isIsFaraBourse() {
        return isFaraBourse;
    }


    /**
     * Sets the isFaraBourse value for this WsPrice.
     *
     * @param isFaraBourse
     */
    public void setIsFaraBourse(boolean isFaraBourse) {
        this.isFaraBourse = isFaraBourse;
    }


    /**
     * Gets the nscCode value for this WsPrice.
     *
     * @return nscCode
     */
    public String getNscCode() {
        return nscCode;
    }


    /**
     * Sets the nscCode value for this WsPrice.
     *
     * @param nscCode
     */
    public void setNscCode(String nscCode) {
        this.nscCode = nscCode;
    }


    /**
     * Gets the lastTradedPrice value for this WsPrice.
     *
     * @return lastTradedPrice
     */
    public int getLastTradedPrice() {
        return lastTradedPrice;
    }


    /**
     * Sets the lastTradedPrice value for this WsPrice.
     *
     * @param lastTradedPrice
     */
    public void setLastTradedPrice(int lastTradedPrice) {
        this.lastTradedPrice = lastTradedPrice;
    }


    /**
     * Gets the realChangePrice value for this WsPrice.
     *
     * @return realChangePrice
     */
    public int getRealChangePrice() {
        return realChangePrice;
    }


    /**
     * Sets the realChangePrice value for this WsPrice.
     *
     * @param realChangePrice
     */
    public void setRealChangePrice(int realChangePrice) {
        this.realChangePrice = realChangePrice;
    }


    /**
     * Gets the mantissa value for this WsPrice.
     *
     * @return mantissa
     */
    public org.apache.axis.types.UnsignedByte getMantissa() {
        return mantissa;
    }


    /**
     * Sets the mantissa value for this WsPrice.
     *
     * @param mantissa
     */
    public void setMantissa(org.apache.axis.types.UnsignedByte mantissa) {
        this.mantissa = mantissa;
    }


    /**
     * Gets the closingPrice value for this WsPrice.
     *
     * @return closingPrice
     */
    public int getClosingPrice() {
        return closingPrice;
    }


    /**
     * Sets the closingPrice value for this WsPrice.
     *
     * @param closingPrice
     */
    public void setClosingPrice(int closingPrice) {
        this.closingPrice = closingPrice;
    }


    /**
     * Gets the highAllowedPrice value for this WsPrice.
     *
     * @return highAllowedPrice
     */
    public int getHighAllowedPrice() {
        return highAllowedPrice;
    }


    /**
     * Sets the highAllowedPrice value for this WsPrice.
     *
     * @param highAllowedPrice
     */
    public void setHighAllowedPrice(int highAllowedPrice) {
        this.highAllowedPrice = highAllowedPrice;
    }


    /**
     * Gets the lowAllowedPrice value for this WsPrice.
     *
     * @return lowAllowedPrice
     */
    public int getLowAllowedPrice() {
        return lowAllowedPrice;
    }


    /**
     * Sets the lowAllowedPrice value for this WsPrice.
     *
     * @param lowAllowedPrice
     */
    public void setLowAllowedPrice(int lowAllowedPrice) {
        this.lowAllowedPrice = lowAllowedPrice;
    }


    /**
     * Gets the priceVar value for this WsPrice.
     *
     * @return priceVar
     */
    public double getPriceVar() {
        return priceVar;
    }


    /**
     * Sets the priceVar value for this WsPrice.
     *
     * @param priceVar
     */
    public void setPriceVar(double priceVar) {
        this.priceVar = priceVar;
    }


    /**
     * Gets the priceChange value for this WsPrice.
     *
     * @return priceChange
     */
    public int getPriceChange() {
        return priceChange;
    }


    /**
     * Sets the priceChange value for this WsPrice.
     *
     * @param priceChange
     */
    public void setPriceChange(int priceChange) {
        this.priceChange = priceChange;
    }


    /**
     * Gets the totalNumberOfSharesTraded value for this WsPrice.
     *
     * @return totalNumberOfSharesTraded
     */
    public long getTotalNumberOfSharesTraded() {
        return totalNumberOfSharesTraded;
    }


    /**
     * Sets the totalNumberOfSharesTraded value for this WsPrice.
     *
     * @param totalNumberOfSharesTraded
     */
    public void setTotalNumberOfSharesTraded(long totalNumberOfSharesTraded) {
        this.totalNumberOfSharesTraded = totalNumberOfSharesTraded;
    }

    private Object __equalsCalc = null;
    public synchronized boolean equals(Object obj) {
        if (!(obj instanceof WsPrice)) return false;
        WsPrice other = (WsPrice) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
            ((this.date==null && other.getDate()==null) ||
             (this.date!=null &&
              this.date.equals(other.getDate()))) &&
            ((this.time==null && other.getTime()==null) ||
             (this.time!=null &&
              this.time.equals(other.getTime()))) &&
            this.isNegative == other.isIsNegative() &&
            this.isRight == other.isIsRight() &&
            this.isFaraBourse == other.isIsFaraBourse() &&
            ((this.nscCode==null && other.getNscCode()==null) ||
             (this.nscCode!=null &&
              this.nscCode.equals(other.getNscCode()))) &&
            this.lastTradedPrice == other.getLastTradedPrice() &&
            this.realChangePrice == other.getRealChangePrice() &&
            ((this.mantissa==null && other.getMantissa()==null) ||
             (this.mantissa!=null &&
              this.mantissa.equals(other.getMantissa()))) &&
            this.closingPrice == other.getClosingPrice() &&
            this.highAllowedPrice == other.getHighAllowedPrice() &&
            this.lowAllowedPrice == other.getLowAllowedPrice() &&
            this.priceVar == other.getPriceVar() &&
            this.priceChange == other.getPriceChange() &&
            this.totalNumberOfSharesTraded == other.getTotalNumberOfSharesTraded();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDate() != null) {
            _hashCode += getDate().hashCode();
        }
        if (getTime() != null) {
            _hashCode += getTime().hashCode();
        }
        _hashCode += (isIsNegative() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsRight() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsFaraBourse() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getNscCode() != null) {
            _hashCode += getNscCode().hashCode();
        }
        _hashCode += getLastTradedPrice();
        _hashCode += getRealChangePrice();
        if (getMantissa() != null) {
            _hashCode += getMantissa().hashCode();
        }
        _hashCode += getClosingPrice();
        _hashCode += getHighAllowedPrice();
        _hashCode += getLowAllowedPrice();
        _hashCode += new Double(getPriceVar()).hashCode();
        _hashCode += getPriceChange();
        _hashCode += new Long(getTotalNumberOfSharesTraded()).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WsPrice.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "WsPrice"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("date");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "Date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("time");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "Time"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isNegative");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "IsNegative"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isRight");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "IsRight"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isFaraBourse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "IsFaraBourse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nscCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "NscCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastTradedPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "LastTradedPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("realChangePrice");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "RealChangePrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mantissa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "Mantissa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "unsignedByte"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("closingPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ClosingPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("highAllowedPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "HighAllowedPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lowAllowedPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "LowAllowedPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("priceVar");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "PriceVar"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("priceChange");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "PriceChange"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalNumberOfSharesTraded");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "TotalNumberOfSharesTraded"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           String mechType,
           Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           String mechType,
           Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
