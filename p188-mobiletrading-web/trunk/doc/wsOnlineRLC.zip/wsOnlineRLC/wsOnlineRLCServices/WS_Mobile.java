/**
 * WS_Mobile.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices;

public interface WS_Mobile extends javax.xml.rpc.Service {
    public String getWS_MobileSoap12Address();

    public WS_MobileSoap_PortType getWS_MobileSoap12() throws javax.xml.rpc.ServiceException;

    public WS_MobileSoap_PortType getWS_MobileSoap12(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public String getWS_MobileSoapAddress();

    public WS_MobileSoap_PortType getWS_MobileSoap() throws javax.xml.rpc.ServiceException;

    public WS_MobileSoap_PortType getWS_MobileSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
