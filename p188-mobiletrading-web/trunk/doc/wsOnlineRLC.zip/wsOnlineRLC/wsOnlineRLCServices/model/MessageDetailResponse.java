package com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.model;

/**
 * Created by IntelliJ IDEA.
 * User: Sarvenaz
 * Date: Jul 30, 2011
 * Time: 1:58:12 PM
 */
public class MessageDetailResponse {
    public int FixMessageDetailResponseLen = 4;
    public int MessageId = 2;
    public int MessageLength = 2;
}
