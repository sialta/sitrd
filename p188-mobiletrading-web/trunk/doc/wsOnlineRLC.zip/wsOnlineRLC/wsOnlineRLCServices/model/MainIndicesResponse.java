package com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.model;

/**
 * Created by IntelliJ IDEA.
 * User: Sarvenaz
 * Date: Jul 24, 2011
 * Time: 3:09:33 PM
 */
public class MainIndicesResponse {

    public int FixIndicesResponseLen = 5;

    public int IndicesCount = 1;
    public int IndicesDateTime = 4;


    public int IndicesResposneItemLength = 27;
    /// <summary>
    /// indices Item
    /// </summary>
    public int NSCCode = 12;
    public int LatestValueReal = 2;
    public int LatestValueMantissa = 1;
    public int MaxValueReal = 2;
    public int MaxValueMantissa = 1;
    public int MinValueReal = 2;
    public int MinValueMantissa = 1;
    public int ChangeValueReal = 2;
    public int ChangeValueMantissa = 1;
    public int PercentReal = 1;
    public int PercentMantissa = 1;
    public int State = 1;
}
