package com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.model;

/**
 * Created by IntelliJ IDEA.
 * User: Sarvenaz
 * Date: Jul 25, 2011
 * Time: 4:48:03 PM
 */
public class BestOfMarketResponse {
    public int FixBestOfMarketResponseLen = 7;
    public int AllTradedCompanies = 2;
    public int ServerDateTime = 4;
    public int NumberOfItems = 1;

    public int FixItemsLen = 25;
    public int NSCCode = 12;
    public int LastTradedPrice = 4;
    public int PriceChange = 3;
    public int PriceVarReal = 4;
    public int PriceVarMantissa = 1;
    public int Status = 1;
}
