package com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.model;

/**
 * Created by IntelliJ IDEA.
 * User: Sarvenaz
 * Date: Jul 25, 2011
 * Time: 4:47:14 PM
 */
public class MarketActivityResponse {
    public int MarketActivityResponseLen = 22;
    public int DateTimeField=4;
    public int TotalNoTradeField=2;
    public int TotalTradeValueField=8;
    public int TotalNoSharesTradedField=8;
}
