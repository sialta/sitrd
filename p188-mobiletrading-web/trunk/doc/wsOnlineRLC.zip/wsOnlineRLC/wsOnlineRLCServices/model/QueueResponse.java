package com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.model;

/**
 * Created by IntelliJ IDEA.
 * User: Sahar Ta
 * Date: Jul 26, 2011
 * Time: 9:39:02 AM
 */
public interface QueueResponse {

    public int NUMBER_OF_ITEM_LENGTH = 1;
    public int FIX_ITEM_LENGTH = 10;

    public int BEST_PRICE_LENGTH = 4;
    public int BEST_VALUE_LENGTH = 4;
    public int BEST_NO_LENGTH = 2;



}
