package com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.model;

/**
 * Created by IntelliJ IDEA.
 * User: Sarvenaz
 * Date: Jul 30, 2011
 * Time: 1:57:51 PM
 */
public class MessageListResponse {
    public int FixMessageListResponseLen = 1;
    public int FixMessageItemLen = 8;
    public int MessageId = 2;
    public int MessageDate = 4;
    public int MessageTitleLen = 1;
    public int MessageStatus = 1;
}
