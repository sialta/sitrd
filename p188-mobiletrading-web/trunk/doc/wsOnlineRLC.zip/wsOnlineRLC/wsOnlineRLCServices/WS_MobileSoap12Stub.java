/**
 * WS_MobileSoap12Stub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices;

public class WS_MobileSoap12Stub extends org.apache.axis.client.Stub implements com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.WS_MobileSoap_PortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[9];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetMainIndices");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "GetMainIndices"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tempuri.org/", ">GetMainIndices"), com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMainIndices.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", ">GetMainIndicesResponse"));
        oper.setReturnClass(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMainIndicesResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetMainIndicesResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetMarketActivity");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "GetMarketActivity"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tempuri.org/", ">GetMarketActivity"), com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMarketActivity.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", ">GetMarketActivityResponse"));
        oper.setReturnClass(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMarketActivityResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetMarketActivityResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetSymbolPrice");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "GetSymbolPrice"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tempuri.org/", ">GetSymbolPrice"), com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolPrice.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", ">GetSymbolPriceResponse"));
        oper.setReturnClass(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolPriceResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetSymbolPriceResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetWatchList");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "GetWatchList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tempuri.org/", ">GetWatchList"), com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetWatchList.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", ">GetWatchListResponse"));
        oper.setReturnClass(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetWatchListResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetWatchListResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetBestOfMarket");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "GetBestOfMarket"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tempuri.org/", ">GetBestOfMarket"), com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetBestOfMarket.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", ">GetBestOfMarketResponse"));
        oper.setReturnClass(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetBestOfMarketResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetBestOfMarketResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetListOfMessages");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "GetListOfMessages"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tempuri.org/", ">GetListOfMessages"), com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetListOfMessages.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", ">GetListOfMessagesResponse"));
        oper.setReturnClass(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetListOfMessagesResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetListOfMessagesResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetMessageById");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "GetMessageById"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tempuri.org/", ">GetMessageById"), com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMessageById.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", ">GetMessageByIdResponse"));
        oper.setReturnClass(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMessageByIdResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetMessageByIdResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetSymbolQueue");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "GetSymbolQueue"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tempuri.org/", ">GetSymbolQueue"), com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolQueue.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", ">GetSymbolQueueResponse"));
        oper.setReturnClass(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolQueueResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tempuri.org/", "GetSymbolQueueResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ExchangeCompanyList");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tempuri.org/", "ExchangeCompanyList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tempuri.org/", ">ExchangeCompanyList"), com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.ExchangeCompanyList.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tempuri.org/", ">ExchangeCompanyListResponse"));
        oper.setReturnClass(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.ExchangeCompanyListResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tempuri.org/", "ExchangeCompanyListResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

    }

    public WS_MobileSoap12Stub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public WS_MobileSoap12Stub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public WS_MobileSoap12Stub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.1");
            Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">ExchangeCompanyList");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.ExchangeCompanyList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">ExchangeCompanyListResponse");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.ExchangeCompanyListResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetBestOfMarket");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetBestOfMarket.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetBestOfMarketResponse");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetBestOfMarketResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetListOfMessages");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetListOfMessages.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetListOfMessagesResponse");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetListOfMessagesResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetMainIndices");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMainIndices.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetMainIndicesResponse");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMainIndicesResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetMarketActivity");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMarketActivity.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetMarketActivityResponse");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMarketActivityResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetMessageById");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMessageById.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetMessageByIdResponse");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMessageByIdResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetSymbolPrice");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolPrice.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetSymbolPriceResponse");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolPriceResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetSymbolQueue");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolQueue.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetSymbolQueueResponse");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolQueueResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetWatchList");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetWatchList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", ">GetWatchListResponse");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetWatchListResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", "ArrayOfString");
            cachedSerQNames.add(qName);
            cls = String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://tempuri.org/", "string");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tempuri.org/", "ArrayOfWs_Message");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.Ws_Message[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tempuri.org/", "Ws_Message");
            qName2 = new javax.xml.namespace.QName("http://tempuri.org/", "Ws_Message");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tempuri.org/", "ArrayOfWsIndices");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.WsIndices[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tempuri.org/", "WsIndices");
            qName2 = new javax.xml.namespace.QName("http://tempuri.org/", "WsIndices");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tempuri.org/", "ArrayOfWsPrice");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.WsPrice[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tempuri.org/", "WsPrice");
            qName2 = new javax.xml.namespace.QName("http://tempuri.org/", "WsPrice");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tempuri.org/", "ArrayOfWsQueue");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.WsQueue[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tempuri.org/", "WsQueue");
            qName2 = new javax.xml.namespace.QName("http://tempuri.org/", "WsQueue");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tempuri.org/", "Ws_Message");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.Ws_Message.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", "WsIndices");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.WsIndices.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", "WsMarketActivity");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.WsMarketActivity.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", "WsPrice");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.WsPrice.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", "WsQueue");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.WsQueue.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tempuri.org/", "WsWatchList");
            cachedSerQNames.add(qName);
            cls = com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.WsWatchList.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                String key = (String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the webservice, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        Class cls = (Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            Class sf = (Class)
                                 cachedSerFactories.get(i);
                            Class df = (Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public GetMainIndicesResponse getMainIndices(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMainIndices parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tempuri.org/GetMainIndices");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "GetMainIndices"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        Object _resp = _call.invoke(new Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMainIndicesResponse) _resp;
            } catch (Exception _exception) {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMainIndicesResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMainIndicesResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public GetMarketActivityResponse getMarketActivity(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMarketActivity parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tempuri.org/GetMarketActivity");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "GetMarketActivity"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        Object _resp = _call.invoke(new Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMarketActivityResponse) _resp;
            } catch (Exception _exception) {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMarketActivityResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMarketActivityResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public GetSymbolPriceResponse getSymbolPrice(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolPrice parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tempuri.org/GetSymbolPrice");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "GetSymbolPrice"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        Object _resp = _call.invoke(new Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolPriceResponse) _resp;
            } catch (Exception _exception) {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolPriceResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolPriceResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public GetWatchListResponse getWatchList(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetWatchList parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tempuri.org/GetWatchList");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "GetWatchList"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        Object _resp = _call.invoke(new Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetWatchListResponse) _resp;
            } catch (Exception _exception) {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetWatchListResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetWatchListResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public GetBestOfMarketResponse getBestOfMarket(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetBestOfMarket parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tempuri.org/GetBestOfMarket");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "GetBestOfMarket"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        Object _resp = _call.invoke(new Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetBestOfMarketResponse) _resp;
            } catch (Exception _exception) {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetBestOfMarketResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetBestOfMarketResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public GetListOfMessagesResponse getListOfMessages(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetListOfMessages parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tempuri.org/GetListOfMessages");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "GetListOfMessages"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        Object _resp = _call.invoke(new Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetListOfMessagesResponse) _resp;
            } catch (Exception _exception) {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetListOfMessagesResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetListOfMessagesResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public GetMessageByIdResponse getMessageById(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMessageById parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tempuri.org/GetMessageById");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "GetMessageById"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        Object _resp = _call.invoke(new Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMessageByIdResponse) _resp;
            } catch (Exception _exception) {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMessageByIdResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetMessageByIdResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public GetSymbolQueueResponse getSymbolQueue(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolQueue parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tempuri.org/GetSymbolQueue");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "GetSymbolQueue"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        Object _resp = _call.invoke(new Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolQueueResponse) _resp;
            } catch (Exception _exception) {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolQueueResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.GetSymbolQueueResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public ExchangeCompanyListResponse exchangeCompanyList(com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.ExchangeCompanyList parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tempuri.org/ExchangeCompanyList");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP12_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "ExchangeCompanyList"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        Object _resp = _call.invoke(new Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.ExchangeCompanyListResponse) _resp;
            } catch (Exception _exception) {
                return (com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.ExchangeCompanyListResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.sefryek.broker.webservices.wsOnlineRLC.wsOnlineRLCServices.ExchangeCompanyListResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
