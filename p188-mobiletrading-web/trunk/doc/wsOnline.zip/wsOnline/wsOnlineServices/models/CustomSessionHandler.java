package com.sefryek.broker.webservices.wsOnline.wsOnlineServices.models;

import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: Mahta
 * Date: Jul 30, 2011
 * Time: 11:58:59 AM
 */
public abstract class CustomSessionHandler {
    public static String HEADER_COOKIE = "Cookie";
}
