package com.sefryek.broker.webservices.wsOnline.wsOnlineServices.models;

/**
 * Created by IntelliJ IDEA.
 * User: Mahta
 * Date: Jul 19, 2011
 * Time: 3:26:39 PM
 */
public class LoginResponseItems {
    
}
