/**
 * WsOrderMessageHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnline.wsOnlineServices.holders;

import com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WsOrderMessage;

import javax.xml.rpc.holders.Holder;

public final class WsOrderMessageHolder implements Holder {
    
    public WsOrderMessage value;

    public WsOrderMessageHolder() {
    }

    public WsOrderMessageHolder(WsOrderMessage value) {
        this.value = value;
    }

}
