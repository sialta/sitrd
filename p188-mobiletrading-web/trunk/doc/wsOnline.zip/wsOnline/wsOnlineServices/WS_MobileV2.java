/**
 * WS_MobileV2.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnline.wsOnlineServices;

public interface WS_MobileV2 extends javax.xml.rpc.Service {
    public java.lang.String getWS_MobileV2Soap12Address();

    public com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_PortType getWS_MobileV2Soap12() throws javax.xml.rpc.ServiceException;

    public com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_PortType getWS_MobileV2Soap12(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getWS_MobileV2SoapAddress();

    public com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_PortType getWS_MobileV2Soap() throws javax.xml.rpc.ServiceException;

    public com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_PortType getWS_MobileV2Soap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
