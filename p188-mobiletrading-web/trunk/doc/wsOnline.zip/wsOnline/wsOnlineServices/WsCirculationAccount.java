/**
 * WsCirculationAccount.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnline.wsOnlineServices;

public class WsCirculationAccount  implements java.io.Serializable {
    private int voucherNo;

    private String accountCode;

    private java.util.Calendar voucherDate;

    private String detailDescription;

    private double debtor;

    private double creditor;

    private int voucherType;

    private double balanced;

    public WsCirculationAccount() {
    }

    public WsCirculationAccount(
           int voucherNo,
           String accountCode,
           java.util.Calendar voucherDate,
           String detailDescription,
           double debtor,
           double creditor,
           int voucherType,
           double balanced) {
           this.voucherNo = voucherNo;
           this.accountCode = accountCode;
           this.voucherDate = voucherDate;
           this.detailDescription = detailDescription;
           this.debtor = debtor;
           this.creditor = creditor;
           this.voucherType = voucherType;
           this.balanced = balanced;
    }


    /**
     * Gets the voucherNo value for this WsCirculationAccount.
     * 
     * @return voucherNo
     */
    public int getVoucherNo() {
        return voucherNo;
    }


    /**
     * Sets the voucherNo value for this WsCirculationAccount.
     * 
     * @param voucherNo
     */
    public void setVoucherNo(int voucherNo) {
        this.voucherNo = voucherNo;
    }


    /**
     * Gets the accountCode value for this WsCirculationAccount.
     * 
     * @return accountCode
     */
    public String getAccountCode() {
        return accountCode;
    }


    /**
     * Sets the accountCode value for this WsCirculationAccount.
     * 
     * @param accountCode
     */
    public void setAccountCode(String accountCode) {
        this.accountCode = accountCode;
    }


    /**
     * Gets the voucherDate value for this WsCirculationAccount.
     * 
     * @return voucherDate
     */
    public java.util.Calendar getVoucherDate() {
        return voucherDate;
    }


    /**
     * Sets the voucherDate value for this WsCirculationAccount.
     * 
     * @param voucherDate
     */
    public void setVoucherDate(java.util.Calendar voucherDate) {
        this.voucherDate = voucherDate;
    }


    /**
     * Gets the detailDescription value for this WsCirculationAccount.
     * 
     * @return detailDescription
     */
    public String getDetailDescription() {
        return detailDescription;
    }


    /**
     * Sets the detailDescription value for this WsCirculationAccount.
     * 
     * @param detailDescription
     */
    public void setDetailDescription(String detailDescription) {
        this.detailDescription = detailDescription;
    }


    /**
     * Gets the debtor value for this WsCirculationAccount.
     * 
     * @return debtor
     */
    public double getDebtor() {
        return debtor;
    }


    /**
     * Sets the debtor value for this WsCirculationAccount.
     * 
     * @param debtor
     */
    public void setDebtor(double debtor) {
        this.debtor = debtor;
    }


    /**
     * Gets the creditor value for this WsCirculationAccount.
     * 
     * @return creditor
     */
    public double getCreditor() {
        return creditor;
    }


    /**
     * Sets the creditor value for this WsCirculationAccount.
     * 
     * @param creditor
     */
    public void setCreditor(double creditor) {
        this.creditor = creditor;
    }


    /**
     * Gets the voucherType value for this WsCirculationAccount.
     * 
     * @return voucherType
     */
    public int getVoucherType() {
        return voucherType;
    }


    /**
     * Sets the voucherType value for this WsCirculationAccount.
     * 
     * @param voucherType
     */
    public void setVoucherType(int voucherType) {
        this.voucherType = voucherType;
    }


    /**
     * Gets the balanced value for this WsCirculationAccount.
     * 
     * @return balanced
     */
    public double getBalanced() {
        return balanced;
    }


    /**
     * Sets the balanced value for this WsCirculationAccount.
     * 
     * @param balanced
     */
    public void setBalanced(double balanced) {
        this.balanced = balanced;
    }

    private Object __equalsCalc = null;
    public synchronized boolean equals(Object obj) {
        if (!(obj instanceof WsCirculationAccount)) return false;
        WsCirculationAccount other = (WsCirculationAccount) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.voucherNo == other.getVoucherNo() &&
            ((this.accountCode==null && other.getAccountCode()==null) || 
             (this.accountCode!=null &&
              this.accountCode.equals(other.getAccountCode()))) &&
            ((this.voucherDate==null && other.getVoucherDate()==null) || 
             (this.voucherDate!=null &&
              this.voucherDate.equals(other.getVoucherDate()))) &&
            ((this.detailDescription==null && other.getDetailDescription()==null) || 
             (this.detailDescription!=null &&
              this.detailDescription.equals(other.getDetailDescription()))) &&
            this.debtor == other.getDebtor() &&
            this.creditor == other.getCreditor() &&
            this.voucherType == other.getVoucherType() &&
            this.balanced == other.getBalanced();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getVoucherNo();
        if (getAccountCode() != null) {
            _hashCode += getAccountCode().hashCode();
        }
        if (getVoucherDate() != null) {
            _hashCode += getVoucherDate().hashCode();
        }
        if (getDetailDescription() != null) {
            _hashCode += getDetailDescription().hashCode();
        }
        _hashCode += new Double(getDebtor()).hashCode();
        _hashCode += new Double(getCreditor()).hashCode();
        _hashCode += getVoucherType();
        _hashCode += new Double(getBalanced()).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WsCirculationAccount.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "WsCirculationAccount"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voucherNo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "VoucherNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "AccountCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voucherDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "VoucherDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("detailDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "DetailDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("debtor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "Debtor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "Creditor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("voucherType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "VoucherType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("balanced");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "Balanced"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           String mechType,
           Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           String mechType,
           Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
