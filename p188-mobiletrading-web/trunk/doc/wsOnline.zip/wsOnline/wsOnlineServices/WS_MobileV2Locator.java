/**
 * WS_MobileV2Locator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnline.wsOnlineServices;

public class WS_MobileV2Locator extends org.apache.axis.client.Service implements com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2 {

    public WS_MobileV2Locator() {
    }


    public WS_MobileV2Locator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public WS_MobileV2Locator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for WS_MobileV2Soap12
    private static java.lang.String WS_MobileV2Soap12_address = "http://www.mofidonline.com/webservice/ws_mobilev2.asmx";
    // Use to get a proxy class for WS_MobileV2Soap
    public static java.lang.String WS_MobileV2Soap_address    = "http://www.mofidonline.com/webservice/ws_mobilev2.asmx";


    public java.lang.String getWS_MobileV2Soap12Address() {
        return WS_MobileV2Soap12_address;
    }

    // The WSDD webservice name defaults to the port name.
    private java.lang.String WS_MobileV2Soap12WSDDServiceName = "WS_MobileV2Soap12";

    public java.lang.String getWS_MobileV2Soap12WSDDServiceName() {
        return WS_MobileV2Soap12WSDDServiceName;
    }

    public void setWS_MobileV2Soap12WSDDServiceName(java.lang.String name) {
        WS_MobileV2Soap12WSDDServiceName = name;
    }

    public com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_PortType getWS_MobileV2Soap12() throws javax.xml.rpc.ServiceException {
        java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(WS_MobileV2Soap12_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getWS_MobileV2Soap12(endpoint);
    }

    public com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_PortType getWS_MobileV2Soap12(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap12Stub _stub = new com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap12Stub(portAddress, this);
            _stub.setPortName(getWS_MobileV2Soap12WSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setWS_MobileV2Soap12EndpointAddress(java.lang.String address) {
        WS_MobileV2Soap12_address = address;
    }



    public java.lang.String getWS_MobileV2SoapAddress() {
        return WS_MobileV2Soap_address;
    }

    // The WSDD webservice name defaults to the port name.
    private java.lang.String WS_MobileV2SoapWSDDServiceName = "WS_MobileV2Soap";

    public java.lang.String getWS_MobileV2SoapWSDDServiceName() {
        return WS_MobileV2SoapWSDDServiceName;
    }

    public void setWS_MobileV2SoapWSDDServiceName(java.lang.String name) {
        WS_MobileV2SoapWSDDServiceName = name;
    }

    public com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_PortType getWS_MobileV2Soap() throws javax.xml.rpc.ServiceException {
        java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(WS_MobileV2Soap_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getWS_MobileV2Soap(endpoint);
    }

    public com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_PortType getWS_MobileV2Soap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_BindingStub _stub = new com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_BindingStub(portAddress, this);
            _stub.setPortName(getWS_MobileV2SoapWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setWS_MobileV2SoapEndpointAddress(java.lang.String address) {
        WS_MobileV2Soap_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     * This service has multiple ports for a given interface;
     * the proxy implementation returned may be indeterminate.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap12Stub _stub = new com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap12Stub(new java.net.URL(WS_MobileV2Soap12_address), this);
                _stub.setPortName(getWS_MobileV2Soap12WSDDServiceName());
                return _stub;
            }
            if (com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_BindingStub _stub = new com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WS_MobileV2Soap_BindingStub(new java.net.URL(WS_MobileV2Soap_address), this);
                _stub.setPortName(getWS_MobileV2SoapWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("WS_MobileV2Soap12".equals(inputPortName)) {
            return getWS_MobileV2Soap12();
        }
        else if ("WS_MobileV2Soap".equals(inputPortName)) {
            return getWS_MobileV2Soap();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://tempuri.org/", "WS_MobileV2");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://tempuri.org/", "WS_MobileV2Soap12"));
            ports.add(new javax.xml.namespace.QName("http://tempuri.org/", "WS_MobileV2Soap"));
        }
        return ports.iterator();
    }

    /**
     * Set the endpoint address for the specified port name.
     */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {

        if ("WS_MobileV2Soap12".equals(portName)) {
            setWS_MobileV2Soap12EndpointAddress(address);
        }
        else
        if ("WS_MobileV2Soap".equals(portName)) {
            setWS_MobileV2SoapEndpointAddress(address);
        }
        else
        { // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
     * Set the endpoint address for the specified port name.
     */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
