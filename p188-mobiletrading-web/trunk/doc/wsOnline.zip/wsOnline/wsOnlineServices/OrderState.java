/**
 * OrderState.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnline.wsOnlineServices;

public class OrderState implements java.io.Serializable {
    private String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected OrderState(String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final String _None = "None";
    public static final String _Modify = "Modify";
    public static final String _Error = "Error";
    public static final String _Cancel = "Cancel";
    public static final String _Delete = "Delete";
    public static final String _Done = "Done";
    public static final String _OnBoard = "OnBoard";
    public static final String _OnSending = "OnSending";
    public static final String _PartiallyExcution = "PartiallyExcution";
    public static final String _OnCanceling = "OnCanceling";
    public static final String _OnCancelError = "OnCancelError";
    public static final String _OnModifyError = "OnModifyError";
    public static final String _DeleteByBroker = "DeleteByBroker";
    public static final String _Expired = "Expired";
    public static final String _PartiallyExcutionAndExpired = "PartiallyExcutionAndExpired";
    public static final String _CancelByBrokerForUnBlock = "CancelByBrokerForUnBlock";
    public static final String _OnModify = "OnModify";
    public static final String _DeleteByNSC = "DeleteByNSC";
    public static final String _CancelByBrokerForOrderOnAir = "CancelByBrokerForOrderOnAir";
    public static final OrderState None = new OrderState(_None);
    public static final OrderState Modify = new OrderState(_Modify);
    public static final OrderState Error = new OrderState(_Error);
    public static final OrderState Cancel = new OrderState(_Cancel);
    public static final OrderState Delete = new OrderState(_Delete);
    public static final OrderState Done = new OrderState(_Done);
    public static final OrderState OnBoard = new OrderState(_OnBoard);
    public static final OrderState OnSending = new OrderState(_OnSending);
    public static final OrderState PartiallyExcution = new OrderState(_PartiallyExcution);
    public static final OrderState OnCanceling = new OrderState(_OnCanceling);
    public static final OrderState OnCancelError = new OrderState(_OnCancelError);
    public static final OrderState OnModifyError = new OrderState(_OnModifyError);
    public static final OrderState DeleteByBroker = new OrderState(_DeleteByBroker);
    public static final OrderState Expired = new OrderState(_Expired);
    public static final OrderState PartiallyExcutionAndExpired = new OrderState(_PartiallyExcutionAndExpired);
    public static final OrderState CancelByBrokerForUnBlock = new OrderState(_CancelByBrokerForUnBlock);
    public static final OrderState OnModify = new OrderState(_OnModify);
    public static final OrderState DeleteByNSC = new OrderState(_DeleteByNSC);
    public static final OrderState CancelByBrokerForOrderOnAir = new OrderState(_CancelByBrokerForOrderOnAir);
    public String getValue() { return _value_;}
    public static OrderState fromValue(String value)
          throws IllegalArgumentException {
        OrderState enumeration = (OrderState)
            _table_.get(value);
        if (enumeration==null) throw new IllegalArgumentException();
        return enumeration;
    }
    public static OrderState fromString(String value)
          throws IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public String toString() { return _value_;}
    public Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           String mechType,
           Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           String mechType,
           Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderState.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "OrderState"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
