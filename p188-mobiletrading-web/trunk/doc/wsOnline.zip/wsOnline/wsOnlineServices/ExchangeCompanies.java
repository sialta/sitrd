/**
 * ExchangeCompanies.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnline.wsOnlineServices;

public class ExchangeCompanies  implements java.io.Serializable {
    private ExchangeBoards exchangeBoard;
    private String managerFullName;
    private java.math.BigDecimal currentAsset;
    private String exchangeCode;
    private int stockCompanyAddressId;
    private String stockHolderDepartmentManagerFullName;
    private int stockHolderDepartmentAddressId;
    private int subSectorId;
    private int sectorId;
    private int baseVolume;
    private String title;
    private String enTitle;
    private boolean isActive;
    private String ISIN;
    private String webSite;
    private String currentActivity;
    private int EPS;
    private int id;

    public ExchangeCompanies() {
    }

    public ExchangeCompanies(
            com.sefryek.broker.webservices.wsOnline.wsOnlineServices.ExchangeBoards exchangeBoard,
            String managerFullName,
            java.math.BigDecimal currentAsset,
            String exchangeCode,
            int stockCompanyAddressId,
            String stockHolderDepartmentManagerFullName,
            int stockHolderDepartmentAddressId,
            int subSectorId,
            int sectorId,
            int baseVolume,
            String title,
            String enTitle,
            boolean isActive,
            String ISIN,
            String webSite,
            String currentActivity,
            int EPS,
            int id) {
        this.exchangeBoard = exchangeBoard;
        this.managerFullName = managerFullName;
        this.currentAsset = currentAsset;
        this.exchangeCode = exchangeCode;
        this.stockCompanyAddressId = stockCompanyAddressId;
        this.stockHolderDepartmentManagerFullName = stockHolderDepartmentManagerFullName;
        this.stockHolderDepartmentAddressId = stockHolderDepartmentAddressId;
        this.subSectorId = subSectorId;
        this.sectorId = sectorId;
        this.baseVolume = baseVolume;
        this.title = title;
        this.enTitle = enTitle;
        this.isActive = isActive;
        this.ISIN = ISIN;
        this.webSite = webSite;
        this.currentActivity = currentActivity;
        this.EPS = EPS;
        this.id = id;
    }


    /**
     * Gets the exchangeBoard value for this ExchangeCompanies.
     *
     * @return exchangeBoard
     */
    public ExchangeBoards getExchangeBoard() {
        return exchangeBoard;
    }


    /**
     * Sets the exchangeBoard value for this ExchangeCompanies.
     *
     * @param exchangeBoard
     */
    public void setExchangeBoard(com.sefryek.broker.webservices.wsOnline.wsOnlineServices.ExchangeBoards exchangeBoard) {
        this.exchangeBoard = exchangeBoard;
    }


    /**
     * Gets the managerFullName value for this ExchangeCompanies.
     *
     * @return managerFullName
     */
    public String getManagerFullName() {
        return managerFullName;
    }


    /**
     * Sets the managerFullName value for this ExchangeCompanies.
     *
     * @param managerFullName
     */
    public void setManagerFullName(String managerFullName) {
        this.managerFullName = managerFullName;
    }


    /**
     * Gets the currentAsset value for this ExchangeCompanies.
     *
     * @return currentAsset
     */
    public java.math.BigDecimal getCurrentAsset() {
        return currentAsset;
    }


    /**
     * Sets the currentAsset value for this ExchangeCompanies.
     *
     * @param currentAsset
     */
    public void setCurrentAsset(java.math.BigDecimal currentAsset) {
        this.currentAsset = currentAsset;
    }


    /**
     * Gets the exchangeCode value for this ExchangeCompanies.
     *
     * @return exchangeCode
     */
    public String getExchangeCode() {
        return exchangeCode;
    }


    /**
     * Sets the exchangeCode value for this ExchangeCompanies.
     *
     * @param exchangeCode
     */
    public void setExchangeCode(String exchangeCode) {
        this.exchangeCode = exchangeCode;
    }


    /**
     * Gets the stockCompanyAddressId value for this ExchangeCompanies.
     *
     * @return stockCompanyAddressId
     */
    public int getStockCompanyAddressId() {
        return stockCompanyAddressId;
    }


    /**
     * Sets the stockCompanyAddressId value for this ExchangeCompanies.
     *
     * @param stockCompanyAddressId
     */
    public void setStockCompanyAddressId(int stockCompanyAddressId) {
        this.stockCompanyAddressId = stockCompanyAddressId;
    }


    /**
     * Gets the stockHolderDepartmentManagerFullName value for this ExchangeCompanies.
     *
     * @return stockHolderDepartmentManagerFullName
     */
    public String getStockHolderDepartmentManagerFullName() {
        return stockHolderDepartmentManagerFullName;
    }


    /**
     * Sets the stockHolderDepartmentManagerFullName value for this ExchangeCompanies.
     *
     * @param stockHolderDepartmentManagerFullName
     */
    public void setStockHolderDepartmentManagerFullName(String stockHolderDepartmentManagerFullName) {
        this.stockHolderDepartmentManagerFullName = stockHolderDepartmentManagerFullName;
    }


    /**
     * Gets the stockHolderDepartmentAddressId value for this ExchangeCompanies.
     *
     * @return stockHolderDepartmentAddressId
     */
    public int getStockHolderDepartmentAddressId() {
        return stockHolderDepartmentAddressId;
    }


    /**
     * Sets the stockHolderDepartmentAddressId value for this ExchangeCompanies.
     *
     * @param stockHolderDepartmentAddressId
     */
    public void setStockHolderDepartmentAddressId(int stockHolderDepartmentAddressId) {
        this.stockHolderDepartmentAddressId = stockHolderDepartmentAddressId;
    }


    /**
     * Gets the subSectorId value for this ExchangeCompanies.
     *
     * @return subSectorId
     */
    public int getSubSectorId() {
        return subSectorId;
    }


    /**
     * Sets the subSectorId value for this ExchangeCompanies.
     *
     * @param subSectorId
     */
    public void setSubSectorId(int subSectorId) {
        this.subSectorId = subSectorId;
    }


    /**
     * Gets the sectorId value for this ExchangeCompanies.
     *
     * @return sectorId
     */
    public int getSectorId() {
        return sectorId;
    }


    /**
     * Sets the sectorId value for this ExchangeCompanies.
     *
     * @param sectorId
     */
    public void setSectorId(int sectorId) {
        this.sectorId = sectorId;
    }


    /**
     * Gets the baseVolume value for this ExchangeCompanies.
     *
     * @return baseVolume
     */
    public int getBaseVolume() {
        return baseVolume;
    }


    /**
     * Sets the baseVolume value for this ExchangeCompanies.
     *
     * @param baseVolume
     */
    public void setBaseVolume(int baseVolume) {
        this.baseVolume = baseVolume;
    }


    /**
     * Gets the title value for this ExchangeCompanies.
     *
     * @return title
     */
    public String getTitle() {
        return title;
    }


    /**
     * Sets the title value for this ExchangeCompanies.
     *
     * @param title
     */
    public void setTitle(String title) {
        this.title = title;
    }


    /**
     * Gets the enTitle value for this ExchangeCompanies.
     *
     * @return enTitle
     */
    public String getEnTitle() {
        return enTitle;
    }


    /**
     * Sets the enTitle value for this ExchangeCompanies.
     *
     * @param enTitle
     */
    public void setEnTitle(String enTitle) {
        this.enTitle = enTitle;
    }


    /**
     * Gets the isActive value for this ExchangeCompanies.
     *
     * @return isActive
     */
    public boolean isIsActive() {
        return isActive;
    }


    /**
     * Sets the isActive value for this ExchangeCompanies.
     *
     * @param isActive
     */
    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }


    /**
     * Gets the ISIN value for this ExchangeCompanies.
     *
     * @return ISIN
     */
    public String getISIN() {
        return ISIN;
    }


    /**
     * Sets the ISIN value for this ExchangeCompanies.
     *
     * @param ISIN
     */
    public void setISIN(String ISIN) {
        this.ISIN = ISIN;
    }


    /**
     * Gets the webSite value for this ExchangeCompanies.
     *
     * @return webSite
     */
    public String getWebSite() {
        return webSite;
    }


    /**
     * Sets the webSite value for this ExchangeCompanies.
     *
     * @param webSite
     */
    public void setWebSite(String webSite) {
        this.webSite = webSite;
    }


    /**
     * Gets the currentActivity value for this ExchangeCompanies.
     *
     * @return currentActivity
     */
    public String getCurrentActivity() {
        return currentActivity;
    }


    /**
     * Sets the currentActivity value for this ExchangeCompanies.
     *
     * @param currentActivity
     */
    public void setCurrentActivity(String currentActivity) {
        this.currentActivity = currentActivity;
    }


    /**
     * Gets the EPS value for this ExchangeCompanies.
     *
     * @return EPS
     */
    public int getEPS() {
        return EPS;
    }


    /**
     * Sets the EPS value for this ExchangeCompanies.
     *
     * @param EPS
     */
    public void setEPS(int EPS) {
        this.EPS = EPS;
    }


    /**
     * Gets the id value for this ExchangeCompanies.
     *
     * @return id
     */
    public int getId() {
        return id;
    }


    /**
     * Sets the id value for this ExchangeCompanies.
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }
    private Object __equalsCalc = null;
    public synchronized boolean equals(Object obj) {
        if (!(obj instanceof ExchangeCompanies)) return false;
        ExchangeCompanies other = (ExchangeCompanies) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
                ((this.exchangeBoard==null && other.getExchangeBoard()==null) ||
                        (this.exchangeBoard!=null &&
                                this.exchangeBoard.equals(other.getExchangeBoard()))) &&
                ((this.managerFullName==null && other.getManagerFullName()==null) ||
                        (this.managerFullName!=null &&
                                this.managerFullName.equals(other.getManagerFullName()))) &&
                ((this.currentAsset==null && other.getCurrentAsset()==null) ||
                        (this.currentAsset!=null &&
                                this.currentAsset.equals(other.getCurrentAsset()))) &&
                ((this.exchangeCode==null && other.getExchangeCode()==null) ||
                        (this.exchangeCode!=null &&
                                this.exchangeCode.equals(other.getExchangeCode()))) &&
                this.stockCompanyAddressId == other.getStockCompanyAddressId() &&
                ((this.stockHolderDepartmentManagerFullName==null && other.getStockHolderDepartmentManagerFullName()==null) ||
                        (this.stockHolderDepartmentManagerFullName!=null &&
                                this.stockHolderDepartmentManagerFullName.equals(other.getStockHolderDepartmentManagerFullName()))) &&
                this.stockHolderDepartmentAddressId == other.getStockHolderDepartmentAddressId() &&
                this.subSectorId == other.getSubSectorId() &&
                this.sectorId == other.getSectorId() &&
                this.baseVolume == other.getBaseVolume() &&
                ((this.title==null && other.getTitle()==null) ||
                        (this.title!=null &&
                                this.title.equals(other.getTitle()))) &&
                ((this.enTitle==null && other.getEnTitle()==null) ||
                        (this.enTitle!=null &&
                                this.enTitle.equals(other.getEnTitle()))) &&
                this.isActive == other.isIsActive() &&
                ((this.ISIN==null && other.getISIN()==null) ||
                        (this.ISIN!=null &&
                                this.ISIN.equals(other.getISIN()))) &&
                ((this.webSite==null && other.getWebSite()==null) ||
                        (this.webSite!=null &&
                                this.webSite.equals(other.getWebSite()))) &&
                ((this.currentActivity==null && other.getCurrentActivity()==null) ||
                        (this.currentActivity!=null &&
                                this.currentActivity.equals(other.getCurrentActivity()))) &&
                this.EPS == other.getEPS() &&
                this.id == other.getId();
        __equalsCalc = null;
        return _equals;
    }
    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getExchangeBoard() != null) {
            _hashCode += getExchangeBoard().hashCode();
        }
        if (getManagerFullName() != null) {
            _hashCode += getManagerFullName().hashCode();
        }
        if (getCurrentAsset() != null) {
            _hashCode += getCurrentAsset().hashCode();
        }
        if (getExchangeCode() != null) {
            _hashCode += getExchangeCode().hashCode();
        }
        _hashCode += getStockCompanyAddressId();
        if (getStockHolderDepartmentManagerFullName() != null) {
            _hashCode += getStockHolderDepartmentManagerFullName().hashCode();
        }
        _hashCode += getStockHolderDepartmentAddressId();
        _hashCode += getSubSectorId();
        _hashCode += getSectorId();
        _hashCode += getBaseVolume();
        if (getTitle() != null) {
            _hashCode += getTitle().hashCode();
        }
        if (getEnTitle() != null) {
            _hashCode += getEnTitle().hashCode();
        }
        _hashCode += (isIsActive() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getISIN() != null) {
            _hashCode += getISIN().hashCode();
        }
        if (getWebSite() != null) {
            _hashCode += getWebSite().hashCode();
        }
        if (getCurrentActivity() != null) {
            _hashCode += getCurrentActivity().hashCode();
        }
        _hashCode += getEPS();
        _hashCode += getId();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadataprivate
    static org.apache.axis.description.TypeDesc typeDesc =
            new org.apache.axis.description.TypeDesc(ExchangeCompanies.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "ExchangeCompanies"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exchangeBoard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ExchangeBoard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "ExchangeBoards"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("managerFullName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ManagerFullName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currentAsset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CurrentAsset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exchangeCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ExchangeCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stockCompanyAddressId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "StockCompanyAddressId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stockHolderDepartmentManagerFullName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "StockHolderDepartmentManagerFullName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stockHolderDepartmentAddressId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "StockHolderDepartmentAddressId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subSectorId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SubSectorId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sectorId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SectorId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("baseVolume");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BaseVolume"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("title");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "Title"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enTitle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "EnTitle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isActive");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "IsActive"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ISIN");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ISIN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webSite");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "WebSite"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currentActivity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CurrentActivity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EPS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "EPS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "Id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
            String mechType,
            Class _javaType,
            javax.xml.namespace.QName _xmlType) {
        return
                new  org.apache.axis.encoding.ser.BeanSerializer(
                        _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
            String mechType,
            Class _javaType,
            javax.xml.namespace.QName _xmlType) {
        return
                new  org.apache.axis.encoding.ser.BeanDeserializer(
                        _javaType, _xmlType, typeDesc);
    }

}
