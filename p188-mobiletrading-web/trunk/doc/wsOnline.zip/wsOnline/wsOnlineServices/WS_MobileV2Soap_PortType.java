/**
 * WS_MobileV2Soap_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnline.wsOnlineServices;

public interface WS_MobileV2Soap_PortType extends java.rmi.Remote {
    public Object[] login(Login parameters) throws java.rmi.RemoteException;
    public AddOrderResponse addOrder(AddOrder parameters, Object cookies) throws java.rmi.RemoteException;
    public GetSettingResponse getSetting(GetSetting parameters) throws java.rmi.RemoteException;
    public CancelOrderResponse cancelOrder(CancelOrder parameters, Object cookie) throws java.rmi.RemoteException;
    public GetOrderListResponse getOrderList(GetOrderList parameters) throws java.rmi.RemoteException;
    public GetCirculationAccountListResponse getCirculationAccountList(GetCirculationAccountList parameters) throws java.rmi.RemoteException;
    public GetOrderBookResponse getOrderBook(GetOrderBook parameters) throws java.rmi.RemoteException;
}
