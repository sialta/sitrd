/**
 * WsOrderMessage.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnline.wsOnlineServices;

public class WsOrderMessage  implements java.io.Serializable {
    private int customerId;

    private ExchangeSymbols exchangeSymbols;

    private int excutedAmount;

    private int hidenOrder;

    private Long id;

    private Integer maximumQuantity;

    private int maxShown;

    private Integer minimumQuantity;

    private java.util.Calendar orderEntryDate;

    private java.math.BigDecimal orderPrice;

    private WsOrderSide orderSide;

    private OrderState orderState;

    private int orderTotalQuantity;

    private WsOrderType orderType;

    private int orderValidity;

    private java.util.Calendar orderValidityDate;

    private Integer brokerId;

    private String isinCode;

    private java.math.BigDecimal triggerPrice;

    public WsOrderMessage() {
    }

    public WsOrderMessage(
           int customerId,
           com.sefryek.broker.webservices.wsOnline.wsOnlineServices.ExchangeSymbols exchangeSymbols,
           int excutedAmount,
           int hidenOrder,
           Long id,
           Integer maximumQuantity,
           int maxShown,
           Integer minimumQuantity,
           java.util.Calendar orderEntryDate,
           java.math.BigDecimal orderPrice,
           com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WsOrderSide orderSide,
           com.sefryek.broker.webservices.wsOnline.wsOnlineServices.OrderState orderState,
           int orderTotalQuantity,
           com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WsOrderType orderType,
           int orderValidity,
           java.util.Calendar orderValidityDate,
           Integer brokerId,
           String isinCode,
           java.math.BigDecimal triggerPrice) {
           this.customerId = customerId;
           this.exchangeSymbols = exchangeSymbols;
           this.excutedAmount = excutedAmount;
           this.hidenOrder = hidenOrder;
           this.id = id;
           this.maximumQuantity = maximumQuantity;
           this.maxShown = maxShown;
           this.minimumQuantity = minimumQuantity;
           this.orderEntryDate = orderEntryDate;
           this.orderPrice = orderPrice;
           this.orderSide = orderSide;
           this.orderState = orderState;
           this.orderTotalQuantity = orderTotalQuantity;
           this.orderType = orderType;
           this.orderValidity = orderValidity;
           this.orderValidityDate = orderValidityDate;
           this.brokerId = brokerId;
           this.isinCode = isinCode;
           this.triggerPrice = triggerPrice;
    }


    /**
     * Gets the customerId value for this WsOrderMessage.
     * 
     * @return customerId
     */
    public int getCustomerId() {
        return customerId;
    }


    /**
     * Sets the customerId value for this WsOrderMessage.
     * 
     * @param customerId
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }


    /**
     * Gets the exchangeSymbols value for this WsOrderMessage.
     * 
     * @return exchangeSymbols
     */
    public ExchangeSymbols getExchangeSymbols() {
        return exchangeSymbols;
    }


    /**
     * Sets the exchangeSymbols value for this WsOrderMessage.
     * 
     * @param exchangeSymbols
     */
    public void setExchangeSymbols(com.sefryek.broker.webservices.wsOnline.wsOnlineServices.ExchangeSymbols exchangeSymbols) {
        this.exchangeSymbols = exchangeSymbols;
    }


    /**
     * Gets the excutedAmount value for this WsOrderMessage.
     * 
     * @return excutedAmount
     */
    public int getExcutedAmount() {
        return excutedAmount;
    }


    /**
     * Sets the excutedAmount value for this WsOrderMessage.
     * 
     * @param excutedAmount
     */
    public void setExcutedAmount(int excutedAmount) {
        this.excutedAmount = excutedAmount;
    }


    /**
     * Gets the hidenOrder value for this WsOrderMessage.
     * 
     * @return hidenOrder
     */
    public int getHidenOrder() {
        return hidenOrder;
    }


    /**
     * Sets the hidenOrder value for this WsOrderMessage.
     * 
     * @param hidenOrder
     */
    public void setHidenOrder(int hidenOrder) {
        this.hidenOrder = hidenOrder;
    }


    /**
     * Gets the id value for this WsOrderMessage.
     * 
     * @return id
     */
    public Long getId() {
        return id;
    }


    /**
     * Sets the id value for this WsOrderMessage.
     * 
     * @param id
     */
    public void setId(Long id) {
        this.id = id;
    }


    /**
     * Gets the maximumQuantity value for this WsOrderMessage.
     * 
     * @return maximumQuantity
     */
    public Integer getMaximumQuantity() {
        return maximumQuantity;
    }


    /**
     * Sets the maximumQuantity value for this WsOrderMessage.
     * 
     * @param maximumQuantity
     */
    public void setMaximumQuantity(Integer maximumQuantity) {
        this.maximumQuantity = maximumQuantity;
    }


    /**
     * Gets the maxShown value for this WsOrderMessage.
     * 
     * @return maxShown
     */
    public int getMaxShown() {
        return maxShown;
    }


    /**
     * Sets the maxShown value for this WsOrderMessage.
     * 
     * @param maxShown
     */
    public void setMaxShown(int maxShown) {
        this.maxShown = maxShown;
    }


    /**
     * Gets the minimumQuantity value for this WsOrderMessage.
     * 
     * @return minimumQuantity
     */
    public Integer getMinimumQuantity() {
        return minimumQuantity;
    }


    /**
     * Sets the minimumQuantity value for this WsOrderMessage.
     * 
     * @param minimumQuantity
     */
    public void setMinimumQuantity(Integer minimumQuantity) {
        this.minimumQuantity = minimumQuantity;
    }


    /**
     * Gets the orderEntryDate value for this WsOrderMessage.
     * 
     * @return orderEntryDate
     */
    public java.util.Calendar getOrderEntryDate() {
        return orderEntryDate;
    }


    /**
     * Sets the orderEntryDate value for this WsOrderMessage.
     * 
     * @param orderEntryDate
     */
    public void setOrderEntryDate(java.util.Calendar orderEntryDate) {
        this.orderEntryDate = orderEntryDate;
    }


    /**
     * Gets the orderPrice value for this WsOrderMessage.
     * 
     * @return orderPrice
     */
    public java.math.BigDecimal getOrderPrice() {
        return orderPrice;
    }


    /**
     * Sets the orderPrice value for this WsOrderMessage.
     * 
     * @param orderPrice
     */
    public void setOrderPrice(java.math.BigDecimal orderPrice) {
        this.orderPrice = orderPrice;
    }


    /**
     * Gets the orderSide value for this WsOrderMessage.
     * 
     * @return orderSide
     */
    public WsOrderSide getOrderSide() {
        return orderSide;
    }


    /**
     * Sets the orderSide value for this WsOrderMessage.
     * 
     * @param orderSide
     */
    public void setOrderSide(com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WsOrderSide orderSide) {
        this.orderSide = orderSide;
    }


    /**
     * Gets the orderState value for this WsOrderMessage.
     * 
     * @return orderState
     */
    public OrderState getOrderState() {
        return orderState;
    }


    /**
     * Sets the orderState value for this WsOrderMessage.
     * 
     * @param orderState
     */
    public void setOrderState(com.sefryek.broker.webservices.wsOnline.wsOnlineServices.OrderState orderState) {
        this.orderState = orderState;
    }


    /**
     * Gets the orderTotalQuantity value for this WsOrderMessage.
     * 
     * @return orderTotalQuantity
     */
    public int getOrderTotalQuantity() {
        return orderTotalQuantity;
    }


    /**
     * Sets the orderTotalQuantity value for this WsOrderMessage.
     * 
     * @param orderTotalQuantity
     */
    public void setOrderTotalQuantity(int orderTotalQuantity) {
        this.orderTotalQuantity = orderTotalQuantity;
    }


    /**
     * Gets the orderType value for this WsOrderMessage.
     * 
     * @return orderType
     */
    public WsOrderType getOrderType() {
        return orderType;
    }


    /**
     * Sets the orderType value for this WsOrderMessage.
     * 
     * @param orderType
     */
    public void setOrderType(com.sefryek.broker.webservices.wsOnline.wsOnlineServices.WsOrderType orderType) {
        this.orderType = orderType;
    }


    /**
     * Gets the orderValidity value for this WsOrderMessage.
     * 
     * @return orderValidity
     */
    public int getOrderValidity() {
        return orderValidity;
    }


    /**
     * Sets the orderValidity value for this WsOrderMessage.
     * 
     * @param orderValidity
     */
    public void setOrderValidity(int orderValidity) {
        this.orderValidity = orderValidity;
    }


    /**
     * Gets the orderValidityDate value for this WsOrderMessage.
     * 
     * @return orderValidityDate
     */
    public java.util.Calendar getOrderValidityDate() {
        return orderValidityDate;
    }


    /**
     * Sets the orderValidityDate value for this WsOrderMessage.
     * 
     * @param orderValidityDate
     */
    public void setOrderValidityDate(java.util.Calendar orderValidityDate) {
        this.orderValidityDate = orderValidityDate;
    }


    /**
     * Gets the brokerId value for this WsOrderMessage.
     * 
     * @return brokerId
     */
    public Integer getBrokerId() {
        return brokerId;
    }


    /**
     * Sets the brokerId value for this WsOrderMessage.
     * 
     * @param brokerId
     */
    public void setBrokerId(Integer brokerId) {
        this.brokerId = brokerId;
    }


    /**
     * Gets the isinCode value for this WsOrderMessage.
     * 
     * @return isinCode
     */
    public String getIsinCode() {
        return isinCode;
    }


    /**
     * Sets the isinCode value for this WsOrderMessage.
     * 
     * @param isinCode
     */
    public void setIsinCode(String isinCode) {
        this.isinCode = isinCode;
    }


    /**
     * Gets the triggerPrice value for this WsOrderMessage.
     * 
     * @return triggerPrice
     */
    public java.math.BigDecimal getTriggerPrice() {
        return triggerPrice;
    }


    /**
     * Sets the triggerPrice value for this WsOrderMessage.
     * 
     * @param triggerPrice
     */
    public void setTriggerPrice(java.math.BigDecimal triggerPrice) {
        this.triggerPrice = triggerPrice;
    }

    private Object __equalsCalc = null;
    public synchronized boolean equals(Object obj) {
        if (!(obj instanceof WsOrderMessage)) return false;
        WsOrderMessage other = (WsOrderMessage) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.customerId == other.getCustomerId() &&
            ((this.exchangeSymbols==null && other.getExchangeSymbols()==null) || 
             (this.exchangeSymbols!=null &&
              this.exchangeSymbols.equals(other.getExchangeSymbols()))) &&
            this.excutedAmount == other.getExcutedAmount() &&
            this.hidenOrder == other.getHidenOrder() &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.maximumQuantity==null && other.getMaximumQuantity()==null) || 
             (this.maximumQuantity!=null &&
              this.maximumQuantity.equals(other.getMaximumQuantity()))) &&
            this.maxShown == other.getMaxShown() &&
            ((this.minimumQuantity==null && other.getMinimumQuantity()==null) || 
             (this.minimumQuantity!=null &&
              this.minimumQuantity.equals(other.getMinimumQuantity()))) &&
            ((this.orderEntryDate==null && other.getOrderEntryDate()==null) || 
             (this.orderEntryDate!=null &&
              this.orderEntryDate.equals(other.getOrderEntryDate()))) &&
            ((this.orderPrice==null && other.getOrderPrice()==null) || 
             (this.orderPrice!=null &&
              this.orderPrice.equals(other.getOrderPrice()))) &&
            ((this.orderSide==null && other.getOrderSide()==null) || 
             (this.orderSide!=null &&
              this.orderSide.equals(other.getOrderSide()))) &&
            ((this.orderState==null && other.getOrderState()==null) || 
             (this.orderState!=null &&
              this.orderState.equals(other.getOrderState()))) &&
            this.orderTotalQuantity == other.getOrderTotalQuantity() &&
            ((this.orderType==null && other.getOrderType()==null) || 
             (this.orderType!=null &&
              this.orderType.equals(other.getOrderType()))) &&
            this.orderValidity == other.getOrderValidity() &&
            ((this.orderValidityDate==null && other.getOrderValidityDate()==null) || 
             (this.orderValidityDate!=null &&
              this.orderValidityDate.equals(other.getOrderValidityDate()))) &&
            ((this.brokerId==null && other.getBrokerId()==null) || 
             (this.brokerId!=null &&
              this.brokerId.equals(other.getBrokerId()))) &&
            ((this.isinCode==null && other.getIsinCode()==null) || 
             (this.isinCode!=null &&
              this.isinCode.equals(other.getIsinCode()))) &&
            ((this.triggerPrice==null && other.getTriggerPrice()==null) || 
             (this.triggerPrice!=null &&
              this.triggerPrice.equals(other.getTriggerPrice())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getCustomerId();
        if (getExchangeSymbols() != null) {
            _hashCode += getExchangeSymbols().hashCode();
        }
        _hashCode += getExcutedAmount();
        _hashCode += getHidenOrder();
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getMaximumQuantity() != null) {
            _hashCode += getMaximumQuantity().hashCode();
        }
        _hashCode += getMaxShown();
        if (getMinimumQuantity() != null) {
            _hashCode += getMinimumQuantity().hashCode();
        }
        if (getOrderEntryDate() != null) {
            _hashCode += getOrderEntryDate().hashCode();
        }
        if (getOrderPrice() != null) {
            _hashCode += getOrderPrice().hashCode();
        }
        if (getOrderSide() != null) {
            _hashCode += getOrderSide().hashCode();
        }
        if (getOrderState() != null) {
            _hashCode += getOrderState().hashCode();
        }
        _hashCode += getOrderTotalQuantity();
        if (getOrderType() != null) {
            _hashCode += getOrderType().hashCode();
        }
        _hashCode += getOrderValidity();
        if (getOrderValidityDate() != null) {
            _hashCode += getOrderValidityDate().hashCode();
        }
        if (getBrokerId() != null) {
            _hashCode += getBrokerId().hashCode();
        }
        if (getIsinCode() != null) {
            _hashCode += getIsinCode().hashCode();
        }
        if (getTriggerPrice() != null) {
            _hashCode += getTriggerPrice().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WsOrderMessage.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "WsOrderMessage"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CustomerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exchangeSymbols");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ExchangeSymbols"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "ExchangeSymbols"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("excutedAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ExcutedAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hidenOrder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "HidenOrder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "Id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maximumQuantity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MaximumQuantity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxShown");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MaxShown"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minimumQuantity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MinimumQuantity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderEntryDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OrderEntryDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OrderPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderSide");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OrderSide"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "WsOrderSide"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderState");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OrderState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "OrderState"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderTotalQuantity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OrderTotalQuantity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OrderType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "WsOrderType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderValidity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OrderValidity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderValidityDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OrderValidityDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brokerId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BrokerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isinCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "IsinCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("triggerPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "TriggerPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           String mechType,
           Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           String mechType,
           Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
