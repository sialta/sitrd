/**
 * OMSSetting.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.sefryek.broker.webservices.wsOnline.wsOnlineServices;

public class OMSSetting  implements java.io.Serializable {
    private java.lang.String automationUsernamePrefix;

      private java.lang.String automationAccountingPrefix;

      private java.lang.String RLCServerAddrerss;

      private java.lang.String cancelStartTime;

      private java.lang.String cancelEndTime;

      private java.lang.String forbiddenOrderStartTime;

      private java.lang.String forbiddenOrderEndTime;

      private int forbiddenOrderValidity;

      private int diffBestPercent;

      private java.lang.String startTimeLastTradedPriceDiff;

      private java.lang.String endTimeLastTradedPriceDiff;

      private java.lang.String siteThemes;

      private long volumeThresholdForDiff;

      private long valueThresholdForBuy;

      private long lastTradePriceDiffPercent;

      private boolean checkRuleForBranchSupervisor;

      private java.lang.String accountingDatabasePassword;

      private java.lang.String accountingDatabaseServer;

      private java.lang.String accountingDatabaseUserId;

      private java.lang.String accountingFinancialYear;

      private java.lang.String accountingGroupNo;

      private int accountingUserId;

      private boolean activeBuyRequestForCustomerWithoutBalance;

      private boolean activeRightForBuy;

      private boolean activeRightForSell;

      private java.lang.String bankCode;

      private java.lang.String bourseKarmozdAccountForBuy;

      private java.lang.String bourseKarmozdAccountForSell;

      private java.lang.String branchCode;

      private java.lang.String brokerId;

      private java.lang.String brokerName;

      private java.lang.String brokerWebSite;

      private java.lang.String brokerWebSiteDB;

      private boolean buyOrderEditCount;

      private boolean buyOrderEditMinQty;

      private boolean buyOrderEditPrice;

      private boolean buyOrderEditShownVolume;

      private boolean buyOrderEditValidity;

      private java.lang.String callBackUrl;

      private boolean canBuy;

      private boolean canBuySell;

      private boolean canSell;

      private java.lang.String CDSPassword;

      private java.lang.String CDSUserName;

      private java.lang.String countryCode;

      private java.lang.String customerAccount;

      private boolean defaultConfirmBranchVoucher;

      private boolean enableSmtpSSL;

      private java.lang.String fanavariAccountForBuy;

      private java.lang.String fanavariAccountForSell;

      private int stockTableLimitForCustomer;

      private int stockTableLimitForBranch;

      private boolean isReady;

      private double karmozdForBuy;

      private double karmozdForSell;

      private java.lang.String khadamatsherkatbourceAccount2ForBuy;

      private java.lang.String khadamatsherkatbourceAccount2ForSell;

      private java.lang.String khadamatsherkatbourceAccountForBuy;

      private java.lang.String khadamatsherkatbourceAccountForSell;

      private long maxRequestPerSecond;

      private java.lang.String maleyatAccount;

      private java.lang.String marketCloseTime;

      private java.lang.String marketOpenTime;

      private long maximumDateRangeForBuy;

      private long maximumDateRangeForSell;

      private long maximumOrderCountForBuy;

      private long maximumOrderCountForSell;

      private long maximumOrderValueForBuy;

      private long maximumOrderValueForSell;

      private java.lang.String mellatAccountCode;

      private java.lang.String mellatPublicKey;

      private int minimumOrderCountForBuy;

      private int minimumOrderCountForSell;

      private int minimumOrderValueForBuy;

      private int minimumOrderValueForSell;

      private java.lang.String moamelatBrokerKarmozdAccountForBuy;

      private java.lang.String moamelatBrokerKarmozdAccountForSell;

      private java.lang.String nezaratbourseKarmozdAccountForBuy;

      private java.lang.String nezaratbourseKarmozdAccountForSell;

      private java.lang.String noReplayEmail;

      private java.lang.String OMSDatabaseName;

      private java.lang.String OMSDatabasePassword;

      private java.lang.String OMSDatabaseServer;

      private java.lang.String OMSDatabaseUserId;

      private java.lang.String payapayAccount;

      private java.lang.String payapayAccountForBuy;

      private java.lang.String payapayAccountForSell;

      private java.lang.String trustChainPath;

      private boolean sellOrderEditCount;

      private boolean sellOrderEditMinQty;

      private boolean sellOrderEditPrice;

      private boolean sellOrderEditShownVolume;

      private boolean sellOrderEditValidity;

      private java.lang.String sepordehGozariAccountForBuy;

      private java.lang.String sepordehGozariAccountForSell;

      private int serviceMailApplicationId;

      private java.lang.String serviceMailPassword;

      private java.lang.String serviceMailUserName;

      private java.lang.String smtpServer;

      private java.lang.String smtpServerPassword;

      private java.lang.String smtpServerPort;

      private java.lang.String smtpServerUserName;

      private boolean smtpServerUsingNtlm;

      private java.lang.String tafavotAccount;

      private java.lang.String themeName;

      private double thresholdVariant;

      private java.lang.String townCode;

      private java.lang.String traderId;

      private java.lang.String version;

      private java.lang.String webSocketAddress;

      private int maxAssetPrint;

      private java.lang.String accessToPageSystemActivity;

      private int porofilerAppId;

      private java.lang.String networkPerformenceURL;

      private java.lang.String googleAnalytics;

      private java.lang.String userBrowserVersion;

      private int changePasswordCycle;

      private int lockUserCycle;

      private java.lang.String userBrowserFlashPlayerVersion;

      private int userReportJobStartTime;

      private java.lang.String retrievingDataMethods;

      private boolean showFill_And_Kill;

      private int externalResourceTimeOut;

      private boolean sendSMS;

      public OMSSetting() {
      }

      public OMSSetting(
             java.lang.String automationUsernamePrefix,
             java.lang.String automationAccountingPrefix,
             java.lang.String RLCServerAddrerss,
             java.lang.String cancelStartTime,
             java.lang.String cancelEndTime,
             java.lang.String forbiddenOrderStartTime,
             java.lang.String forbiddenOrderEndTime,
             int forbiddenOrderValidity,
             int diffBestPercent,
             java.lang.String startTimeLastTradedPriceDiff,
             java.lang.String endTimeLastTradedPriceDiff,
             java.lang.String siteThemes,
             long volumeThresholdForDiff,
             long valueThresholdForBuy,
             long lastTradePriceDiffPercent,
             boolean checkRuleForBranchSupervisor,
             java.lang.String accountingDatabasePassword,
             java.lang.String accountingDatabaseServer,
             java.lang.String accountingDatabaseUserId,
             java.lang.String accountingFinancialYear,
             java.lang.String accountingGroupNo,
             int accountingUserId,
             boolean activeBuyRequestForCustomerWithoutBalance,
             boolean activeRightForBuy,
             boolean activeRightForSell,
             java.lang.String bankCode,
             java.lang.String bourseKarmozdAccountForBuy,
             java.lang.String bourseKarmozdAccountForSell,
             java.lang.String branchCode,
             java.lang.String brokerId,
             java.lang.String brokerName,
             java.lang.String brokerWebSite,
             java.lang.String brokerWebSiteDB,
             boolean buyOrderEditCount,
             boolean buyOrderEditMinQty,
             boolean buyOrderEditPrice,
             boolean buyOrderEditShownVolume,
             boolean buyOrderEditValidity,
             java.lang.String callBackUrl,
             boolean canBuy,
             boolean canBuySell,
             boolean canSell,
             java.lang.String CDSPassword,
             java.lang.String CDSUserName,
             java.lang.String countryCode,
             java.lang.String customerAccount,
             boolean defaultConfirmBranchVoucher,
             boolean enableSmtpSSL,
             java.lang.String fanavariAccountForBuy,
             java.lang.String fanavariAccountForSell,
             int stockTableLimitForCustomer,
             int stockTableLimitForBranch,
             boolean isReady,
             double karmozdForBuy,
             double karmozdForSell,
             java.lang.String khadamatsherkatbourceAccount2ForBuy,
             java.lang.String khadamatsherkatbourceAccount2ForSell,
             java.lang.String khadamatsherkatbourceAccountForBuy,
             java.lang.String khadamatsherkatbourceAccountForSell,
             long maxRequestPerSecond,
             java.lang.String maleyatAccount,
             java.lang.String marketCloseTime,
             java.lang.String marketOpenTime,
             long maximumDateRangeForBuy,
             long maximumDateRangeForSell,
             long maximumOrderCountForBuy,
             long maximumOrderCountForSell,
             long maximumOrderValueForBuy,
             long maximumOrderValueForSell,
             java.lang.String mellatAccountCode,
             java.lang.String mellatPublicKey,
             int minimumOrderCountForBuy,
             int minimumOrderCountForSell,
             int minimumOrderValueForBuy,
             int minimumOrderValueForSell,
             java.lang.String moamelatBrokerKarmozdAccountForBuy,
             java.lang.String moamelatBrokerKarmozdAccountForSell,
             java.lang.String nezaratbourseKarmozdAccountForBuy,
             java.lang.String nezaratbourseKarmozdAccountForSell,
             java.lang.String noReplayEmail,
             java.lang.String OMSDatabaseName,
             java.lang.String OMSDatabasePassword,
             java.lang.String OMSDatabaseServer,
             java.lang.String OMSDatabaseUserId,
             java.lang.String payapayAccount,
             java.lang.String payapayAccountForBuy,
             java.lang.String payapayAccountForSell,
             java.lang.String trustChainPath,
             boolean sellOrderEditCount,
             boolean sellOrderEditMinQty,
             boolean sellOrderEditPrice,
             boolean sellOrderEditShownVolume,
             boolean sellOrderEditValidity,
             java.lang.String sepordehGozariAccountForBuy,
             java.lang.String sepordehGozariAccountForSell,
             int serviceMailApplicationId,
             java.lang.String serviceMailPassword,
             java.lang.String serviceMailUserName,
             java.lang.String smtpServer,
             java.lang.String smtpServerPassword,
             java.lang.String smtpServerPort,
             java.lang.String smtpServerUserName,
             boolean smtpServerUsingNtlm,
             java.lang.String tafavotAccount,
             java.lang.String themeName,
             double thresholdVariant,
             java.lang.String townCode,
             java.lang.String traderId,
             java.lang.String version,
             java.lang.String webSocketAddress,
             int maxAssetPrint,
             java.lang.String accessToPageSystemActivity,
             int porofilerAppId,
             java.lang.String networkPerformenceURL,
             java.lang.String googleAnalytics,
             java.lang.String userBrowserVersion,
             int changePasswordCycle,
             int lockUserCycle,
             java.lang.String userBrowserFlashPlayerVersion,
             int userReportJobStartTime,
             java.lang.String retrievingDataMethods,
             boolean showFill_And_Kill,
             int externalResourceTimeOut,
             boolean sendSMS) {
             this.automationUsernamePrefix = automationUsernamePrefix;
             this.automationAccountingPrefix = automationAccountingPrefix;
             this.RLCServerAddrerss = RLCServerAddrerss;
             this.cancelStartTime = cancelStartTime;
             this.cancelEndTime = cancelEndTime;
             this.forbiddenOrderStartTime = forbiddenOrderStartTime;
             this.forbiddenOrderEndTime = forbiddenOrderEndTime;
             this.forbiddenOrderValidity = forbiddenOrderValidity;
             this.diffBestPercent = diffBestPercent;
             this.startTimeLastTradedPriceDiff = startTimeLastTradedPriceDiff;
             this.endTimeLastTradedPriceDiff = endTimeLastTradedPriceDiff;
             this.siteThemes = siteThemes;
             this.volumeThresholdForDiff = volumeThresholdForDiff;
             this.valueThresholdForBuy = valueThresholdForBuy;
             this.lastTradePriceDiffPercent = lastTradePriceDiffPercent;
             this.checkRuleForBranchSupervisor = checkRuleForBranchSupervisor;
             this.accountingDatabasePassword = accountingDatabasePassword;
             this.accountingDatabaseServer = accountingDatabaseServer;
             this.accountingDatabaseUserId = accountingDatabaseUserId;
             this.accountingFinancialYear = accountingFinancialYear;
             this.accountingGroupNo = accountingGroupNo;
             this.accountingUserId = accountingUserId;
             this.activeBuyRequestForCustomerWithoutBalance = activeBuyRequestForCustomerWithoutBalance;
             this.activeRightForBuy = activeRightForBuy;
             this.activeRightForSell = activeRightForSell;
             this.bankCode = bankCode;
             this.bourseKarmozdAccountForBuy = bourseKarmozdAccountForBuy;
             this.bourseKarmozdAccountForSell = bourseKarmozdAccountForSell;
             this.branchCode = branchCode;
             this.brokerId = brokerId;
             this.brokerName = brokerName;
             this.brokerWebSite = brokerWebSite;
             this.brokerWebSiteDB = brokerWebSiteDB;
             this.buyOrderEditCount = buyOrderEditCount;
             this.buyOrderEditMinQty = buyOrderEditMinQty;
             this.buyOrderEditPrice = buyOrderEditPrice;
             this.buyOrderEditShownVolume = buyOrderEditShownVolume;
             this.buyOrderEditValidity = buyOrderEditValidity;
             this.callBackUrl = callBackUrl;
             this.canBuy = canBuy;
             this.canBuySell = canBuySell;
             this.canSell = canSell;
             this.CDSPassword = CDSPassword;
             this.CDSUserName = CDSUserName;
             this.countryCode = countryCode;
             this.customerAccount = customerAccount;
             this.defaultConfirmBranchVoucher = defaultConfirmBranchVoucher;
             this.enableSmtpSSL = enableSmtpSSL;
             this.fanavariAccountForBuy = fanavariAccountForBuy;
             this.fanavariAccountForSell = fanavariAccountForSell;
             this.stockTableLimitForCustomer = stockTableLimitForCustomer;
             this.stockTableLimitForBranch = stockTableLimitForBranch;
             this.isReady = isReady;
             this.karmozdForBuy = karmozdForBuy;
             this.karmozdForSell = karmozdForSell;
             this.khadamatsherkatbourceAccount2ForBuy = khadamatsherkatbourceAccount2ForBuy;
             this.khadamatsherkatbourceAccount2ForSell = khadamatsherkatbourceAccount2ForSell;
             this.khadamatsherkatbourceAccountForBuy = khadamatsherkatbourceAccountForBuy;
             this.khadamatsherkatbourceAccountForSell = khadamatsherkatbourceAccountForSell;
             this.maxRequestPerSecond = maxRequestPerSecond;
             this.maleyatAccount = maleyatAccount;
             this.marketCloseTime = marketCloseTime;
             this.marketOpenTime = marketOpenTime;
             this.maximumDateRangeForBuy = maximumDateRangeForBuy;
             this.maximumDateRangeForSell = maximumDateRangeForSell;
             this.maximumOrderCountForBuy = maximumOrderCountForBuy;
             this.maximumOrderCountForSell = maximumOrderCountForSell;
             this.maximumOrderValueForBuy = maximumOrderValueForBuy;
             this.maximumOrderValueForSell = maximumOrderValueForSell;
             this.mellatAccountCode = mellatAccountCode;
             this.mellatPublicKey = mellatPublicKey;
             this.minimumOrderCountForBuy = minimumOrderCountForBuy;
             this.minimumOrderCountForSell = minimumOrderCountForSell;
             this.minimumOrderValueForBuy = minimumOrderValueForBuy;
             this.minimumOrderValueForSell = minimumOrderValueForSell;
             this.moamelatBrokerKarmozdAccountForBuy = moamelatBrokerKarmozdAccountForBuy;
             this.moamelatBrokerKarmozdAccountForSell = moamelatBrokerKarmozdAccountForSell;
             this.nezaratbourseKarmozdAccountForBuy = nezaratbourseKarmozdAccountForBuy;
             this.nezaratbourseKarmozdAccountForSell = nezaratbourseKarmozdAccountForSell;
             this.noReplayEmail = noReplayEmail;
             this.OMSDatabaseName = OMSDatabaseName;
             this.OMSDatabasePassword = OMSDatabasePassword;
             this.OMSDatabaseServer = OMSDatabaseServer;
             this.OMSDatabaseUserId = OMSDatabaseUserId;
             this.payapayAccount = payapayAccount;
             this.payapayAccountForBuy = payapayAccountForBuy;
             this.payapayAccountForSell = payapayAccountForSell;
             this.trustChainPath = trustChainPath;
             this.sellOrderEditCount = sellOrderEditCount;
             this.sellOrderEditMinQty = sellOrderEditMinQty;
             this.sellOrderEditPrice = sellOrderEditPrice;
             this.sellOrderEditShownVolume = sellOrderEditShownVolume;
             this.sellOrderEditValidity = sellOrderEditValidity;
             this.sepordehGozariAccountForBuy = sepordehGozariAccountForBuy;
             this.sepordehGozariAccountForSell = sepordehGozariAccountForSell;
             this.serviceMailApplicationId = serviceMailApplicationId;
             this.serviceMailPassword = serviceMailPassword;
             this.serviceMailUserName = serviceMailUserName;
             this.smtpServer = smtpServer;
             this.smtpServerPassword = smtpServerPassword;
             this.smtpServerPort = smtpServerPort;
             this.smtpServerUserName = smtpServerUserName;
             this.smtpServerUsingNtlm = smtpServerUsingNtlm;
             this.tafavotAccount = tafavotAccount;
             this.themeName = themeName;
             this.thresholdVariant = thresholdVariant;
             this.townCode = townCode;
             this.traderId = traderId;
             this.version = version;
             this.webSocketAddress = webSocketAddress;
             this.maxAssetPrint = maxAssetPrint;
             this.accessToPageSystemActivity = accessToPageSystemActivity;
             this.porofilerAppId = porofilerAppId;
             this.networkPerformenceURL = networkPerformenceURL;
             this.googleAnalytics = googleAnalytics;
             this.userBrowserVersion = userBrowserVersion;
             this.changePasswordCycle = changePasswordCycle;
             this.lockUserCycle = lockUserCycle;
             this.userBrowserFlashPlayerVersion = userBrowserFlashPlayerVersion;
             this.userReportJobStartTime = userReportJobStartTime;
             this.retrievingDataMethods = retrievingDataMethods;
             this.showFill_And_Kill = showFill_And_Kill;
             this.externalResourceTimeOut = externalResourceTimeOut;
             this.sendSMS = sendSMS;
      }


      /**
       * Gets the automationUsernamePrefix value for this OMSSetting.
       *
       * @return automationUsernamePrefix
       */
      public java.lang.String getAutomationUsernamePrefix() {
          return automationUsernamePrefix;
      }


      /**
       * Sets the automationUsernamePrefix value for this OMSSetting.
       *
       * @param automationUsernamePrefix
       */
      public void setAutomationUsernamePrefix(java.lang.String automationUsernamePrefix) {
          this.automationUsernamePrefix = automationUsernamePrefix;
      }


      /**
       * Gets the automationAccountingPrefix value for this OMSSetting.
       *
       * @return automationAccountingPrefix
       */
      public java.lang.String getAutomationAccountingPrefix() {
          return automationAccountingPrefix;
      }


      /**
       * Sets the automationAccountingPrefix value for this OMSSetting.
       *
       * @param automationAccountingPrefix
       */
      public void setAutomationAccountingPrefix(java.lang.String automationAccountingPrefix) {
          this.automationAccountingPrefix = automationAccountingPrefix;
      }


      /**
       * Gets the RLCServerAddrerss value for this OMSSetting.
       *
       * @return RLCServerAddrerss
       */
      public java.lang.String getRLCServerAddrerss() {
          return RLCServerAddrerss;
      }


      /**
       * Sets the RLCServerAddrerss value for this OMSSetting.
       *
       * @param RLCServerAddrerss
       */
      public void setRLCServerAddrerss(java.lang.String RLCServerAddrerss) {
          this.RLCServerAddrerss = RLCServerAddrerss;
      }


      /**
       * Gets the cancelStartTime value for this OMSSetting.
       *
       * @return cancelStartTime
       */
      public java.lang.String getCancelStartTime() {
          return cancelStartTime;
      }


      /**
       * Sets the cancelStartTime value for this OMSSetting.
       *
       * @param cancelStartTime
       */
      public void setCancelStartTime(java.lang.String cancelStartTime) {
          this.cancelStartTime = cancelStartTime;
      }


      /**
       * Gets the cancelEndTime value for this OMSSetting.
       *
       * @return cancelEndTime
       */
      public java.lang.String getCancelEndTime() {
          return cancelEndTime;
      }


      /**
       * Sets the cancelEndTime value for this OMSSetting.
       *
       * @param cancelEndTime
       */
      public void setCancelEndTime(java.lang.String cancelEndTime) {
          this.cancelEndTime = cancelEndTime;
      }


      /**
       * Gets the forbiddenOrderStartTime value for this OMSSetting.
       *
       * @return forbiddenOrderStartTime
       */
      public java.lang.String getForbiddenOrderStartTime() {
          return forbiddenOrderStartTime;
      }


      /**
       * Sets the forbiddenOrderStartTime value for this OMSSetting.
       *
       * @param forbiddenOrderStartTime
       */
      public void setForbiddenOrderStartTime(java.lang.String forbiddenOrderStartTime) {
          this.forbiddenOrderStartTime = forbiddenOrderStartTime;
      }


      /**
       * Gets the forbiddenOrderEndTime value for this OMSSetting.
       *
       * @return forbiddenOrderEndTime
       */
      public java.lang.String getForbiddenOrderEndTime() {
          return forbiddenOrderEndTime;
      }


      /**
       * Sets the forbiddenOrderEndTime value for this OMSSetting.
       *
       * @param forbiddenOrderEndTime
       */
      public void setForbiddenOrderEndTime(java.lang.String forbiddenOrderEndTime) {
          this.forbiddenOrderEndTime = forbiddenOrderEndTime;
      }


      /**
       * Gets the forbiddenOrderValidity value for this OMSSetting.
       *
       * @return forbiddenOrderValidity
       */
      public int getForbiddenOrderValidity() {
          return forbiddenOrderValidity;
      }


      /**
       * Sets the forbiddenOrderValidity value for this OMSSetting.
       *
       * @param forbiddenOrderValidity
       */
      public void setForbiddenOrderValidity(int forbiddenOrderValidity) {
          this.forbiddenOrderValidity = forbiddenOrderValidity;
      }


      /**
       * Gets the diffBestPercent value for this OMSSetting.
       *
       * @return diffBestPercent
       */
      public int getDiffBestPercent() {
          return diffBestPercent;
      }


      /**
       * Sets the diffBestPercent value for this OMSSetting.
       *
       * @param diffBestPercent
       */
      public void setDiffBestPercent(int diffBestPercent) {
          this.diffBestPercent = diffBestPercent;
      }


      /**
       * Gets the startTimeLastTradedPriceDiff value for this OMSSetting.
       *
       * @return startTimeLastTradedPriceDiff
       */
      public java.lang.String getStartTimeLastTradedPriceDiff() {
          return startTimeLastTradedPriceDiff;
      }


      /**
       * Sets the startTimeLastTradedPriceDiff value for this OMSSetting.
       *
       * @param startTimeLastTradedPriceDiff
       */
      public void setStartTimeLastTradedPriceDiff(java.lang.String startTimeLastTradedPriceDiff) {
          this.startTimeLastTradedPriceDiff = startTimeLastTradedPriceDiff;
      }


      /**
       * Gets the endTimeLastTradedPriceDiff value for this OMSSetting.
       *
       * @return endTimeLastTradedPriceDiff
       */
      public java.lang.String getEndTimeLastTradedPriceDiff() {
          return endTimeLastTradedPriceDiff;
      }


      /**
       * Sets the endTimeLastTradedPriceDiff value for this OMSSetting.
       *
       * @param endTimeLastTradedPriceDiff
       */
      public void setEndTimeLastTradedPriceDiff(java.lang.String endTimeLastTradedPriceDiff) {
          this.endTimeLastTradedPriceDiff = endTimeLastTradedPriceDiff;
      }


      /**
       * Gets the siteThemes value for this OMSSetting.
       *
       * @return siteThemes
       */
      public java.lang.String getSiteThemes() {
          return siteThemes;
      }


      /**
       * Sets the siteThemes value for this OMSSetting.
       *
       * @param siteThemes
       */
      public void setSiteThemes(java.lang.String siteThemes) {
          this.siteThemes = siteThemes;
      }


      /**
       * Gets the volumeThresholdForDiff value for this OMSSetting.
       *
       * @return volumeThresholdForDiff
       */
      public long getVolumeThresholdForDiff() {
          return volumeThresholdForDiff;
      }


      /**
       * Sets the volumeThresholdForDiff value for this OMSSetting.
       *
       * @param volumeThresholdForDiff
       */
      public void setVolumeThresholdForDiff(long volumeThresholdForDiff) {
          this.volumeThresholdForDiff = volumeThresholdForDiff;
      }


      /**
       * Gets the valueThresholdForBuy value for this OMSSetting.
       *
       * @return valueThresholdForBuy
       */
      public long getValueThresholdForBuy() {
          return valueThresholdForBuy;
      }


      /**
       * Sets the valueThresholdForBuy value for this OMSSetting.
       *
       * @param valueThresholdForBuy
       */
      public void setValueThresholdForBuy(long valueThresholdForBuy) {
          this.valueThresholdForBuy = valueThresholdForBuy;
      }


      /**
       * Gets the lastTradePriceDiffPercent value for this OMSSetting.
       *
       * @return lastTradePriceDiffPercent
       */
      public long getLastTradePriceDiffPercent() {
          return lastTradePriceDiffPercent;
      }


      /**
       * Sets the lastTradePriceDiffPercent value for this OMSSetting.
       *
       * @param lastTradePriceDiffPercent
       */
      public void setLastTradePriceDiffPercent(long lastTradePriceDiffPercent) {
          this.lastTradePriceDiffPercent = lastTradePriceDiffPercent;
      }


      /**
       * Gets the checkRuleForBranchSupervisor value for this OMSSetting.
       *
       * @return checkRuleForBranchSupervisor
       */
      public boolean isCheckRuleForBranchSupervisor() {
          return checkRuleForBranchSupervisor;
      }


      /**
       * Sets the checkRuleForBranchSupervisor value for this OMSSetting.
       *
       * @param checkRuleForBranchSupervisor
       */
      public void setCheckRuleForBranchSupervisor(boolean checkRuleForBranchSupervisor) {
          this.checkRuleForBranchSupervisor = checkRuleForBranchSupervisor;
      }


      /**
       * Gets the accountingDatabasePassword value for this OMSSetting.
       *
       * @return accountingDatabasePassword
       */
      public java.lang.String getAccountingDatabasePassword() {
          return accountingDatabasePassword;
      }


      /**
       * Sets the accountingDatabasePassword value for this OMSSetting.
       *
       * @param accountingDatabasePassword
       */
      public void setAccountingDatabasePassword(java.lang.String accountingDatabasePassword) {
          this.accountingDatabasePassword = accountingDatabasePassword;
      }


      /**
       * Gets the accountingDatabaseServer value for this OMSSetting.
       *
       * @return accountingDatabaseServer
       */
      public java.lang.String getAccountingDatabaseServer() {
          return accountingDatabaseServer;
      }


      /**
       * Sets the accountingDatabaseServer value for this OMSSetting.
       *
       * @param accountingDatabaseServer
       */
      public void setAccountingDatabaseServer(java.lang.String accountingDatabaseServer) {
          this.accountingDatabaseServer = accountingDatabaseServer;
      }


      /**
       * Gets the accountingDatabaseUserId value for this OMSSetting.
       *
       * @return accountingDatabaseUserId
       */
      public java.lang.String getAccountingDatabaseUserId() {
          return accountingDatabaseUserId;
      }


      /**
       * Sets the accountingDatabaseUserId value for this OMSSetting.
       *
       * @param accountingDatabaseUserId
       */
      public void setAccountingDatabaseUserId(java.lang.String accountingDatabaseUserId) {
          this.accountingDatabaseUserId = accountingDatabaseUserId;
      }


      /**
       * Gets the accountingFinancialYear value for this OMSSetting.
       *
       * @return accountingFinancialYear
       */
      public java.lang.String getAccountingFinancialYear() {
          return accountingFinancialYear;
      }


      /**
       * Sets the accountingFinancialYear value for this OMSSetting.
       *
       * @param accountingFinancialYear
       */
      public void setAccountingFinancialYear(java.lang.String accountingFinancialYear) {
          this.accountingFinancialYear = accountingFinancialYear;
      }


      /**
       * Gets the accountingGroupNo value for this OMSSetting.
       *
       * @return accountingGroupNo
       */
      public java.lang.String getAccountingGroupNo() {
          return accountingGroupNo;
      }


      /**
       * Sets the accountingGroupNo value for this OMSSetting.
       *
       * @param accountingGroupNo
       */
      public void setAccountingGroupNo(java.lang.String accountingGroupNo) {
          this.accountingGroupNo = accountingGroupNo;
      }


      /**
       * Gets the accountingUserId value for this OMSSetting.
       *
       * @return accountingUserId
       */
      public int getAccountingUserId() {
          return accountingUserId;
      }


      /**
       * Sets the accountingUserId value for this OMSSetting.
       *
       * @param accountingUserId
       */
      public void setAccountingUserId(int accountingUserId) {
          this.accountingUserId = accountingUserId;
      }


      /**
       * Gets the activeBuyRequestForCustomerWithoutBalance value for this OMSSetting.
       *
       * @return activeBuyRequestForCustomerWithoutBalance
       */
      public boolean isActiveBuyRequestForCustomerWithoutBalance() {
          return activeBuyRequestForCustomerWithoutBalance;
      }


      /**
       * Sets the activeBuyRequestForCustomerWithoutBalance value for this OMSSetting.
       *
       * @param activeBuyRequestForCustomerWithoutBalance
       */
      public void setActiveBuyRequestForCustomerWithoutBalance(boolean activeBuyRequestForCustomerWithoutBalance) {
          this.activeBuyRequestForCustomerWithoutBalance = activeBuyRequestForCustomerWithoutBalance;
      }


      /**
       * Gets the activeRightForBuy value for this OMSSetting.
       *
       * @return activeRightForBuy
       */
      public boolean isActiveRightForBuy() {
          return activeRightForBuy;
      }


      /**
       * Sets the activeRightForBuy value for this OMSSetting.
       *
       * @param activeRightForBuy
       */
      public void setActiveRightForBuy(boolean activeRightForBuy) {
          this.activeRightForBuy = activeRightForBuy;
      }


      /**
       * Gets the activeRightForSell value for this OMSSetting.
       *
       * @return activeRightForSell
       */
      public boolean isActiveRightForSell() {
          return activeRightForSell;
      }


      /**
       * Sets the activeRightForSell value for this OMSSetting.
       *
       * @param activeRightForSell
       */
      public void setActiveRightForSell(boolean activeRightForSell) {
          this.activeRightForSell = activeRightForSell;
      }


      /**
       * Gets the bankCode value for this OMSSetting.
       *
       * @return bankCode
       */
      public java.lang.String getBankCode() {
          return bankCode;
      }


      /**
       * Sets the bankCode value for this OMSSetting.
       *
       * @param bankCode
       */
      public void setBankCode(java.lang.String bankCode) {
          this.bankCode = bankCode;
      }


      /**
       * Gets the bourseKarmozdAccountForBuy value for this OMSSetting.
       *
       * @return bourseKarmozdAccountForBuy
       */
      public java.lang.String getBourseKarmozdAccountForBuy() {
          return bourseKarmozdAccountForBuy;
      }


      /**
       * Sets the bourseKarmozdAccountForBuy value for this OMSSetting.
       *
       * @param bourseKarmozdAccountForBuy
       */
      public void setBourseKarmozdAccountForBuy(java.lang.String bourseKarmozdAccountForBuy) {
          this.bourseKarmozdAccountForBuy = bourseKarmozdAccountForBuy;
      }


      /**
       * Gets the bourseKarmozdAccountForSell value for this OMSSetting.
       *
       * @return bourseKarmozdAccountForSell
       */
      public java.lang.String getBourseKarmozdAccountForSell() {
          return bourseKarmozdAccountForSell;
      }


      /**
       * Sets the bourseKarmozdAccountForSell value for this OMSSetting.
       *
       * @param bourseKarmozdAccountForSell
       */
      public void setBourseKarmozdAccountForSell(java.lang.String bourseKarmozdAccountForSell) {
          this.bourseKarmozdAccountForSell = bourseKarmozdAccountForSell;
      }


      /**
       * Gets the branchCode value for this OMSSetting.
       *
       * @return branchCode
       */
      public java.lang.String getBranchCode() {
          return branchCode;
      }


      /**
       * Sets the branchCode value for this OMSSetting.
       *
       * @param branchCode
       */
      public void setBranchCode(java.lang.String branchCode) {
          this.branchCode = branchCode;
      }


      /**
       * Gets the brokerId value for this OMSSetting.
       *
       * @return brokerId
       */
      public java.lang.String getBrokerId() {
          return brokerId;
      }


      /**
       * Sets the brokerId value for this OMSSetting.
       *
       * @param brokerId
       */
      public void setBrokerId(java.lang.String brokerId) {
          this.brokerId = brokerId;
      }


      /**
       * Gets the brokerName value for this OMSSetting.
       *
       * @return brokerName
       */
      public java.lang.String getBrokerName() {
          return brokerName;
      }


      /**
       * Sets the brokerName value for this OMSSetting.
       *
       * @param brokerName
       */
      public void setBrokerName(java.lang.String brokerName) {
          this.brokerName = brokerName;
      }


      /**
       * Gets the brokerWebSite value for this OMSSetting.
       *
       * @return brokerWebSite
       */
      public java.lang.String getBrokerWebSite() {
          return brokerWebSite;
      }


      /**
       * Sets the brokerWebSite value for this OMSSetting.
       *
       * @param brokerWebSite
       */
      public void setBrokerWebSite(java.lang.String brokerWebSite) {
          this.brokerWebSite = brokerWebSite;
      }


      /**
       * Gets the brokerWebSiteDB value for this OMSSetting.
       *
       * @return brokerWebSiteDB
       */
      public java.lang.String getBrokerWebSiteDB() {
          return brokerWebSiteDB;
      }


      /**
       * Sets the brokerWebSiteDB value for this OMSSetting.
       *
       * @param brokerWebSiteDB
       */
      public void setBrokerWebSiteDB(java.lang.String brokerWebSiteDB) {
          this.brokerWebSiteDB = brokerWebSiteDB;
      }


      /**
       * Gets the buyOrderEditCount value for this OMSSetting.
       *
       * @return buyOrderEditCount
       */
      public boolean isBuyOrderEditCount() {
          return buyOrderEditCount;
      }


      /**
       * Sets the buyOrderEditCount value for this OMSSetting.
       *
       * @param buyOrderEditCount
       */
      public void setBuyOrderEditCount(boolean buyOrderEditCount) {
          this.buyOrderEditCount = buyOrderEditCount;
      }


      /**
       * Gets the buyOrderEditMinQty value for this OMSSetting.
       *
       * @return buyOrderEditMinQty
       */
      public boolean isBuyOrderEditMinQty() {
          return buyOrderEditMinQty;
      }


      /**
       * Sets the buyOrderEditMinQty value for this OMSSetting.
       *
       * @param buyOrderEditMinQty
       */
      public void setBuyOrderEditMinQty(boolean buyOrderEditMinQty) {
          this.buyOrderEditMinQty = buyOrderEditMinQty;
      }


      /**
       * Gets the buyOrderEditPrice value for this OMSSetting.
       *
       * @return buyOrderEditPrice
       */
      public boolean isBuyOrderEditPrice() {
          return buyOrderEditPrice;
      }


      /**
       * Sets the buyOrderEditPrice value for this OMSSetting.
       *
       * @param buyOrderEditPrice
       */
      public void setBuyOrderEditPrice(boolean buyOrderEditPrice) {
          this.buyOrderEditPrice = buyOrderEditPrice;
      }


      /**
       * Gets the buyOrderEditShownVolume value for this OMSSetting.
       *
       * @return buyOrderEditShownVolume
       */
      public boolean isBuyOrderEditShownVolume() {
          return buyOrderEditShownVolume;
      }


      /**
       * Sets the buyOrderEditShownVolume value for this OMSSetting.
       *
       * @param buyOrderEditShownVolume
       */
      public void setBuyOrderEditShownVolume(boolean buyOrderEditShownVolume) {
          this.buyOrderEditShownVolume = buyOrderEditShownVolume;
      }


      /**
       * Gets the buyOrderEditValidity value for this OMSSetting.
       *
       * @return buyOrderEditValidity
       */
      public boolean isBuyOrderEditValidity() {
          return buyOrderEditValidity;
      }


      /**
       * Sets the buyOrderEditValidity value for this OMSSetting.
       *
       * @param buyOrderEditValidity
       */
      public void setBuyOrderEditValidity(boolean buyOrderEditValidity) {
          this.buyOrderEditValidity = buyOrderEditValidity;
      }


      /**
       * Gets the callBackUrl value for this OMSSetting.
       *
       * @return callBackUrl
       */
      public java.lang.String getCallBackUrl() {
          return callBackUrl;
      }


      /**
       * Sets the callBackUrl value for this OMSSetting.
       *
       * @param callBackUrl
       */
      public void setCallBackUrl(java.lang.String callBackUrl) {
          this.callBackUrl = callBackUrl;
      }


      /**
       * Gets the canBuy value for this OMSSetting.
       *
       * @return canBuy
       */
      public boolean isCanBuy() {
          return canBuy;
      }


      /**
       * Sets the canBuy value for this OMSSetting.
       *
       * @param canBuy
       */
      public void setCanBuy(boolean canBuy) {
          this.canBuy = canBuy;
      }


      /**
       * Gets the canBuySell value for this OMSSetting.
       *
       * @return canBuySell
       */
      public boolean isCanBuySell() {
          return canBuySell;
      }


      /**
       * Sets the canBuySell value for this OMSSetting.
       *
       * @param canBuySell
       */
      public void setCanBuySell(boolean canBuySell) {
          this.canBuySell = canBuySell;
      }


      /**
       * Gets the canSell value for this OMSSetting.
       *
       * @return canSell
       */
      public boolean isCanSell() {
          return canSell;
      }


      /**
       * Sets the canSell value for this OMSSetting.
       *
       * @param canSell
       */
      public void setCanSell(boolean canSell) {
          this.canSell = canSell;
      }


      /**
       * Gets the CDSPassword value for this OMSSetting.
       *
       * @return CDSPassword
       */
      public java.lang.String getCDSPassword() {
          return CDSPassword;
      }


      /**
       * Sets the CDSPassword value for this OMSSetting.
       *
       * @param CDSPassword
       */
      public void setCDSPassword(java.lang.String CDSPassword) {
          this.CDSPassword = CDSPassword;
      }


      /**
       * Gets the CDSUserName value for this OMSSetting.
       *
       * @return CDSUserName
       */
      public java.lang.String getCDSUserName() {
          return CDSUserName;
      }


      /**
       * Sets the CDSUserName value for this OMSSetting.
       *
       * @param CDSUserName
       */
      public void setCDSUserName(java.lang.String CDSUserName) {
          this.CDSUserName = CDSUserName;
      }


      /**
       * Gets the countryCode value for this OMSSetting.
       *
       * @return countryCode
       */
      public java.lang.String getCountryCode() {
          return countryCode;
      }


      /**
       * Sets the countryCode value for this OMSSetting.
       *
       * @param countryCode
       */
      public void setCountryCode(java.lang.String countryCode) {
          this.countryCode = countryCode;
      }


      /**
       * Gets the customerAccount value for this OMSSetting.
       *
       * @return customerAccount
       */
      public java.lang.String getCustomerAccount() {
          return customerAccount;
      }


      /**
       * Sets the customerAccount value for this OMSSetting.
       *
       * @param customerAccount
       */
      public void setCustomerAccount(java.lang.String customerAccount) {
          this.customerAccount = customerAccount;
      }


      /**
       * Gets the defaultConfirmBranchVoucher value for this OMSSetting.
       *
       * @return defaultConfirmBranchVoucher
       */
      public boolean isDefaultConfirmBranchVoucher() {
          return defaultConfirmBranchVoucher;
      }


      /**
       * Sets the defaultConfirmBranchVoucher value for this OMSSetting.
       *
       * @param defaultConfirmBranchVoucher
       */
      public void setDefaultConfirmBranchVoucher(boolean defaultConfirmBranchVoucher) {
          this.defaultConfirmBranchVoucher = defaultConfirmBranchVoucher;
      }


      /**
       * Gets the enableSmtpSSL value for this OMSSetting.
       *
       * @return enableSmtpSSL
       */
      public boolean isEnableSmtpSSL() {
          return enableSmtpSSL;
      }


      /**
       * Sets the enableSmtpSSL value for this OMSSetting.
       *
       * @param enableSmtpSSL
       */
      public void setEnableSmtpSSL(boolean enableSmtpSSL) {
          this.enableSmtpSSL = enableSmtpSSL;
      }


      /**
       * Gets the fanavariAccountForBuy value for this OMSSetting.
       *
       * @return fanavariAccountForBuy
       */
      public java.lang.String getFanavariAccountForBuy() {
          return fanavariAccountForBuy;
      }


      /**
       * Sets the fanavariAccountForBuy value for this OMSSetting.
       *
       * @param fanavariAccountForBuy
       */
      public void setFanavariAccountForBuy(java.lang.String fanavariAccountForBuy) {
          this.fanavariAccountForBuy = fanavariAccountForBuy;
      }


      /**
       * Gets the fanavariAccountForSell value for this OMSSetting.
       *
       * @return fanavariAccountForSell
       */
      public java.lang.String getFanavariAccountForSell() {
          return fanavariAccountForSell;
      }


      /**
       * Sets the fanavariAccountForSell value for this OMSSetting.
       *
       * @param fanavariAccountForSell
       */
      public void setFanavariAccountForSell(java.lang.String fanavariAccountForSell) {
          this.fanavariAccountForSell = fanavariAccountForSell;
      }


      /**
       * Gets the stockTableLimitForCustomer value for this OMSSetting.
       *
       * @return stockTableLimitForCustomer
       */
      public int getStockTableLimitForCustomer() {
          return stockTableLimitForCustomer;
      }


      /**
       * Sets the stockTableLimitForCustomer value for this OMSSetting.
       *
       * @param stockTableLimitForCustomer
       */
      public void setStockTableLimitForCustomer(int stockTableLimitForCustomer) {
          this.stockTableLimitForCustomer = stockTableLimitForCustomer;
      }


      /**
       * Gets the stockTableLimitForBranch value for this OMSSetting.
       *
       * @return stockTableLimitForBranch
       */
      public int getStockTableLimitForBranch() {
          return stockTableLimitForBranch;
      }


      /**
       * Sets the stockTableLimitForBranch value for this OMSSetting.
       *
       * @param stockTableLimitForBranch
       */
      public void setStockTableLimitForBranch(int stockTableLimitForBranch) {
          this.stockTableLimitForBranch = stockTableLimitForBranch;
      }


      /**
       * Gets the isReady value for this OMSSetting.
       *
       * @return isReady
       */
      public boolean isIsReady() {
          return isReady;
      }


      /**
       * Sets the isReady value for this OMSSetting.
       *
       * @param isReady
       */
      public void setIsReady(boolean isReady) {
          this.isReady = isReady;
      }


      /**
       * Gets the karmozdForBuy value for this OMSSetting.
       *
       * @return karmozdForBuy
       */
      public double getKarmozdForBuy() {
          return karmozdForBuy;
      }


      /**
       * Sets the karmozdForBuy value for this OMSSetting.
       *
       * @param karmozdForBuy
       */
      public void setKarmozdForBuy(double karmozdForBuy) {
          this.karmozdForBuy = karmozdForBuy;
      }


      /**
       * Gets the karmozdForSell value for this OMSSetting.
       *
       * @return karmozdForSell
       */
      public double getKarmozdForSell() {
          return karmozdForSell;
      }


      /**
       * Sets the karmozdForSell value for this OMSSetting.
       *
       * @param karmozdForSell
       */
      public void setKarmozdForSell(double karmozdForSell) {
          this.karmozdForSell = karmozdForSell;
      }


      /**
       * Gets the khadamatsherkatbourceAccount2ForBuy value for this OMSSetting.
       *
       * @return khadamatsherkatbourceAccount2ForBuy
       */
      public java.lang.String getKhadamatsherkatbourceAccount2ForBuy() {
          return khadamatsherkatbourceAccount2ForBuy;
      }


      /**
       * Sets the khadamatsherkatbourceAccount2ForBuy value for this OMSSetting.
       *
       * @param khadamatsherkatbourceAccount2ForBuy
       */
      public void setKhadamatsherkatbourceAccount2ForBuy(java.lang.String khadamatsherkatbourceAccount2ForBuy) {
          this.khadamatsherkatbourceAccount2ForBuy = khadamatsherkatbourceAccount2ForBuy;
      }


      /**
       * Gets the khadamatsherkatbourceAccount2ForSell value for this OMSSetting.
       *
       * @return khadamatsherkatbourceAccount2ForSell
       */
      public java.lang.String getKhadamatsherkatbourceAccount2ForSell() {
          return khadamatsherkatbourceAccount2ForSell;
      }


      /**
       * Sets the khadamatsherkatbourceAccount2ForSell value for this OMSSetting.
       *
       * @param khadamatsherkatbourceAccount2ForSell
       */
      public void setKhadamatsherkatbourceAccount2ForSell(java.lang.String khadamatsherkatbourceAccount2ForSell) {
          this.khadamatsherkatbourceAccount2ForSell = khadamatsherkatbourceAccount2ForSell;
      }


      /**
       * Gets the khadamatsherkatbourceAccountForBuy value for this OMSSetting.
       *
       * @return khadamatsherkatbourceAccountForBuy
       */
      public java.lang.String getKhadamatsherkatbourceAccountForBuy() {
          return khadamatsherkatbourceAccountForBuy;
      }


      /**
       * Sets the khadamatsherkatbourceAccountForBuy value for this OMSSetting.
       *
       * @param khadamatsherkatbourceAccountForBuy
       */
      public void setKhadamatsherkatbourceAccountForBuy(java.lang.String khadamatsherkatbourceAccountForBuy) {
          this.khadamatsherkatbourceAccountForBuy = khadamatsherkatbourceAccountForBuy;
      }


      /**
       * Gets the khadamatsherkatbourceAccountForSell value for this OMSSetting.
       *
       * @return khadamatsherkatbourceAccountForSell
       */
      public java.lang.String getKhadamatsherkatbourceAccountForSell() {
          return khadamatsherkatbourceAccountForSell;
      }


      /**
       * Sets the khadamatsherkatbourceAccountForSell value for this OMSSetting.
       *
       * @param khadamatsherkatbourceAccountForSell
       */
      public void setKhadamatsherkatbourceAccountForSell(java.lang.String khadamatsherkatbourceAccountForSell) {
          this.khadamatsherkatbourceAccountForSell = khadamatsherkatbourceAccountForSell;
      }


      /**
       * Gets the maxRequestPerSecond value for this OMSSetting.
       *
       * @return maxRequestPerSecond
       */
      public long getMaxRequestPerSecond() {
          return maxRequestPerSecond;
      }


      /**
       * Sets the maxRequestPerSecond value for this OMSSetting.
       *
       * @param maxRequestPerSecond
       */
      public void setMaxRequestPerSecond(long maxRequestPerSecond) {
          this.maxRequestPerSecond = maxRequestPerSecond;
      }


      /**
       * Gets the maleyatAccount value for this OMSSetting.
       *
       * @return maleyatAccount
       */
      public java.lang.String getMaleyatAccount() {
          return maleyatAccount;
      }


      /**
       * Sets the maleyatAccount value for this OMSSetting.
       *
       * @param maleyatAccount
       */
      public void setMaleyatAccount(java.lang.String maleyatAccount) {
          this.maleyatAccount = maleyatAccount;
      }


      /**
       * Gets the marketCloseTime value for this OMSSetting.
       *
       * @return marketCloseTime
       */
      public java.lang.String getMarketCloseTime() {
          return marketCloseTime;
      }


      /**
       * Sets the marketCloseTime value for this OMSSetting.
       *
       * @param marketCloseTime
       */
      public void setMarketCloseTime(java.lang.String marketCloseTime) {
          this.marketCloseTime = marketCloseTime;
      }


      /**
       * Gets the marketOpenTime value for this OMSSetting.
       *
       * @return marketOpenTime
       */
      public java.lang.String getMarketOpenTime() {
          return marketOpenTime;
      }


      /**
       * Sets the marketOpenTime value for this OMSSetting.
       *
       * @param marketOpenTime
       */
      public void setMarketOpenTime(java.lang.String marketOpenTime) {
          this.marketOpenTime = marketOpenTime;
      }


      /**
       * Gets the maximumDateRangeForBuy value for this OMSSetting.
       *
       * @return maximumDateRangeForBuy
       */
      public long getMaximumDateRangeForBuy() {
          return maximumDateRangeForBuy;
      }


      /**
       * Sets the maximumDateRangeForBuy value for this OMSSetting.
       *
       * @param maximumDateRangeForBuy
       */
      public void setMaximumDateRangeForBuy(long maximumDateRangeForBuy) {
          this.maximumDateRangeForBuy = maximumDateRangeForBuy;
      }


      /**
       * Gets the maximumDateRangeForSell value for this OMSSetting.
       *
       * @return maximumDateRangeForSell
       */
      public long getMaximumDateRangeForSell() {
          return maximumDateRangeForSell;
      }


      /**
       * Sets the maximumDateRangeForSell value for this OMSSetting.
       *
       * @param maximumDateRangeForSell
       */
      public void setMaximumDateRangeForSell(long maximumDateRangeForSell) {
          this.maximumDateRangeForSell = maximumDateRangeForSell;
      }


      /**
       * Gets the maximumOrderCountForBuy value for this OMSSetting.
       *
       * @return maximumOrderCountForBuy
       */
      public long getMaximumOrderCountForBuy() {
          return maximumOrderCountForBuy;
      }


      /**
       * Sets the maximumOrderCountForBuy value for this OMSSetting.
       *
       * @param maximumOrderCountForBuy
       */
      public void setMaximumOrderCountForBuy(long maximumOrderCountForBuy) {
          this.maximumOrderCountForBuy = maximumOrderCountForBuy;
      }


      /**
       * Gets the maximumOrderCountForSell value for this OMSSetting.
       *
       * @return maximumOrderCountForSell
       */
      public long getMaximumOrderCountForSell() {
          return maximumOrderCountForSell;
      }


      /**
       * Sets the maximumOrderCountForSell value for this OMSSetting.
       *
       * @param maximumOrderCountForSell
       */
      public void setMaximumOrderCountForSell(long maximumOrderCountForSell) {
          this.maximumOrderCountForSell = maximumOrderCountForSell;
      }


      /**
       * Gets the maximumOrderValueForBuy value for this OMSSetting.
       *
       * @return maximumOrderValueForBuy
       */
      public long getMaximumOrderValueForBuy() {
          return maximumOrderValueForBuy;
      }


      /**
       * Sets the maximumOrderValueForBuy value for this OMSSetting.
       *
       * @param maximumOrderValueForBuy
       */
      public void setMaximumOrderValueForBuy(long maximumOrderValueForBuy) {
          this.maximumOrderValueForBuy = maximumOrderValueForBuy;
      }


      /**
       * Gets the maximumOrderValueForSell value for this OMSSetting.
       *
       * @return maximumOrderValueForSell
       */
      public long getMaximumOrderValueForSell() {
          return maximumOrderValueForSell;
      }


      /**
       * Sets the maximumOrderValueForSell value for this OMSSetting.
       *
       * @param maximumOrderValueForSell
       */
      public void setMaximumOrderValueForSell(long maximumOrderValueForSell) {
          this.maximumOrderValueForSell = maximumOrderValueForSell;
      }


      /**
       * Gets the mellatAccountCode value for this OMSSetting.
       *
       * @return mellatAccountCode
       */
      public java.lang.String getMellatAccountCode() {
          return mellatAccountCode;
      }


      /**
       * Sets the mellatAccountCode value for this OMSSetting.
       *
       * @param mellatAccountCode
       */
      public void setMellatAccountCode(java.lang.String mellatAccountCode) {
          this.mellatAccountCode = mellatAccountCode;
      }


      /**
       * Gets the mellatPublicKey value for this OMSSetting.
       *
       * @return mellatPublicKey
       */
      public java.lang.String getMellatPublicKey() {
          return mellatPublicKey;
      }


      /**
       * Sets the mellatPublicKey value for this OMSSetting.
       *
       * @param mellatPublicKey
       */
      public void setMellatPublicKey(java.lang.String mellatPublicKey) {
          this.mellatPublicKey = mellatPublicKey;
      }


      /**
       * Gets the minimumOrderCountForBuy value for this OMSSetting.
       *
       * @return minimumOrderCountForBuy
       */
      public int getMinimumOrderCountForBuy() {
          return minimumOrderCountForBuy;
      }


      /**
       * Sets the minimumOrderCountForBuy value for this OMSSetting.
       *
       * @param minimumOrderCountForBuy
       */
      public void setMinimumOrderCountForBuy(int minimumOrderCountForBuy) {
          this.minimumOrderCountForBuy = minimumOrderCountForBuy;
      }


      /**
       * Gets the minimumOrderCountForSell value for this OMSSetting.
       *
       * @return minimumOrderCountForSell
       */
      public int getMinimumOrderCountForSell() {
          return minimumOrderCountForSell;
      }


      /**
       * Sets the minimumOrderCountForSell value for this OMSSetting.
       *
       * @param minimumOrderCountForSell
       */
      public void setMinimumOrderCountForSell(int minimumOrderCountForSell) {
          this.minimumOrderCountForSell = minimumOrderCountForSell;
      }


      /**
       * Gets the minimumOrderValueForBuy value for this OMSSetting.
       *
       * @return minimumOrderValueForBuy
       */
      public int getMinimumOrderValueForBuy() {
          return minimumOrderValueForBuy;
      }


      /**
       * Sets the minimumOrderValueForBuy value for this OMSSetting.
       *
       * @param minimumOrderValueForBuy
       */
      public void setMinimumOrderValueForBuy(int minimumOrderValueForBuy) {
          this.minimumOrderValueForBuy = minimumOrderValueForBuy;
      }


      /**
       * Gets the minimumOrderValueForSell value for this OMSSetting.
       *
       * @return minimumOrderValueForSell
       */
      public int getMinimumOrderValueForSell() {
          return minimumOrderValueForSell;
      }


      /**
       * Sets the minimumOrderValueForSell value for this OMSSetting.
       *
       * @param minimumOrderValueForSell
       */
      public void setMinimumOrderValueForSell(int minimumOrderValueForSell) {
          this.minimumOrderValueForSell = minimumOrderValueForSell;
      }


      /**
       * Gets the moamelatBrokerKarmozdAccountForBuy value for this OMSSetting.
       *
       * @return moamelatBrokerKarmozdAccountForBuy
       */
      public java.lang.String getMoamelatBrokerKarmozdAccountForBuy() {
          return moamelatBrokerKarmozdAccountForBuy;
      }


      /**
       * Sets the moamelatBrokerKarmozdAccountForBuy value for this OMSSetting.
       *
       * @param moamelatBrokerKarmozdAccountForBuy
       */
      public void setMoamelatBrokerKarmozdAccountForBuy(java.lang.String moamelatBrokerKarmozdAccountForBuy) {
          this.moamelatBrokerKarmozdAccountForBuy = moamelatBrokerKarmozdAccountForBuy;
      }


      /**
       * Gets the moamelatBrokerKarmozdAccountForSell value for this OMSSetting.
       *
       * @return moamelatBrokerKarmozdAccountForSell
       */
      public java.lang.String getMoamelatBrokerKarmozdAccountForSell() {
          return moamelatBrokerKarmozdAccountForSell;
      }


      /**
       * Sets the moamelatBrokerKarmozdAccountForSell value for this OMSSetting.
       *
       * @param moamelatBrokerKarmozdAccountForSell
       */
      public void setMoamelatBrokerKarmozdAccountForSell(java.lang.String moamelatBrokerKarmozdAccountForSell) {
          this.moamelatBrokerKarmozdAccountForSell = moamelatBrokerKarmozdAccountForSell;
      }


      /**
       * Gets the nezaratbourseKarmozdAccountForBuy value for this OMSSetting.
       *
       * @return nezaratbourseKarmozdAccountForBuy
       */
      public java.lang.String getNezaratbourseKarmozdAccountForBuy() {
          return nezaratbourseKarmozdAccountForBuy;
      }


      /**
       * Sets the nezaratbourseKarmozdAccountForBuy value for this OMSSetting.
       *
       * @param nezaratbourseKarmozdAccountForBuy
       */
      public void setNezaratbourseKarmozdAccountForBuy(java.lang.String nezaratbourseKarmozdAccountForBuy) {
          this.nezaratbourseKarmozdAccountForBuy = nezaratbourseKarmozdAccountForBuy;
      }


      /**
       * Gets the nezaratbourseKarmozdAccountForSell value for this OMSSetting.
       *
       * @return nezaratbourseKarmozdAccountForSell
       */
      public java.lang.String getNezaratbourseKarmozdAccountForSell() {
          return nezaratbourseKarmozdAccountForSell;
      }


      /**
       * Sets the nezaratbourseKarmozdAccountForSell value for this OMSSetting.
       *
       * @param nezaratbourseKarmozdAccountForSell
       */
      public void setNezaratbourseKarmozdAccountForSell(java.lang.String nezaratbourseKarmozdAccountForSell) {
          this.nezaratbourseKarmozdAccountForSell = nezaratbourseKarmozdAccountForSell;
      }


      /**
       * Gets the noReplayEmail value for this OMSSetting.
       *
       * @return noReplayEmail
       */
      public java.lang.String getNoReplayEmail() {
          return noReplayEmail;
      }


      /**
       * Sets the noReplayEmail value for this OMSSetting.
       *
       * @param noReplayEmail
       */
      public void setNoReplayEmail(java.lang.String noReplayEmail) {
          this.noReplayEmail = noReplayEmail;
      }


      /**
       * Gets the OMSDatabaseName value for this OMSSetting.
       *
       * @return OMSDatabaseName
       */
      public java.lang.String getOMSDatabaseName() {
          return OMSDatabaseName;
      }


      /**
       * Sets the OMSDatabaseName value for this OMSSetting.
       *
       * @param OMSDatabaseName
       */
      public void setOMSDatabaseName(java.lang.String OMSDatabaseName) {
          this.OMSDatabaseName = OMSDatabaseName;
      }


      /**
       * Gets the OMSDatabasePassword value for this OMSSetting.
       *
       * @return OMSDatabasePassword
       */
      public java.lang.String getOMSDatabasePassword() {
          return OMSDatabasePassword;
      }


      /**
       * Sets the OMSDatabasePassword value for this OMSSetting.
       *
       * @param OMSDatabasePassword
       */
      public void setOMSDatabasePassword(java.lang.String OMSDatabasePassword) {
          this.OMSDatabasePassword = OMSDatabasePassword;
      }


      /**
       * Gets the OMSDatabaseServer value for this OMSSetting.
       *
       * @return OMSDatabaseServer
       */
      public java.lang.String getOMSDatabaseServer() {
          return OMSDatabaseServer;
      }


      /**
       * Sets the OMSDatabaseServer value for this OMSSetting.
       *
       * @param OMSDatabaseServer
       */
      public void setOMSDatabaseServer(java.lang.String OMSDatabaseServer) {
          this.OMSDatabaseServer = OMSDatabaseServer;
      }


      /**
       * Gets the OMSDatabaseUserId value for this OMSSetting.
       *
       * @return OMSDatabaseUserId
       */
      public java.lang.String getOMSDatabaseUserId() {
          return OMSDatabaseUserId;
      }


      /**
       * Sets the OMSDatabaseUserId value for this OMSSetting.
       *
       * @param OMSDatabaseUserId
       */
      public void setOMSDatabaseUserId(java.lang.String OMSDatabaseUserId) {
          this.OMSDatabaseUserId = OMSDatabaseUserId;
      }


      /**
       * Gets the payapayAccount value for this OMSSetting.
       *
       * @return payapayAccount
       */
      public java.lang.String getPayapayAccount() {
          return payapayAccount;
      }


      /**
       * Sets the payapayAccount value for this OMSSetting.
       *
       * @param payapayAccount
       */
      public void setPayapayAccount(java.lang.String payapayAccount) {
          this.payapayAccount = payapayAccount;
      }


      /**
       * Gets the payapayAccountForBuy value for this OMSSetting.
       *
       * @return payapayAccountForBuy
       */
      public java.lang.String getPayapayAccountForBuy() {
          return payapayAccountForBuy;
      }


      /**
       * Sets the payapayAccountForBuy value for this OMSSetting.
       *
       * @param payapayAccountForBuy
       */
      public void setPayapayAccountForBuy(java.lang.String payapayAccountForBuy) {
          this.payapayAccountForBuy = payapayAccountForBuy;
      }


      /**
       * Gets the payapayAccountForSell value for this OMSSetting.
       *
       * @return payapayAccountForSell
       */
      public java.lang.String getPayapayAccountForSell() {
          return payapayAccountForSell;
      }


      /**
       * Sets the payapayAccountForSell value for this OMSSetting.
       *
       * @param payapayAccountForSell
       */
      public void setPayapayAccountForSell(java.lang.String payapayAccountForSell) {
          this.payapayAccountForSell = payapayAccountForSell;
      }


      /**
       * Gets the trustChainPath value for this OMSSetting.
       *
       * @return trustChainPath
       */
      public java.lang.String getTrustChainPath() {
          return trustChainPath;
      }


      /**
       * Sets the trustChainPath value for this OMSSetting.
       *
       * @param trustChainPath
       */
      public void setTrustChainPath(java.lang.String trustChainPath) {
          this.trustChainPath = trustChainPath;
      }


      /**
       * Gets the sellOrderEditCount value for this OMSSetting.
       *
       * @return sellOrderEditCount
       */
      public boolean isSellOrderEditCount() {
          return sellOrderEditCount;
      }


      /**
       * Sets the sellOrderEditCount value for this OMSSetting.
       *
       * @param sellOrderEditCount
       */
      public void setSellOrderEditCount(boolean sellOrderEditCount) {
          this.sellOrderEditCount = sellOrderEditCount;
      }


      /**
       * Gets the sellOrderEditMinQty value for this OMSSetting.
       *
       * @return sellOrderEditMinQty
       */
      public boolean isSellOrderEditMinQty() {
          return sellOrderEditMinQty;
      }


      /**
       * Sets the sellOrderEditMinQty value for this OMSSetting.
       *
       * @param sellOrderEditMinQty
       */
      public void setSellOrderEditMinQty(boolean sellOrderEditMinQty) {
          this.sellOrderEditMinQty = sellOrderEditMinQty;
      }


      /**
       * Gets the sellOrderEditPrice value for this OMSSetting.
       *
       * @return sellOrderEditPrice
       */
      public boolean isSellOrderEditPrice() {
          return sellOrderEditPrice;
      }


      /**
       * Sets the sellOrderEditPrice value for this OMSSetting.
       *
       * @param sellOrderEditPrice
       */
      public void setSellOrderEditPrice(boolean sellOrderEditPrice) {
          this.sellOrderEditPrice = sellOrderEditPrice;
      }


      /**
       * Gets the sellOrderEditShownVolume value for this OMSSetting.
       *
       * @return sellOrderEditShownVolume
       */
      public boolean isSellOrderEditShownVolume() {
          return sellOrderEditShownVolume;
      }


      /**
       * Sets the sellOrderEditShownVolume value for this OMSSetting.
       *
       * @param sellOrderEditShownVolume
       */
      public void setSellOrderEditShownVolume(boolean sellOrderEditShownVolume) {
          this.sellOrderEditShownVolume = sellOrderEditShownVolume;
      }


      /**
       * Gets the sellOrderEditValidity value for this OMSSetting.
       *
       * @return sellOrderEditValidity
       */
      public boolean isSellOrderEditValidity() {
          return sellOrderEditValidity;
      }


      /**
       * Sets the sellOrderEditValidity value for this OMSSetting.
       *
       * @param sellOrderEditValidity
       */
      public void setSellOrderEditValidity(boolean sellOrderEditValidity) {
          this.sellOrderEditValidity = sellOrderEditValidity;
      }


      /**
       * Gets the sepordehGozariAccountForBuy value for this OMSSetting.
       *
       * @return sepordehGozariAccountForBuy
       */
      public java.lang.String getSepordehGozariAccountForBuy() {
          return sepordehGozariAccountForBuy;
      }


      /**
       * Sets the sepordehGozariAccountForBuy value for this OMSSetting.
       *
       * @param sepordehGozariAccountForBuy
       */
      public void setSepordehGozariAccountForBuy(java.lang.String sepordehGozariAccountForBuy) {
          this.sepordehGozariAccountForBuy = sepordehGozariAccountForBuy;
      }


      /**
       * Gets the sepordehGozariAccountForSell value for this OMSSetting.
       *
       * @return sepordehGozariAccountForSell
       */
      public java.lang.String getSepordehGozariAccountForSell() {
          return sepordehGozariAccountForSell;
      }


      /**
       * Sets the sepordehGozariAccountForSell value for this OMSSetting.
       *
       * @param sepordehGozariAccountForSell
       */
      public void setSepordehGozariAccountForSell(java.lang.String sepordehGozariAccountForSell) {
          this.sepordehGozariAccountForSell = sepordehGozariAccountForSell;
      }


      /**
       * Gets the serviceMailApplicationId value for this OMSSetting.
       *
       * @return serviceMailApplicationId
       */
      public int getServiceMailApplicationId() {
          return serviceMailApplicationId;
      }


      /**
       * Sets the serviceMailApplicationId value for this OMSSetting.
       *
       * @param serviceMailApplicationId
       */
      public void setServiceMailApplicationId(int serviceMailApplicationId) {
          this.serviceMailApplicationId = serviceMailApplicationId;
      }


      /**
       * Gets the serviceMailPassword value for this OMSSetting.
       *
       * @return serviceMailPassword
       */
      public java.lang.String getServiceMailPassword() {
          return serviceMailPassword;
      }


      /**
       * Sets the serviceMailPassword value for this OMSSetting.
       *
       * @param serviceMailPassword
       */
      public void setServiceMailPassword(java.lang.String serviceMailPassword) {
          this.serviceMailPassword = serviceMailPassword;
      }


      /**
       * Gets the serviceMailUserName value for this OMSSetting.
       *
       * @return serviceMailUserName
       */
      public java.lang.String getServiceMailUserName() {
          return serviceMailUserName;
      }


      /**
       * Sets the serviceMailUserName value for this OMSSetting.
       *
       * @param serviceMailUserName
       */
      public void setServiceMailUserName(java.lang.String serviceMailUserName) {
          this.serviceMailUserName = serviceMailUserName;
      }


      /**
       * Gets the smtpServer value for this OMSSetting.
       *
       * @return smtpServer
       */
      public java.lang.String getSmtpServer() {
          return smtpServer;
      }


      /**
       * Sets the smtpServer value for this OMSSetting.
       *
       * @param smtpServer
       */
      public void setSmtpServer(java.lang.String smtpServer) {
          this.smtpServer = smtpServer;
      }


      /**
       * Gets the smtpServerPassword value for this OMSSetting.
       *
       * @return smtpServerPassword
       */
      public java.lang.String getSmtpServerPassword() {
          return smtpServerPassword;
      }


      /**
       * Sets the smtpServerPassword value for this OMSSetting.
       *
       * @param smtpServerPassword
       */
      public void setSmtpServerPassword(java.lang.String smtpServerPassword) {
          this.smtpServerPassword = smtpServerPassword;
      }


      /**
       * Gets the smtpServerPort value for this OMSSetting.
       *
       * @return smtpServerPort
       */
      public java.lang.String getSmtpServerPort() {
          return smtpServerPort;
      }


      /**
       * Sets the smtpServerPort value for this OMSSetting.
       *
       * @param smtpServerPort
       */
      public void setSmtpServerPort(java.lang.String smtpServerPort) {
          this.smtpServerPort = smtpServerPort;
      }


      /**
       * Gets the smtpServerUserName value for this OMSSetting.
       *
       * @return smtpServerUserName
       */
      public java.lang.String getSmtpServerUserName() {
          return smtpServerUserName;
      }


      /**
       * Sets the smtpServerUserName value for this OMSSetting.
       *
       * @param smtpServerUserName
       */
      public void setSmtpServerUserName(java.lang.String smtpServerUserName) {
          this.smtpServerUserName = smtpServerUserName;
      }


      /**
       * Gets the smtpServerUsingNtlm value for this OMSSetting.
       *
       * @return smtpServerUsingNtlm
       */
      public boolean isSmtpServerUsingNtlm() {
          return smtpServerUsingNtlm;
      }


      /**
       * Sets the smtpServerUsingNtlm value for this OMSSetting.
       *
       * @param smtpServerUsingNtlm
       */
      public void setSmtpServerUsingNtlm(boolean smtpServerUsingNtlm) {
          this.smtpServerUsingNtlm = smtpServerUsingNtlm;
      }


      /**
       * Gets the tafavotAccount value for this OMSSetting.
       *
       * @return tafavotAccount
       */
      public java.lang.String getTafavotAccount() {
          return tafavotAccount;
      }


      /**
       * Sets the tafavotAccount value for this OMSSetting.
       *
       * @param tafavotAccount
       */
      public void setTafavotAccount(java.lang.String tafavotAccount) {
          this.tafavotAccount = tafavotAccount;
      }


      /**
       * Gets the themeName value for this OMSSetting.
       *
       * @return themeName
       */
      public java.lang.String getThemeName() {
          return themeName;
      }


      /**
       * Sets the themeName value for this OMSSetting.
       *
       * @param themeName
       */
      public void setThemeName(java.lang.String themeName) {
          this.themeName = themeName;
      }


      /**
       * Gets the thresholdVariant value for this OMSSetting.
       *
       * @return thresholdVariant
       */
      public double getThresholdVariant() {
          return thresholdVariant;
      }


      /**
       * Sets the thresholdVariant value for this OMSSetting.
       *
       * @param thresholdVariant
       */
      public void setThresholdVariant(double thresholdVariant) {
          this.thresholdVariant = thresholdVariant;
      }


      /**
       * Gets the townCode value for this OMSSetting.
       *
       * @return townCode
       */
      public java.lang.String getTownCode() {
          return townCode;
      }


      /**
       * Sets the townCode value for this OMSSetting.
       *
       * @param townCode
       */
      public void setTownCode(java.lang.String townCode) {
          this.townCode = townCode;
      }


      /**
       * Gets the traderId value for this OMSSetting.
       *
       * @return traderId
       */
      public java.lang.String getTraderId() {
          return traderId;
      }


      /**
       * Sets the traderId value for this OMSSetting.
       *
       * @param traderId
       */
      public void setTraderId(java.lang.String traderId) {
          this.traderId = traderId;
      }


      /**
       * Gets the version value for this OMSSetting.
       *
       * @return version
       */
      public java.lang.String getVersion() {
          return version;
      }


      /**
       * Sets the version value for this OMSSetting.
       *
       * @param version
       */
      public void setVersion(java.lang.String version) {
          this.version = version;
      }


      /**
       * Gets the webSocketAddress value for this OMSSetting.
       *
       * @return webSocketAddress
       */
      public java.lang.String getWebSocketAddress() {
          return webSocketAddress;
      }


      /**
       * Sets the webSocketAddress value for this OMSSetting.
       *
       * @param webSocketAddress
       */
      public void setWebSocketAddress(java.lang.String webSocketAddress) {
          this.webSocketAddress = webSocketAddress;
      }


      /**
       * Gets the maxAssetPrint value for this OMSSetting.
       *
       * @return maxAssetPrint
       */
      public int getMaxAssetPrint() {
          return maxAssetPrint;
      }


      /**
       * Sets the maxAssetPrint value for this OMSSetting.
       *
       * @param maxAssetPrint
       */
      public void setMaxAssetPrint(int maxAssetPrint) {
          this.maxAssetPrint = maxAssetPrint;
      }


      /**
       * Gets the accessToPageSystemActivity value for this OMSSetting.
       *
       * @return accessToPageSystemActivity
       */
      public java.lang.String getAccessToPageSystemActivity() {
          return accessToPageSystemActivity;
      }


      /**
       * Sets the accessToPageSystemActivity value for this OMSSetting.
       *
       * @param accessToPageSystemActivity
       */
      public void setAccessToPageSystemActivity(java.lang.String accessToPageSystemActivity) {
          this.accessToPageSystemActivity = accessToPageSystemActivity;
      }


      /**
       * Gets the porofilerAppId value for this OMSSetting.
       *
       * @return porofilerAppId
       */
      public int getPorofilerAppId() {
          return porofilerAppId;
      }


      /**
       * Sets the porofilerAppId value for this OMSSetting.
       *
       * @param porofilerAppId
       */
      public void setPorofilerAppId(int porofilerAppId) {
          this.porofilerAppId = porofilerAppId;
      }


      /**
       * Gets the networkPerformenceURL value for this OMSSetting.
       *
       * @return networkPerformenceURL
       */
      public java.lang.String getNetworkPerformenceURL() {
          return networkPerformenceURL;
      }


      /**
       * Sets the networkPerformenceURL value for this OMSSetting.
       *
       * @param networkPerformenceURL
       */
      public void setNetworkPerformenceURL(java.lang.String networkPerformenceURL) {
          this.networkPerformenceURL = networkPerformenceURL;
      }


      /**
       * Gets the googleAnalytics value for this OMSSetting.
       *
       * @return googleAnalytics
       */
      public java.lang.String getGoogleAnalytics() {
          return googleAnalytics;
      }


      /**
       * Sets the googleAnalytics value for this OMSSetting.
       *
       * @param googleAnalytics
       */
      public void setGoogleAnalytics(java.lang.String googleAnalytics) {
          this.googleAnalytics = googleAnalytics;
      }


      /**
       * Gets the userBrowserVersion value for this OMSSetting.
       *
       * @return userBrowserVersion
       */
      public java.lang.String getUserBrowserVersion() {
          return userBrowserVersion;
      }


      /**
       * Sets the userBrowserVersion value for this OMSSetting.
       *
       * @param userBrowserVersion
       */
      public void setUserBrowserVersion(java.lang.String userBrowserVersion) {
          this.userBrowserVersion = userBrowserVersion;
      }


      /**
       * Gets the changePasswordCycle value for this OMSSetting.
       *
       * @return changePasswordCycle
       */
      public int getChangePasswordCycle() {
          return changePasswordCycle;
      }


      /**
       * Sets the changePasswordCycle value for this OMSSetting.
       *
       * @param changePasswordCycle
       */
      public void setChangePasswordCycle(int changePasswordCycle) {
          this.changePasswordCycle = changePasswordCycle;
      }


      /**
       * Gets the lockUserCycle value for this OMSSetting.
       *
       * @return lockUserCycle
       */
      public int getLockUserCycle() {
          return lockUserCycle;
      }


      /**
       * Sets the lockUserCycle value for this OMSSetting.
       *
       * @param lockUserCycle
       */
      public void setLockUserCycle(int lockUserCycle) {
          this.lockUserCycle = lockUserCycle;
      }


      /**
       * Gets the userBrowserFlashPlayerVersion value for this OMSSetting.
       *
       * @return userBrowserFlashPlayerVersion
       */
      public java.lang.String getUserBrowserFlashPlayerVersion() {
          return userBrowserFlashPlayerVersion;
      }


      /**
       * Sets the userBrowserFlashPlayerVersion value for this OMSSetting.
       *
       * @param userBrowserFlashPlayerVersion
       */
      public void setUserBrowserFlashPlayerVersion(java.lang.String userBrowserFlashPlayerVersion) {
          this.userBrowserFlashPlayerVersion = userBrowserFlashPlayerVersion;
      }


      /**
       * Gets the userReportJobStartTime value for this OMSSetting.
       *
       * @return userReportJobStartTime
       */
      public int getUserReportJobStartTime() {
          return userReportJobStartTime;
      }


      /**
       * Sets the userReportJobStartTime value for this OMSSetting.
       *
       * @param userReportJobStartTime
       */
      public void setUserReportJobStartTime(int userReportJobStartTime) {
          this.userReportJobStartTime = userReportJobStartTime;
      }


      /**
       * Gets the retrievingDataMethods value for this OMSSetting.
       *
       * @return retrievingDataMethods
       */
      public java.lang.String getRetrievingDataMethods() {
          return retrievingDataMethods;
      }


      /**
       * Sets the retrievingDataMethods value for this OMSSetting.
       *
       * @param retrievingDataMethods
       */
      public void setRetrievingDataMethods(java.lang.String retrievingDataMethods) {
          this.retrievingDataMethods = retrievingDataMethods;
      }


      /**
       * Gets the showFill_And_Kill value for this OMSSetting.
       *
       * @return showFill_And_Kill
       */
      public boolean isShowFill_And_Kill() {
          return showFill_And_Kill;
      }


      /**
       * Sets the showFill_And_Kill value for this OMSSetting.
       *
       * @param showFill_And_Kill
       */
      public void setShowFill_And_Kill(boolean showFill_And_Kill) {
          this.showFill_And_Kill = showFill_And_Kill;
      }


      /**
       * Gets the externalResourceTimeOut value for this OMSSetting.
       *
       * @return externalResourceTimeOut
       */
      public int getExternalResourceTimeOut() {
          return externalResourceTimeOut;
      }


      /**
       * Sets the externalResourceTimeOut value for this OMSSetting.
       *
       * @param externalResourceTimeOut
       */
      public void setExternalResourceTimeOut(int externalResourceTimeOut) {
          this.externalResourceTimeOut = externalResourceTimeOut;
      }


      /**
       * Gets the sendSMS value for this OMSSetting.
       *
       * @return sendSMS
       */
      public boolean isSendSMS() {
          return sendSMS;
      }


      /**
       * Sets the sendSMS value for this OMSSetting.
       *
       * @param sendSMS
       */
      public void setSendSMS(boolean sendSMS) {
          this.sendSMS = sendSMS;
      }

      private java.lang.Object __equalsCalc = null;
      public synchronized boolean equals(java.lang.Object obj) {
          if (!(obj instanceof OMSSetting)) return false;
          OMSSetting other = (OMSSetting) obj;
          if (obj == null) return false;
          if (this == obj) return true;
          if (__equalsCalc != null) {
              return (__equalsCalc == obj);
          }
          __equalsCalc = obj;
          boolean _equals;
          _equals = true &&
              ((this.automationUsernamePrefix==null && other.getAutomationUsernamePrefix()==null) ||
               (this.automationUsernamePrefix!=null &&
                this.automationUsernamePrefix.equals(other.getAutomationUsernamePrefix()))) &&
              ((this.automationAccountingPrefix==null && other.getAutomationAccountingPrefix()==null) ||
               (this.automationAccountingPrefix!=null &&
                this.automationAccountingPrefix.equals(other.getAutomationAccountingPrefix()))) &&
              ((this.RLCServerAddrerss==null && other.getRLCServerAddrerss()==null) ||
               (this.RLCServerAddrerss!=null &&
                this.RLCServerAddrerss.equals(other.getRLCServerAddrerss()))) &&
              ((this.cancelStartTime==null && other.getCancelStartTime()==null) ||
               (this.cancelStartTime!=null &&
                this.cancelStartTime.equals(other.getCancelStartTime()))) &&
              ((this.cancelEndTime==null && other.getCancelEndTime()==null) ||
               (this.cancelEndTime!=null &&
                this.cancelEndTime.equals(other.getCancelEndTime()))) &&
              ((this.forbiddenOrderStartTime==null && other.getForbiddenOrderStartTime()==null) ||
               (this.forbiddenOrderStartTime!=null &&
                this.forbiddenOrderStartTime.equals(other.getForbiddenOrderStartTime()))) &&
              ((this.forbiddenOrderEndTime==null && other.getForbiddenOrderEndTime()==null) ||
               (this.forbiddenOrderEndTime!=null &&
                this.forbiddenOrderEndTime.equals(other.getForbiddenOrderEndTime()))) &&
              this.forbiddenOrderValidity == other.getForbiddenOrderValidity() &&
              this.diffBestPercent == other.getDiffBestPercent() &&
              ((this.startTimeLastTradedPriceDiff==null && other.getStartTimeLastTradedPriceDiff()==null) ||
               (this.startTimeLastTradedPriceDiff!=null &&
                this.startTimeLastTradedPriceDiff.equals(other.getStartTimeLastTradedPriceDiff()))) &&
              ((this.endTimeLastTradedPriceDiff==null && other.getEndTimeLastTradedPriceDiff()==null) ||
               (this.endTimeLastTradedPriceDiff!=null &&
                this.endTimeLastTradedPriceDiff.equals(other.getEndTimeLastTradedPriceDiff()))) &&
              ((this.siteThemes==null && other.getSiteThemes()==null) ||
               (this.siteThemes!=null &&
                this.siteThemes.equals(other.getSiteThemes()))) &&
              this.volumeThresholdForDiff == other.getVolumeThresholdForDiff() &&
              this.valueThresholdForBuy == other.getValueThresholdForBuy() &&
              this.lastTradePriceDiffPercent == other.getLastTradePriceDiffPercent() &&
              this.checkRuleForBranchSupervisor == other.isCheckRuleForBranchSupervisor() &&
              ((this.accountingDatabasePassword==null && other.getAccountingDatabasePassword()==null) ||
               (this.accountingDatabasePassword!=null &&
                this.accountingDatabasePassword.equals(other.getAccountingDatabasePassword()))) &&
              ((this.accountingDatabaseServer==null && other.getAccountingDatabaseServer()==null) ||
               (this.accountingDatabaseServer!=null &&
                this.accountingDatabaseServer.equals(other.getAccountingDatabaseServer()))) &&
              ((this.accountingDatabaseUserId==null && other.getAccountingDatabaseUserId()==null) ||
               (this.accountingDatabaseUserId!=null &&
                this.accountingDatabaseUserId.equals(other.getAccountingDatabaseUserId()))) &&
              ((this.accountingFinancialYear==null && other.getAccountingFinancialYear()==null) ||
               (this.accountingFinancialYear!=null &&
                this.accountingFinancialYear.equals(other.getAccountingFinancialYear()))) &&
              ((this.accountingGroupNo==null && other.getAccountingGroupNo()==null) ||
               (this.accountingGroupNo!=null &&
                this.accountingGroupNo.equals(other.getAccountingGroupNo()))) &&
              this.accountingUserId == other.getAccountingUserId() &&
              this.activeBuyRequestForCustomerWithoutBalance == other.isActiveBuyRequestForCustomerWithoutBalance() &&
              this.activeRightForBuy == other.isActiveRightForBuy() &&
              this.activeRightForSell == other.isActiveRightForSell() &&
              ((this.bankCode==null && other.getBankCode()==null) ||
               (this.bankCode!=null &&
                this.bankCode.equals(other.getBankCode()))) &&
              ((this.bourseKarmozdAccountForBuy==null && other.getBourseKarmozdAccountForBuy()==null) ||
               (this.bourseKarmozdAccountForBuy!=null &&
                this.bourseKarmozdAccountForBuy.equals(other.getBourseKarmozdAccountForBuy()))) &&
              ((this.bourseKarmozdAccountForSell==null && other.getBourseKarmozdAccountForSell()==null) ||
               (this.bourseKarmozdAccountForSell!=null &&
                this.bourseKarmozdAccountForSell.equals(other.getBourseKarmozdAccountForSell()))) &&
              ((this.branchCode==null && other.getBranchCode()==null) ||
               (this.branchCode!=null &&
                this.branchCode.equals(other.getBranchCode()))) &&
              ((this.brokerId==null && other.getBrokerId()==null) ||
               (this.brokerId!=null &&
                this.brokerId.equals(other.getBrokerId()))) &&
              ((this.brokerName==null && other.getBrokerName()==null) ||
               (this.brokerName!=null &&
                this.brokerName.equals(other.getBrokerName()))) &&
              ((this.brokerWebSite==null && other.getBrokerWebSite()==null) ||
               (this.brokerWebSite!=null &&
                this.brokerWebSite.equals(other.getBrokerWebSite()))) &&
              ((this.brokerWebSiteDB==null && other.getBrokerWebSiteDB()==null) ||
               (this.brokerWebSiteDB!=null &&
                this.brokerWebSiteDB.equals(other.getBrokerWebSiteDB()))) &&
              this.buyOrderEditCount == other.isBuyOrderEditCount() &&
              this.buyOrderEditMinQty == other.isBuyOrderEditMinQty() &&
              this.buyOrderEditPrice == other.isBuyOrderEditPrice() &&
              this.buyOrderEditShownVolume == other.isBuyOrderEditShownVolume() &&
              this.buyOrderEditValidity == other.isBuyOrderEditValidity() &&
              ((this.callBackUrl==null && other.getCallBackUrl()==null) ||
               (this.callBackUrl!=null &&
                this.callBackUrl.equals(other.getCallBackUrl()))) &&
              this.canBuy == other.isCanBuy() &&
              this.canBuySell == other.isCanBuySell() &&
              this.canSell == other.isCanSell() &&
              ((this.CDSPassword==null && other.getCDSPassword()==null) ||
               (this.CDSPassword!=null &&
                this.CDSPassword.equals(other.getCDSPassword()))) &&
              ((this.CDSUserName==null && other.getCDSUserName()==null) ||
               (this.CDSUserName!=null &&
                this.CDSUserName.equals(other.getCDSUserName()))) &&
              ((this.countryCode==null && other.getCountryCode()==null) ||
               (this.countryCode!=null &&
                this.countryCode.equals(other.getCountryCode()))) &&
              ((this.customerAccount==null && other.getCustomerAccount()==null) ||
               (this.customerAccount!=null &&
                this.customerAccount.equals(other.getCustomerAccount()))) &&
              this.defaultConfirmBranchVoucher == other.isDefaultConfirmBranchVoucher() &&
              this.enableSmtpSSL == other.isEnableSmtpSSL() &&
              ((this.fanavariAccountForBuy==null && other.getFanavariAccountForBuy()==null) ||
               (this.fanavariAccountForBuy!=null &&
                this.fanavariAccountForBuy.equals(other.getFanavariAccountForBuy()))) &&
              ((this.fanavariAccountForSell==null && other.getFanavariAccountForSell()==null) ||
               (this.fanavariAccountForSell!=null &&
                this.fanavariAccountForSell.equals(other.getFanavariAccountForSell()))) &&
              this.stockTableLimitForCustomer == other.getStockTableLimitForCustomer() &&
              this.stockTableLimitForBranch == other.getStockTableLimitForBranch() &&
              this.isReady == other.isIsReady() &&
              this.karmozdForBuy == other.getKarmozdForBuy() &&
              this.karmozdForSell == other.getKarmozdForSell() &&
              ((this.khadamatsherkatbourceAccount2ForBuy==null && other.getKhadamatsherkatbourceAccount2ForBuy()==null) ||
               (this.khadamatsherkatbourceAccount2ForBuy!=null &&
                this.khadamatsherkatbourceAccount2ForBuy.equals(other.getKhadamatsherkatbourceAccount2ForBuy()))) &&
              ((this.khadamatsherkatbourceAccount2ForSell==null && other.getKhadamatsherkatbourceAccount2ForSell()==null) ||
               (this.khadamatsherkatbourceAccount2ForSell!=null &&
                this.khadamatsherkatbourceAccount2ForSell.equals(other.getKhadamatsherkatbourceAccount2ForSell()))) &&
              ((this.khadamatsherkatbourceAccountForBuy==null && other.getKhadamatsherkatbourceAccountForBuy()==null) ||
               (this.khadamatsherkatbourceAccountForBuy!=null &&
                this.khadamatsherkatbourceAccountForBuy.equals(other.getKhadamatsherkatbourceAccountForBuy()))) &&
              ((this.khadamatsherkatbourceAccountForSell==null && other.getKhadamatsherkatbourceAccountForSell()==null) ||
               (this.khadamatsherkatbourceAccountForSell!=null &&
                this.khadamatsherkatbourceAccountForSell.equals(other.getKhadamatsherkatbourceAccountForSell()))) &&
              this.maxRequestPerSecond == other.getMaxRequestPerSecond() &&
              ((this.maleyatAccount==null && other.getMaleyatAccount()==null) ||
               (this.maleyatAccount!=null &&
                this.maleyatAccount.equals(other.getMaleyatAccount()))) &&
              ((this.marketCloseTime==null && other.getMarketCloseTime()==null) ||
               (this.marketCloseTime!=null &&
                this.marketCloseTime.equals(other.getMarketCloseTime()))) &&
              ((this.marketOpenTime==null && other.getMarketOpenTime()==null) ||
               (this.marketOpenTime!=null &&
                this.marketOpenTime.equals(other.getMarketOpenTime()))) &&
              this.maximumDateRangeForBuy == other.getMaximumDateRangeForBuy() &&
              this.maximumDateRangeForSell == other.getMaximumDateRangeForSell() &&
              this.maximumOrderCountForBuy == other.getMaximumOrderCountForBuy() &&
              this.maximumOrderCountForSell == other.getMaximumOrderCountForSell() &&
              this.maximumOrderValueForBuy == other.getMaximumOrderValueForBuy() &&
              this.maximumOrderValueForSell == other.getMaximumOrderValueForSell() &&
              ((this.mellatAccountCode==null && other.getMellatAccountCode()==null) ||
               (this.mellatAccountCode!=null &&
                this.mellatAccountCode.equals(other.getMellatAccountCode()))) &&
              ((this.mellatPublicKey==null && other.getMellatPublicKey()==null) ||
               (this.mellatPublicKey!=null &&
                this.mellatPublicKey.equals(other.getMellatPublicKey()))) &&
              this.minimumOrderCountForBuy == other.getMinimumOrderCountForBuy() &&
              this.minimumOrderCountForSell == other.getMinimumOrderCountForSell() &&
              this.minimumOrderValueForBuy == other.getMinimumOrderValueForBuy() &&
              this.minimumOrderValueForSell == other.getMinimumOrderValueForSell() &&
              ((this.moamelatBrokerKarmozdAccountForBuy==null && other.getMoamelatBrokerKarmozdAccountForBuy()==null) ||
               (this.moamelatBrokerKarmozdAccountForBuy!=null &&
                this.moamelatBrokerKarmozdAccountForBuy.equals(other.getMoamelatBrokerKarmozdAccountForBuy()))) &&
              ((this.moamelatBrokerKarmozdAccountForSell==null && other.getMoamelatBrokerKarmozdAccountForSell()==null) ||
               (this.moamelatBrokerKarmozdAccountForSell!=null &&
                this.moamelatBrokerKarmozdAccountForSell.equals(other.getMoamelatBrokerKarmozdAccountForSell()))) &&
              ((this.nezaratbourseKarmozdAccountForBuy==null && other.getNezaratbourseKarmozdAccountForBuy()==null) ||
               (this.nezaratbourseKarmozdAccountForBuy!=null &&
                this.nezaratbourseKarmozdAccountForBuy.equals(other.getNezaratbourseKarmozdAccountForBuy()))) &&
              ((this.nezaratbourseKarmozdAccountForSell==null && other.getNezaratbourseKarmozdAccountForSell()==null) ||
               (this.nezaratbourseKarmozdAccountForSell!=null &&
                this.nezaratbourseKarmozdAccountForSell.equals(other.getNezaratbourseKarmozdAccountForSell()))) &&
              ((this.noReplayEmail==null && other.getNoReplayEmail()==null) ||
               (this.noReplayEmail!=null &&
                this.noReplayEmail.equals(other.getNoReplayEmail()))) &&
              ((this.OMSDatabaseName==null && other.getOMSDatabaseName()==null) ||
               (this.OMSDatabaseName!=null &&
                this.OMSDatabaseName.equals(other.getOMSDatabaseName()))) &&
              ((this.OMSDatabasePassword==null && other.getOMSDatabasePassword()==null) ||
               (this.OMSDatabasePassword!=null &&
                this.OMSDatabasePassword.equals(other.getOMSDatabasePassword()))) &&
              ((this.OMSDatabaseServer==null && other.getOMSDatabaseServer()==null) ||
               (this.OMSDatabaseServer!=null &&
                this.OMSDatabaseServer.equals(other.getOMSDatabaseServer()))) &&
              ((this.OMSDatabaseUserId==null && other.getOMSDatabaseUserId()==null) ||
               (this.OMSDatabaseUserId!=null &&
                this.OMSDatabaseUserId.equals(other.getOMSDatabaseUserId()))) &&
              ((this.payapayAccount==null && other.getPayapayAccount()==null) ||
               (this.payapayAccount!=null &&
                this.payapayAccount.equals(other.getPayapayAccount()))) &&
              ((this.payapayAccountForBuy==null && other.getPayapayAccountForBuy()==null) ||
               (this.payapayAccountForBuy!=null &&
                this.payapayAccountForBuy.equals(other.getPayapayAccountForBuy()))) &&
              ((this.payapayAccountForSell==null && other.getPayapayAccountForSell()==null) ||
               (this.payapayAccountForSell!=null &&
                this.payapayAccountForSell.equals(other.getPayapayAccountForSell()))) &&
              ((this.trustChainPath==null && other.getTrustChainPath()==null) ||
               (this.trustChainPath!=null &&
                this.trustChainPath.equals(other.getTrustChainPath()))) &&
              this.sellOrderEditCount == other.isSellOrderEditCount() &&
              this.sellOrderEditMinQty == other.isSellOrderEditMinQty() &&
              this.sellOrderEditPrice == other.isSellOrderEditPrice() &&
              this.sellOrderEditShownVolume == other.isSellOrderEditShownVolume() &&
              this.sellOrderEditValidity == other.isSellOrderEditValidity() &&
              ((this.sepordehGozariAccountForBuy==null && other.getSepordehGozariAccountForBuy()==null) ||
               (this.sepordehGozariAccountForBuy!=null &&
                this.sepordehGozariAccountForBuy.equals(other.getSepordehGozariAccountForBuy()))) &&
              ((this.sepordehGozariAccountForSell==null && other.getSepordehGozariAccountForSell()==null) ||
               (this.sepordehGozariAccountForSell!=null &&
                this.sepordehGozariAccountForSell.equals(other.getSepordehGozariAccountForSell()))) &&
              this.serviceMailApplicationId == other.getServiceMailApplicationId() &&
              ((this.serviceMailPassword==null && other.getServiceMailPassword()==null) ||
               (this.serviceMailPassword!=null &&
                this.serviceMailPassword.equals(other.getServiceMailPassword()))) &&
              ((this.serviceMailUserName==null && other.getServiceMailUserName()==null) ||
               (this.serviceMailUserName!=null &&
                this.serviceMailUserName.equals(other.getServiceMailUserName()))) &&
              ((this.smtpServer==null && other.getSmtpServer()==null) ||
               (this.smtpServer!=null &&
                this.smtpServer.equals(other.getSmtpServer()))) &&
              ((this.smtpServerPassword==null && other.getSmtpServerPassword()==null) ||
               (this.smtpServerPassword!=null &&
                this.smtpServerPassword.equals(other.getSmtpServerPassword()))) &&
              ((this.smtpServerPort==null && other.getSmtpServerPort()==null) ||
               (this.smtpServerPort!=null &&
                this.smtpServerPort.equals(other.getSmtpServerPort()))) &&
              ((this.smtpServerUserName==null && other.getSmtpServerUserName()==null) ||
               (this.smtpServerUserName!=null &&
                this.smtpServerUserName.equals(other.getSmtpServerUserName()))) &&
              this.smtpServerUsingNtlm == other.isSmtpServerUsingNtlm() &&
              ((this.tafavotAccount==null && other.getTafavotAccount()==null) ||
               (this.tafavotAccount!=null &&
                this.tafavotAccount.equals(other.getTafavotAccount()))) &&
              ((this.themeName==null && other.getThemeName()==null) ||
               (this.themeName!=null &&
                this.themeName.equals(other.getThemeName()))) &&
              this.thresholdVariant == other.getThresholdVariant() &&
              ((this.townCode==null && other.getTownCode()==null) ||
               (this.townCode!=null &&
                this.townCode.equals(other.getTownCode()))) &&
              ((this.traderId==null && other.getTraderId()==null) ||
               (this.traderId!=null &&
                this.traderId.equals(other.getTraderId()))) &&
              ((this.version==null && other.getVersion()==null) ||
               (this.version!=null &&
                this.version.equals(other.getVersion()))) &&
              ((this.webSocketAddress==null && other.getWebSocketAddress()==null) ||
               (this.webSocketAddress!=null &&
                this.webSocketAddress.equals(other.getWebSocketAddress()))) &&
              this.maxAssetPrint == other.getMaxAssetPrint() &&
              ((this.accessToPageSystemActivity==null && other.getAccessToPageSystemActivity()==null) ||
               (this.accessToPageSystemActivity!=null &&
                this.accessToPageSystemActivity.equals(other.getAccessToPageSystemActivity()))) &&
              this.porofilerAppId == other.getPorofilerAppId() &&
              ((this.networkPerformenceURL==null && other.getNetworkPerformenceURL()==null) ||
               (this.networkPerformenceURL!=null &&
                this.networkPerformenceURL.equals(other.getNetworkPerformenceURL()))) &&
              ((this.googleAnalytics==null && other.getGoogleAnalytics()==null) ||
               (this.googleAnalytics!=null &&
                this.googleAnalytics.equals(other.getGoogleAnalytics()))) &&
              ((this.userBrowserVersion==null && other.getUserBrowserVersion()==null) ||
               (this.userBrowserVersion!=null &&
                this.userBrowserVersion.equals(other.getUserBrowserVersion()))) &&
              this.changePasswordCycle == other.getChangePasswordCycle() &&
              this.lockUserCycle == other.getLockUserCycle() &&
              ((this.userBrowserFlashPlayerVersion==null && other.getUserBrowserFlashPlayerVersion()==null) ||
               (this.userBrowserFlashPlayerVersion!=null &&
                this.userBrowserFlashPlayerVersion.equals(other.getUserBrowserFlashPlayerVersion()))) &&
              this.userReportJobStartTime == other.getUserReportJobStartTime() &&
              ((this.retrievingDataMethods==null && other.getRetrievingDataMethods()==null) ||
               (this.retrievingDataMethods!=null &&
                this.retrievingDataMethods.equals(other.getRetrievingDataMethods()))) &&
              this.showFill_And_Kill == other.isShowFill_And_Kill() &&
              this.externalResourceTimeOut == other.getExternalResourceTimeOut() &&
              this.sendSMS == other.isSendSMS();
          __equalsCalc = null;
          return _equals;
      }

      private boolean __hashCodeCalc = false;
      public synchronized int hashCode() {
          if (__hashCodeCalc) {
              return 0;
          }
          __hashCodeCalc = true;
          int _hashCode = 1;
          if (getAutomationUsernamePrefix() != null) {
              _hashCode += getAutomationUsernamePrefix().hashCode();
          }
          if (getAutomationAccountingPrefix() != null) {
              _hashCode += getAutomationAccountingPrefix().hashCode();
          }
          if (getRLCServerAddrerss() != null) {
              _hashCode += getRLCServerAddrerss().hashCode();
          }
          if (getCancelStartTime() != null) {
              _hashCode += getCancelStartTime().hashCode();
          }
          if (getCancelEndTime() != null) {
              _hashCode += getCancelEndTime().hashCode();
          }
          if (getForbiddenOrderStartTime() != null) {
              _hashCode += getForbiddenOrderStartTime().hashCode();
          }
          if (getForbiddenOrderEndTime() != null) {
              _hashCode += getForbiddenOrderEndTime().hashCode();
          }
          _hashCode += getForbiddenOrderValidity();
          _hashCode += getDiffBestPercent();
          if (getStartTimeLastTradedPriceDiff() != null) {
              _hashCode += getStartTimeLastTradedPriceDiff().hashCode();
          }
          if (getEndTimeLastTradedPriceDiff() != null) {
              _hashCode += getEndTimeLastTradedPriceDiff().hashCode();
          }
          if (getSiteThemes() != null) {
              _hashCode += getSiteThemes().hashCode();
          }
          _hashCode += new Long(getVolumeThresholdForDiff()).hashCode();
          _hashCode += new Long(getValueThresholdForBuy()).hashCode();
          _hashCode += new Long(getLastTradePriceDiffPercent()).hashCode();
          _hashCode += (isCheckRuleForBranchSupervisor() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          if (getAccountingDatabasePassword() != null) {
              _hashCode += getAccountingDatabasePassword().hashCode();
          }
          if (getAccountingDatabaseServer() != null) {
              _hashCode += getAccountingDatabaseServer().hashCode();
          }
          if (getAccountingDatabaseUserId() != null) {
              _hashCode += getAccountingDatabaseUserId().hashCode();
          }
          if (getAccountingFinancialYear() != null) {
              _hashCode += getAccountingFinancialYear().hashCode();
          }
          if (getAccountingGroupNo() != null) {
              _hashCode += getAccountingGroupNo().hashCode();
          }
          _hashCode += getAccountingUserId();
          _hashCode += (isActiveBuyRequestForCustomerWithoutBalance() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isActiveRightForBuy() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isActiveRightForSell() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          if (getBankCode() != null) {
              _hashCode += getBankCode().hashCode();
          }
          if (getBourseKarmozdAccountForBuy() != null) {
              _hashCode += getBourseKarmozdAccountForBuy().hashCode();
          }
          if (getBourseKarmozdAccountForSell() != null) {
              _hashCode += getBourseKarmozdAccountForSell().hashCode();
          }
          if (getBranchCode() != null) {
              _hashCode += getBranchCode().hashCode();
          }
          if (getBrokerId() != null) {
              _hashCode += getBrokerId().hashCode();
          }
          if (getBrokerName() != null) {
              _hashCode += getBrokerName().hashCode();
          }
          if (getBrokerWebSite() != null) {
              _hashCode += getBrokerWebSite().hashCode();
          }
          if (getBrokerWebSiteDB() != null) {
              _hashCode += getBrokerWebSiteDB().hashCode();
          }
          _hashCode += (isBuyOrderEditCount() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isBuyOrderEditMinQty() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isBuyOrderEditPrice() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isBuyOrderEditShownVolume() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isBuyOrderEditValidity() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          if (getCallBackUrl() != null) {
              _hashCode += getCallBackUrl().hashCode();
          }
          _hashCode += (isCanBuy() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isCanBuySell() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isCanSell() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          if (getCDSPassword() != null) {
              _hashCode += getCDSPassword().hashCode();
          }
          if (getCDSUserName() != null) {
              _hashCode += getCDSUserName().hashCode();
          }
          if (getCountryCode() != null) {
              _hashCode += getCountryCode().hashCode();
          }
          if (getCustomerAccount() != null) {
              _hashCode += getCustomerAccount().hashCode();
          }
          _hashCode += (isDefaultConfirmBranchVoucher() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isEnableSmtpSSL() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          if (getFanavariAccountForBuy() != null) {
              _hashCode += getFanavariAccountForBuy().hashCode();
          }
          if (getFanavariAccountForSell() != null) {
              _hashCode += getFanavariAccountForSell().hashCode();
          }
          _hashCode += getStockTableLimitForCustomer();
          _hashCode += getStockTableLimitForBranch();
          _hashCode += (isIsReady() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += new Double(getKarmozdForBuy()).hashCode();
          _hashCode += new Double(getKarmozdForSell()).hashCode();
          if (getKhadamatsherkatbourceAccount2ForBuy() != null) {
              _hashCode += getKhadamatsherkatbourceAccount2ForBuy().hashCode();
          }
          if (getKhadamatsherkatbourceAccount2ForSell() != null) {
              _hashCode += getKhadamatsherkatbourceAccount2ForSell().hashCode();
          }
          if (getKhadamatsherkatbourceAccountForBuy() != null) {
              _hashCode += getKhadamatsherkatbourceAccountForBuy().hashCode();
          }
          if (getKhadamatsherkatbourceAccountForSell() != null) {
              _hashCode += getKhadamatsherkatbourceAccountForSell().hashCode();
          }
          _hashCode += new Long(getMaxRequestPerSecond()).hashCode();
          if (getMaleyatAccount() != null) {
              _hashCode += getMaleyatAccount().hashCode();
          }
          if (getMarketCloseTime() != null) {
              _hashCode += getMarketCloseTime().hashCode();
          }
          if (getMarketOpenTime() != null) {
              _hashCode += getMarketOpenTime().hashCode();
          }
          _hashCode += new Long(getMaximumDateRangeForBuy()).hashCode();
          _hashCode += new Long(getMaximumDateRangeForSell()).hashCode();
          _hashCode += new Long(getMaximumOrderCountForBuy()).hashCode();
          _hashCode += new Long(getMaximumOrderCountForSell()).hashCode();
          _hashCode += new Long(getMaximumOrderValueForBuy()).hashCode();
          _hashCode += new Long(getMaximumOrderValueForSell()).hashCode();
          if (getMellatAccountCode() != null) {
              _hashCode += getMellatAccountCode().hashCode();
          }
          if (getMellatPublicKey() != null) {
              _hashCode += getMellatPublicKey().hashCode();
          }
          _hashCode += getMinimumOrderCountForBuy();
          _hashCode += getMinimumOrderCountForSell();
          _hashCode += getMinimumOrderValueForBuy();
          _hashCode += getMinimumOrderValueForSell();
          if (getMoamelatBrokerKarmozdAccountForBuy() != null) {
              _hashCode += getMoamelatBrokerKarmozdAccountForBuy().hashCode();
          }
          if (getMoamelatBrokerKarmozdAccountForSell() != null) {
              _hashCode += getMoamelatBrokerKarmozdAccountForSell().hashCode();
          }
          if (getNezaratbourseKarmozdAccountForBuy() != null) {
              _hashCode += getNezaratbourseKarmozdAccountForBuy().hashCode();
          }
          if (getNezaratbourseKarmozdAccountForSell() != null) {
              _hashCode += getNezaratbourseKarmozdAccountForSell().hashCode();
          }
          if (getNoReplayEmail() != null) {
              _hashCode += getNoReplayEmail().hashCode();
          }
          if (getOMSDatabaseName() != null) {
              _hashCode += getOMSDatabaseName().hashCode();
          }
          if (getOMSDatabasePassword() != null) {
              _hashCode += getOMSDatabasePassword().hashCode();
          }
          if (getOMSDatabaseServer() != null) {
              _hashCode += getOMSDatabaseServer().hashCode();
          }
          if (getOMSDatabaseUserId() != null) {
              _hashCode += getOMSDatabaseUserId().hashCode();
          }
          if (getPayapayAccount() != null) {
              _hashCode += getPayapayAccount().hashCode();
          }
          if (getPayapayAccountForBuy() != null) {
              _hashCode += getPayapayAccountForBuy().hashCode();
          }
          if (getPayapayAccountForSell() != null) {
              _hashCode += getPayapayAccountForSell().hashCode();
          }
          if (getTrustChainPath() != null) {
              _hashCode += getTrustChainPath().hashCode();
          }
          _hashCode += (isSellOrderEditCount() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isSellOrderEditMinQty() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isSellOrderEditPrice() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isSellOrderEditShownVolume() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += (isSellOrderEditValidity() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          if (getSepordehGozariAccountForBuy() != null) {
              _hashCode += getSepordehGozariAccountForBuy().hashCode();
          }
          if (getSepordehGozariAccountForSell() != null) {
              _hashCode += getSepordehGozariAccountForSell().hashCode();
          }
          _hashCode += getServiceMailApplicationId();
          if (getServiceMailPassword() != null) {
              _hashCode += getServiceMailPassword().hashCode();
          }
          if (getServiceMailUserName() != null) {
              _hashCode += getServiceMailUserName().hashCode();
          }
          if (getSmtpServer() != null) {
              _hashCode += getSmtpServer().hashCode();
          }
          if (getSmtpServerPassword() != null) {
              _hashCode += getSmtpServerPassword().hashCode();
          }
          if (getSmtpServerPort() != null) {
              _hashCode += getSmtpServerPort().hashCode();
          }
          if (getSmtpServerUserName() != null) {
              _hashCode += getSmtpServerUserName().hashCode();
          }
          _hashCode += (isSmtpServerUsingNtlm() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          if (getTafavotAccount() != null) {
              _hashCode += getTafavotAccount().hashCode();
          }
          if (getThemeName() != null) {
              _hashCode += getThemeName().hashCode();
          }
          _hashCode += new Double(getThresholdVariant()).hashCode();
          if (getTownCode() != null) {
              _hashCode += getTownCode().hashCode();
          }
          if (getTraderId() != null) {
              _hashCode += getTraderId().hashCode();
          }
          if (getVersion() != null) {
              _hashCode += getVersion().hashCode();
          }
          if (getWebSocketAddress() != null) {
              _hashCode += getWebSocketAddress().hashCode();
          }
          _hashCode += getMaxAssetPrint();
          if (getAccessToPageSystemActivity() != null) {
              _hashCode += getAccessToPageSystemActivity().hashCode();
          }
          _hashCode += getPorofilerAppId();
          if (getNetworkPerformenceURL() != null) {
              _hashCode += getNetworkPerformenceURL().hashCode();
          }
          if (getGoogleAnalytics() != null) {
              _hashCode += getGoogleAnalytics().hashCode();
          }
          if (getUserBrowserVersion() != null) {
              _hashCode += getUserBrowserVersion().hashCode();
          }
          _hashCode += getChangePasswordCycle();
          _hashCode += getLockUserCycle();
          if (getUserBrowserFlashPlayerVersion() != null) {
              _hashCode += getUserBrowserFlashPlayerVersion().hashCode();
          }
          _hashCode += getUserReportJobStartTime();
          if (getRetrievingDataMethods() != null) {
              _hashCode += getRetrievingDataMethods().hashCode();
          }
          _hashCode += (isShowFill_And_Kill() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          _hashCode += getExternalResourceTimeOut();
          _hashCode += (isSendSMS() ? Boolean.TRUE : Boolean.FALSE).hashCode();
          __hashCodeCalc = false;
          return _hashCode;
      }

      // Type metadata
      private static org.apache.axis.description.TypeDesc typeDesc =
          new org.apache.axis.description.TypeDesc(OMSSetting.class, true);

      static {
          typeDesc.setXmlType(new javax.xml.namespace.QName("http://tempuri.org/", "OMSSetting"));
          org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("automationUsernamePrefix");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "AutomationUsernamePrefix"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("automationAccountingPrefix");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "AutomationAccountingPrefix"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("RLCServerAddrerss");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "RLCServerAddrerss"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("cancelStartTime");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CancelStartTime"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("cancelEndTime");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CancelEndTime"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("forbiddenOrderStartTime");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ForbiddenOrderStartTime"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("forbiddenOrderEndTime");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ForbiddenOrderEndTime"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("forbiddenOrderValidity");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ForbiddenOrderValidity"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("diffBestPercent");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "DiffBestPercent"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("startTimeLastTradedPriceDiff");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "StartTimeLastTradedPriceDiff"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("endTimeLastTradedPriceDiff");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "EndTimeLastTradedPriceDiff"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("siteThemes");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SiteThemes"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("volumeThresholdForDiff");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "VolumeThresholdForDiff"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("valueThresholdForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ValueThresholdForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("lastTradePriceDiffPercent");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "LastTradePriceDiffPercent"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("checkRuleForBranchSupervisor");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CheckRuleForBranchSupervisor"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("accountingDatabasePassword");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "AccountingDatabasePassword"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("accountingDatabaseServer");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "AccountingDatabaseServer"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("accountingDatabaseUserId");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "AccountingDatabaseUserId"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("accountingFinancialYear");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "AccountingFinancialYear"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("accountingGroupNo");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "AccountingGroupNo"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("accountingUserId");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "AccountingUserId"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("activeBuyRequestForCustomerWithoutBalance");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ActiveBuyRequestForCustomerWithoutBalance"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("activeRightForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ActiveRightForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("activeRightForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ActiveRightForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("bankCode");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BankCode"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("bourseKarmozdAccountForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BourseKarmozdAccountForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("bourseKarmozdAccountForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BourseKarmozdAccountForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("branchCode");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BranchCode"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("brokerId");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BrokerId"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("brokerName");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BrokerName"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("brokerWebSite");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BrokerWebSite"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("brokerWebSiteDB");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BrokerWebSiteDB"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("buyOrderEditCount");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BuyOrderEditCount"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("buyOrderEditMinQty");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BuyOrderEditMinQty"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("buyOrderEditPrice");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BuyOrderEditPrice"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("buyOrderEditShownVolume");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BuyOrderEditShownVolume"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("buyOrderEditValidity");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "BuyOrderEditValidity"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("callBackUrl");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CallBackUrl"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("canBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CanBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("canBuySell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CanBuySell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("canSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CanSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("CDSPassword");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CDSPassword"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("CDSUserName");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CDSUserName"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("countryCode");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CountryCode"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("customerAccount");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "CustomerAccount"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("defaultConfirmBranchVoucher");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "DefaultConfirmBranchVoucher"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("enableSmtpSSL");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "EnableSmtpSSL"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("fanavariAccountForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "FanavariAccountForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("fanavariAccountForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "FanavariAccountForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("stockTableLimitForCustomer");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "StockTableLimitForCustomer"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("stockTableLimitForBranch");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "StockTableLimitForBranch"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("isReady");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "IsReady"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("karmozdForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "KarmozdForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("karmozdForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "KarmozdForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("khadamatsherkatbourceAccount2ForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "KhadamatsherkatbourceAccount2ForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("khadamatsherkatbourceAccount2ForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "KhadamatsherkatbourceAccount2ForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("khadamatsherkatbourceAccountForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "KhadamatsherkatbourceAccountForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("khadamatsherkatbourceAccountForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "KhadamatsherkatbourceAccountForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("maxRequestPerSecond");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MaxRequestPerSecond"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("maleyatAccount");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MaleyatAccount"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("marketCloseTime");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MarketCloseTime"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("marketOpenTime");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MarketOpenTime"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("maximumDateRangeForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MaximumDateRangeForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("maximumDateRangeForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MaximumDateRangeForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("maximumOrderCountForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MaximumOrderCountForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("maximumOrderCountForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MaximumOrderCountForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("maximumOrderValueForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MaximumOrderValueForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("maximumOrderValueForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MaximumOrderValueForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("mellatAccountCode");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MellatAccountCode"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("mellatPublicKey");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MellatPublicKey"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("minimumOrderCountForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MinimumOrderCountForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("minimumOrderCountForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MinimumOrderCountForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("minimumOrderValueForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MinimumOrderValueForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("minimumOrderValueForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MinimumOrderValueForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("moamelatBrokerKarmozdAccountForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MoamelatBrokerKarmozdAccountForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("moamelatBrokerKarmozdAccountForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MoamelatBrokerKarmozdAccountForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("nezaratbourseKarmozdAccountForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "NezaratbourseKarmozdAccountForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("nezaratbourseKarmozdAccountForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "NezaratbourseKarmozdAccountForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("noReplayEmail");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "NoReplayEmail"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("OMSDatabaseName");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OMSDatabaseName"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("OMSDatabasePassword");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OMSDatabasePassword"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("OMSDatabaseServer");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OMSDatabaseServer"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("OMSDatabaseUserId");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "OMSDatabaseUserId"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("payapayAccount");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "PayapayAccount"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("payapayAccountForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "PayapayAccountForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("payapayAccountForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "PayapayAccountForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("trustChainPath");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "TrustChainPath"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("sellOrderEditCount");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SellOrderEditCount"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("sellOrderEditMinQty");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SellOrderEditMinQty"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("sellOrderEditPrice");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SellOrderEditPrice"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("sellOrderEditShownVolume");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SellOrderEditShownVolume"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("sellOrderEditValidity");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SellOrderEditValidity"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("sepordehGozariAccountForBuy");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SepordehGozariAccountForBuy"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("sepordehGozariAccountForSell");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SepordehGozariAccountForSell"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("serviceMailApplicationId");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ServiceMailApplicationId"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("serviceMailPassword");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ServiceMailPassword"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("serviceMailUserName");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ServiceMailUserName"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("smtpServer");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SmtpServer"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("smtpServerPassword");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SmtpServerPassword"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("smtpServerPort");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SmtpServerPort"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("smtpServerUserName");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SmtpServerUserName"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("smtpServerUsingNtlm");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SmtpServerUsingNtlm"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("tafavotAccount");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "TafavotAccount"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("themeName");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ThemeName"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("thresholdVariant");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ThresholdVariant"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("townCode");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "TownCode"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("traderId");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "TraderId"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("version");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "Version"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("webSocketAddress");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "WebSocketAddress"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("maxAssetPrint");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "MaxAssetPrint"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("accessToPageSystemActivity");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "AccessToPageSystemActivity"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("porofilerAppId");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "PorofilerAppId"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("networkPerformenceURL");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "NetworkPerformenceURL"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("googleAnalytics");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "GoogleAnalytics"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("userBrowserVersion");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "UserBrowserVersion"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("changePasswordCycle");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ChangePasswordCycle"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("lockUserCycle");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "LockUserCycle"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("userBrowserFlashPlayerVersion");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "UserBrowserFlashPlayerVersion"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("userReportJobStartTime");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "UserReportJobStartTime"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("retrievingDataMethods");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "RetrievingDataMethods"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
          elemField.setMinOccurs(0);
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("showFill_And_Kill");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ShowFill_And_Kill"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("externalResourceTimeOut");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "ExternalResourceTimeOut"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
          elemField = new org.apache.axis.description.ElementDesc();
          elemField.setFieldName("sendSMS");
          elemField.setXmlName(new javax.xml.namespace.QName("http://tempuri.org/", "SendSMS"));
          elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
          elemField.setNillable(false);
          typeDesc.addFieldDesc(elemField);
      }

      /**
       * Return type metadata object
       */
      public static org.apache.axis.description.TypeDesc getTypeDesc() {
          return typeDesc;
      }

      /**
       * Get Custom Serializer
       */
      public static org.apache.axis.encoding.Serializer getSerializer(
             java.lang.String mechType,
             java.lang.Class _javaType,
             javax.xml.namespace.QName _xmlType) {
          return
            new  org.apache.axis.encoding.ser.BeanSerializer(
              _javaType, _xmlType, typeDesc);
      }

      /**
       * Get Custom Deserializer
       */
      public static org.apache.axis.encoding.Deserializer getDeserializer(
             java.lang.String mechType,
             java.lang.Class _javaType,
             javax.xml.namespace.QName _xmlType) {
          return
            new  org.apache.axis.encoding.ser.BeanDeserializer(
              _javaType, _xmlType, typeDesc);
      }

  }
